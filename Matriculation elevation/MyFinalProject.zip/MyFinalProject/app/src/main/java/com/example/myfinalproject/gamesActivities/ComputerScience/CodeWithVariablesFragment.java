package com.example.myfinalproject.gamesActivities.ComputerScience;

import android.content.Intent; // Import Intent
import android.content.SharedPreferences; // Import SharedPreferences
import android.os.Bundle; // Import Bundle
import android.util.Log; // Import Log
import android.view.LayoutInflater; // Import LayoutInflater
import android.view.Menu; // Import Menu
import android.view.MenuInflater; // Import MenuInflater
import android.view.MenuItem; // Import MenuItem
import android.view.View; // Import View
import android.view.ViewGroup; // Import ViewGroup
import android.widget.Button; // Import Button
import android.widget.RadioGroup; // Import RadioGroup
import android.widget.TextView; // Import TextView
import android.widget.Toast; // Import Toast

import androidx.annotation.NonNull; // Import annotations
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity; // Import AppCompatActivity
import androidx.appcompat.widget.Toolbar; // Import Toolbar
import androidx.core.content.ContextCompat; // Import ContextCompat
import androidx.fragment.app.Fragment; // Import Fragment
import androidx.fragment.app.FragmentManager; // Import FragmentManager

import com.example.myfinalproject.R; // Import R
import com.example.myfinalproject.activities.LogInActivity; // Import activities
import com.example.myfinalproject.activities.MainActivity;
import com.example.myfinalproject.activities.ProfileActivity;
import com.example.myfinalproject.activities.SettingsActivity;
import com.example.myfinalproject.adapters.SubtopicAdapter; // Import SubtopicAdapter
import com.example.myfinalproject.java_classes.Constants; // Import Constants
import com.example.myfinalproject.java_classes.CourseClass; // Import data classes
import com.example.myfinalproject.java_classes.SubTopicClass;
import com.example.myfinalproject.java_classes.UserInfoClass;
import com.google.android.gms.tasks.OnFailureListener; // Import Firebase task listeners
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task; // Import Task
import com.google.firebase.auth.FirebaseAuth; // Import Firebase Auth
import com.google.firebase.auth.FirebaseUser; // Import FirebaseUser
import com.google.firebase.firestore.DocumentReference; // Import Firestore classes
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList; // Import ArrayList

// Class: CodeWithVariablesFragment
// Description: A Fragment representing a game/exercise related to computer science variables.
// It allows the user to select an answer and provides feedback. It also handles updating
// the user's progress for this specific subtopic in Firestore and navigation.
// Input: none (as it's a Fragment, gets data via UI interaction and Firebase)
// Output: Displays UI, handles user interaction, updates Firestore, navigates.
public class CodeWithVariablesFragment extends Fragment {
    // UI Variables
    private Button startButton; // Button to start the exercise (might be unused in current logic)
    private RadioGroup selectCorrectAnswerVariableExercise; // RadioGroup for answer selection
    private Button nextButton; // Button to proceed/submit (triggers progress update)
    private TextView successOrFailedMessage; // TextView to display feedback message

    // Firebase Variables
    private FirebaseAuth mAuth; // Firebase Authentication instance
    private FirebaseFirestore db; // Firestore database instance
    private String userId; // User ID (might be redundant with currentUser.getUid())

    // Function: onCreateView
    // Description: Called to create the view hierarchy for the fragment.
    // Inflates the layout, initializes views, listeners, Firebase, and sets up the toolbar menu.
    // Input: LayoutInflater inflater - The LayoutInflater object that can be used to inflate any views in the fragment.
    // Input: ViewGroup container - If non-null, this is the parent view that the fragment's UI should be attached to.
    // Input: Bundle savedInstanceState - If non-null, this fragment is being re-constructed from a previous saved state.
    // Output: View - The root View of the fragment's layout.
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Step 1: Inflate the layout for this fragment from code_with_variables_fragment.xml
        View view = inflater.inflate(R.layout.code_with_variables_fragment, container, false);

        // Step 2: Initialize UI views
        initViews(view);
        // Step 3: Initialize event listeners
        initListeners();

        // Step 4: Initialize Firebase instances
        mAuth = FirebaseAuth.getInstance(); // Get Auth instance
        db = FirebaseFirestore.getInstance(); // Get Firestore instance
        // Step 5: Indicate that this fragment has its own options menu
        setHasOptionsMenu(true); // Ensure menu options show up

        // Step 6: Get the main activity's Toolbar and set it as the action bar for the fragment
        // This allows the fragment to manage the options menu displayed on this toolbar.
        Toolbar toolbar = requireActivity().findViewById(R.id.toolbarMain); // Find toolbar in the hosting activity
        ((AppCompatActivity) requireActivity()).setSupportActionBar(toolbar); // Set it as the action bar

        // Step 7: Return the root view of the fragment
        return view;
    }

    // Function: initViews
    // Description: Initializes UI elements by finding them in the layout.
    // Input: View view - The root view of the fragment's layout.
    // Output: void (Initializes UI views).
    private void initViews(View view) {
        // Step 1: Find and assign the start button
        startButton = view.findViewById(R.id.startButton);
        // Step 2: Find and assign the radio group for answers
        selectCorrectAnswerVariableExercise = view.findViewById(R.id.selectCorrectAnswerVariableExercise);
        // Step 3: Find and assign the next button
        nextButton = view.findViewById(R.id.nextButton);
        // Step 4: Find and assign the success/failure message TextView
        successOrFailedMessage = view.findViewById(R.id.successOrFailureMessage);
    }

    // Function: initListeners
    // Description: Sets up click listeners for buttons and the checked change listener for the RadioGroup.
    // Input: none
    // Output: void (Sets up listeners).
    private void initListeners() {
        // Step 1: Set a click listener for the Next button
        nextButton.setOnClickListener(new View.OnClickListener() {
            // Function: onClick
            // Description: Called when the Next button is clicked. Triggers updating subtopic progress.
            // Input: View view - The clicked view (the button).
            // Output: void (Calls updateSubtopicProgress helper method).
            @Override
            public void onClick(View view) {
                // Step 1.1: Call the helper method to update subtopic progress
                updateSubtopicProgress();
            }
        });

        // Step 2: Set a checked change listener for the answer selection RadioGroup
        selectCorrectAnswerVariableExercise.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            // Function: onCheckedChanged
            // Description: Called when the selected radio button in the group changes. Provides immediate feedback.
            // Input: RadioGroup radioGroup - The RadioGroup whose selection has changed.
            // Input: int i - The ID of the newly selected radio button.
            // Output: void (Shows success or failure message based on selection).
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                // Step 2.1: Check if the selected radio button ID matches the correct answer's ID (R.id.option1Variable)
                if (i == R.id.option1Variable) {
                    // Step 2.1.1: If correct, show the success message
                    showSuccessMessage();
                } else {
                    // Step 2.1.2: If incorrect, show the failure message
                    showFailureMessage();
                }
            }
        });
    }

    // Function: updateSubtopicProgress
    // Description: Updates the progress for the 'Variables' CS subtopic in Firestore.
    // It retrieves the current user's courses, finds the specific subtopic, updates its progress,
    // saves the modified course list back to Firestore, and navigates to the next fragment on success.
    // Input: none
    // Output: void (Fetches user data, updates Firestore, navigates, shows feedback).
    private void updateSubtopicProgress() {
        // Step 1: Reset the global currently selected subtopic (optional, depends on app flow)
        SubtopicAdapter.currentlySelectedSubtopic = null;

        // Step 2: Get the currently logged-in Firebase user
        FirebaseUser currentUser = mAuth.getCurrentUser();
        // Step 3: Check if the user is logged in
        if (currentUser == null) {
            // Step 3.1: If not logged in, show a toast and exit the method
            Toast.makeText(getContext(), "User not signed in", Toast.LENGTH_SHORT).show();
            return; // Exit the method
        }

        // Step 4: Get the current user's UID
        String userId = currentUser.getUid();
        // Step 5: Get a document reference to the user's data in Firestore
        DocumentReference userRef = db.collection("users").document(userId);

        // Step 6: Retrieve current user data from Firestore asynchronously
        userRef.get().addOnCompleteListener(task -> {
            // Function: onComplete (OnCompleteListener for Firestore get)
            // Description: Called when the task to get user data completes.
            // Input: Task<DocumentSnapshot> task - The completed task.
            // Output: void (Processes user data, updates subtopic, saves to Firestore, navigates).
            // Step 6.1: Check if the task was successful
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                // Step 6.2: Check if the document exists and is not null
                if (document != null && document.exists()) {
                    // Step 6.3: Convert the document to a UserInfoClass object
                    UserInfoClass userInfo = document.toObject(UserInfoClass.class);
                    // Step 6.4: Check if UserInfo object and its classes list are valid
                    if (userInfo != null && userInfo.getClasses() != null) {
                        // Step 6.5: Get the list of existing courses
                        ArrayList<CourseClass> courses = userInfo.getClasses(); // Existing courses list
                        boolean updated = false; // Flag to track if progress was updated

                        // Step 6.6: Iterate through courses and subtopics to find the target subtopic
                        for (CourseClass course : courses) {
                            if (course.getSubtopics() != null) {
                                for (SubTopicClass subTopic : course.getSubtopics()) {
                                    // Step 6.6.1: Check if the current subtopic matches the target subtopic ('Variables')
                                    if (subTopic.getName().equals(Constants.KEY_CS_VARIABLES)) {
                                        // Step 6.6.2: Calculate the score based on the selected radio button
                                        int score = 0; // Default score is 0
                                        // Check if the correctly answered option is selected in the RadioGroup
                                        if (R.id.option1Variable == selectCorrectAnswerVariableExercise.getCheckedRadioButtonId())
                                            score = 100; // Set score to 100 if correct

                                        // Step 6.6.3: Update the progress for this specific subtopic
                                        subTopic.setProgress(score); // Mark as completed (or partial based on logic)
                                        updated = true; // Set the flag to true
                                        break; // Exit the inner subtopic loop once found
                                    }
                                }
                            }
                            // Step 6.6.4: If the subtopic was updated, exit the outer course loop as well
                            if (updated) break;
                        }

                        // Step 6.7: Update the 'classes' field in the user's Firestore document with the modified courses list
                        userRef.update("classes", courses)
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    // Function: onSuccess (OnSuccessListener for Firestore update)
                                    // Description: Called when the Firestore update succeeds.
                                    // Input: Void aVoid - Placeholder.
                                    // Output: void (Shows success toast and navigates).
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        // Step 6.7.1.1: Show a toast message indicating progress update success
                                        Toast.makeText(getContext(), "Subtopic progress updated!", Toast.LENGTH_SHORT).show();
                                        // Step 6.7.1.2: Navigate to the next fragment (VariablesExerciseFragment) after successful update
                                        requireActivity().getSupportFragmentManager().beginTransaction()
                                                .replace(R.id.fragment_container_main, new VariablesExerciseFragment()) // Replace current fragment
                                                .addToBackStack(null) // Add to back stack for navigation
                                                .commit(); // Commit the transaction
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    // Function: onFailure (OnFailureListener for Firestore update)
                                    // Description: Called when the Firestore update fails.
                                    // Input: Exception e - The exception detailing the failure.
                                    // Output: void (Shows error toast and logs error).
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        // Step 6.7.2.1: Show a toast message with the error details
                                        Toast.makeText(getContext(), "Error updating Firestore: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                        // Step 6.7.2.2: Log the error
                                        Log.e("Firestore", "Error updating subtopic progress", e);
                                        // Note: Navigation might not happen on failure, keeping the user on the current fragment.
                                    }
                                });
                    } else {
                        // Step 6.8: Show a toast if user data or course list is unexpectedly null
                        Toast.makeText(requireContext(), "User data or course list is null.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Step 6.9: Show a toast if the user document is not found in Firestore
                    Toast.makeText(requireContext(), "User document not found.", Toast.LENGTH_SHORT).show();
                }
            } else {
                // Step 6.10: Show a toast and log if fetching user data from Firestore failed
                Toast.makeText(requireContext(), "Error getting user data: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("Firestore", "Error getting user data", task.getException());
            }
        });
    }

    // Function: showSuccessMessage
    // Description: Makes the feedback message TextView visible, sets its background to green, and sets the success text.
    // Input: none
    // Output: void (Updates UI element).
    private void showSuccessMessage() {
        // Step 1: Make the success/failure message TextView visible
        successOrFailedMessage.setVisibility(View.VISIBLE);
        // Step 2: Set the background color to green
        successOrFailedMessage.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.green));
        // Step 3: Set the success message text
        successOrFailedMessage.setText("Well done, correct answer!"); // Move text update here
    }

    // Function: showFailureMessage
    // Description: Makes the feedback message TextView visible, sets its background to red, and sets the failure text.
    // Input: none
    // Output: void (Updates UI element).
    private void showFailureMessage() {
        // Step 1: Make the success/failure message TextView visible
        successOrFailedMessage.setVisibility(View.VISIBLE);
        // Step 2: Set the background color to red
        successOrFailedMessage.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.red_900));
        // Step 3: Set the failure message text
        successOrFailedMessage.setText("Oops! That's not correct. Try again");
    }

    // Function: onCreateOptionsMenu
    // Description: Initializes the options menu for the fragment's toolbar.
    // Input: Menu menu - The options menu.
    // Input: MenuInflater inflater - The inflater to inflate the menu layout.
    // Output: void (Inflates menu).
    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        // Step 1: Call the superclass method
        super.onCreateOptionsMenu(menu, inflater);
        // Step 2: Clear any existing menu items (important for fragments sharing a toolbar)
        menu.clear();
        // Step 3: Inflate the menu layout (R.menu.menu) into the provided Menu object
        inflater.inflate(R.menu.menu, menu);
    }

    // Function: onOptionsItemSelected
    // Description: Called when an item in the options menu is selected. Handles navigation based on the selected item.
    // Input: MenuItem item - The menu item that was selected.
    // Output: boolean - True if the event was consumed, false otherwise.
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Step 1: Get the ID of the selected menu item
        int id = item.getItemId();
        // Step 2: Check the ID and perform the corresponding action
        if (id == R.id.menu_log_out) {
            // Step 2.1: If Log Out is selected, call the logoutUser helper method
            logoutUser();
        } else if (id == R.id.menu_go_back) {
            // Step 2.2: If Go Back is selected, get the FragmentManager from the hosting activity
            FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
            // Step 2.2.1: Check if there are fragments in the back stack
            if (fragmentManager.getBackStackEntryCount() > 0) {
                // Step 2.2.1.1: If yes, pop the back stack to go to the previous fragment
                fragmentManager.popBackStack();
            } else {
                // Step 2.2.1.2: If no fragments in the back stack, navigate back to MainActivity
                Intent intent = new Intent(requireActivity(), MainActivity.class);
                startActivity(intent);
                requireActivity().finish(); // Finish the hosting activity
            }
        } else if (id == R.id.menu_settings) {
            // Step 2.3: If Settings is selected, start the SettingsActivity
            startActivity(new Intent(requireActivity(), SettingsActivity.class));
        } else if (id == R.id.menu_profile) {
            // Step 2.4: If Profile is selected, start the ProfileActivity
            startActivity(new Intent(requireActivity(), ProfileActivity.class));
        } else if (id == R.id.menu_home) {
            // Step 2.5: If Home is selected, navigate back to MainActivity
            Intent intent = new Intent(requireActivity(), MainActivity.class);
            // Step 2.5.1: Reset the global currently selected subtopic (important when going home)
            SubtopicAdapter.currentlySelectedSubtopic = null;
            startActivity(intent);
            // Note: Finishing the activity here might be desired depending on navigation flow.
        }
        // Step 3: Return true to indicate that the event was consumed
        return true;
    }

    // Function: logoutUser
    // Description: Logs out the currently authenticated user from Firebase, updates shared preferences,
    // clears the global selected subtopic, and navigates back to the LogInActivity.
    // Input: none
    // Output: void (Logs out user, updates state, navigates).
    private void logoutUser() {
        // Step 1: Get SharedPreferences for remembering user login
        SharedPreferences sharedPreferences = requireActivity()
                .getSharedPreferences(Constants.KEY_REMEMBER_USER, requireActivity().MODE_PRIVATE);
        // Step 2: Get an editor for SharedPreferences
        SharedPreferences.Editor editor = sharedPreferences.edit();
        // Step 3: Set the "Remember User" flag to false
        editor.putBoolean(Constants.KEY_REMEMBER_USER, false);
        // Step 4: Apply the changes to SharedPreferences
        editor.apply();

        // Step 5: Clear the global currently selected subtopic
        SubtopicAdapter.currentlySelectedSubtopic = null;
        // Step 6: Sign out the user from Firebase Authentication
        mAuth.signOut();

        // Step 7: Create an Intent to navigate to the LogInActivity
        Intent intent = new Intent(requireActivity(), LogInActivity.class);
        // Step 8: Start the LogInActivity
        startActivity(intent);
        // Step 9: Finish the current hosting activity to prevent going back
        requireActivity().finish();
    }
}