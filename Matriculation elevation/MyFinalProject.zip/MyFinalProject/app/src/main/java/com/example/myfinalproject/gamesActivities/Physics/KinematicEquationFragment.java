package com.example.myfinalproject.gamesActivities.Physics;

import android.animation.AnimatorSet; // Import animation classes
import android.animation.ObjectAnimator;
import android.content.Intent; // Import Intent
import android.content.SharedPreferences; // Import SharedPreferences
import android.os.Bundle; // Import Bundle
import android.text.Editable; // Import Editable for TextWatcher
import android.text.TextWatcher; // Import TextWatcher for EditText listener
import android.util.DisplayMetrics; // Import DisplayMetrics
import android.util.Log; // Import Log
import android.view.LayoutInflater; // Import LayoutInflater
import android.view.Menu; // Import Menu
import android.view.MenuInflater; // Import MenuInflater
import android.view.MenuItem; // Import MenuItem
import android.view.View; // Import View
import android.view.ViewGroup; // Import ViewGroup
import android.widget.Button; // Import Button
import android.widget.EditText; // Import EditText
import android.widget.ImageView; // Import ImageView
import android.widget.TextView; // Import TextView
import android.widget.Toast; // Import Toast

import androidx.annotation.NonNull; // Import annotations
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity; // Import AppCompatActivity
import androidx.appcompat.widget.Toolbar; // Import Toolbar
import androidx.fragment.app.Fragment; // Import Fragment

import com.example.myfinalproject.R; // Import R
import com.example.myfinalproject.activities.LogInActivity; // Import activities
import com.example.myfinalproject.activities.MainActivity;
import com.example.myfinalproject.activities.ProfileActivity;
import com.example.myfinalproject.activities.SettingsActivity;
import com.example.myfinalproject.adapters.SubtopicAdapter; // Import SubtopicAdapter
import com.example.myfinalproject.java_classes.Constants; // Import Constants
import com.example.myfinalproject.java_classes.CourseClass; // Import data classes
import com.example.myfinalproject.java_classes.SubTopicClass;
import com.example.myfinalproject.java_classes.UserInfoClass;
import com.google.android.gms.tasks.OnFailureListener; // Import Firebase task listeners
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth; // Import Firebase Auth
import com.google.firebase.auth.FirebaseUser; // Import FirebaseUser
import com.google.firebase.firestore.DocumentReference; // Import Firestore classes
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList; // Import ArrayList

// Class: KinematicEquationFragment
// Description: A Fragment representing an interactive exercise demonstrating kinematic equations.
// Users input initial velocity and acceleration, and the fragment animates a ball's motion
// based on these values over a fixed time. It also includes logic to update user progress in Firestore.
// Input: none (as it's a Fragment, interacts via UI and Firebase)
// Output: Displays UI, handles user input, performs animation, updates Firestore, navigates.
public class KinematicEquationFragment extends Fragment {

    // --- UI Variables ---
    private TextView distanceTraveledTextView; // TextView to display calculated distance
    private TextView timeLimitTextView; // TextView to display the time limit (fixed)
    private EditText velocityEditText; // EditText for user to input velocity
    private EditText accelerationEditText; // EditText for user to input acceleration
    private Button startButton; // Button to start the animation
    private Button continueButton; // Button to proceed to the next subtopic

    private View xAxis; // View representing the X-axis baseline
    private ImageView ball; // ImageView representing the animated ball

    // --- Firebase Variables ---
    private FirebaseUser currentUser; // Current authenticated Firebase user (declared but not directly used in this snippet's methods)
    private FirebaseFirestore firestore; // Firestore database instance
    private FirebaseAuth mAuth; // Firebase Authentication instance

    // --- State Variables ---
    private boolean isCompleteTask = false; // Flag indicating if the task was completed (animation run)

    // --- Constants ---
    private static final String TAG = "KinematicEquationFrag"; // Tag for logging


    // Function: onCreateView
    // Description: Called to create the view hierarchy for the fragment.
    // Inflates the layout, initializes views, listeners, Firebase, sets up the toolbar menu.
    // Input: LayoutInflater inflater - The LayoutInflater object that can be used to inflate any views in the fragment.
    // Input: ViewGroup container - If non-null, this is the parent view that the fragment's UI should be attached to.
    // Input: Bundle savedInstanceState - If non-null, this fragment is being re-constructed from a previous saved state.
    // Output: View - The root View of the fragment's layout.
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Step 1: Inflate the layout for this fragment from physics_equations_activity.xml
        View view = inflater.inflate(R.layout.physics_equations_activity, container, false);

        // Step 2: Initialize UI views
        initializeUI(view);
        // Step 3: Initialize event listeners
        initListeners();

        // Step 4: Initialize Firebase Authentication and Firestore instances
        mAuth = FirebaseAuth.getInstance(); // Get Auth instance
        firestore = FirebaseFirestore.getInstance(); // Get Firestore instance
        // Note: currentUser is declared but not directly used here, userId is used within updateSubtopicProgress.

        // Step 5: Indicate that this fragment has its own options menu
        setHasOptionsMenu(true); // Important for showing the options menu

        // Step 6: Get the main activity's Toolbar and set it as the action bar for the fragment
        Toolbar toolbar = requireActivity().findViewById(R.id.toolbarMain); // Find toolbar in the hosting activity
        ((AppCompatActivity) requireActivity()).setSupportActionBar(toolbar); // Set it as the action bar

        // Step 7: Return the root view of the fragment
        return view;
    }

    // Function: initListeners
    // Description: Sets up click listeners for the Start and Continue buttons.
    // The Start button parses input, performs calculations, and animates the ball.
    // The Continue button updates subtopic progress and navigates to the next fragment.
    // Input: none
    // Output: void (Sets up listeners).
    private void initListeners() {
        // Step 1: Set a click listener for the Start button
        startButton.setOnClickListener(new View.OnClickListener() {
            // Function: onClick
            // Description: Called when the Start button is clicked. Parses input, calculates motion, and runs animation.
            // Input: View view - The clicked view (the button).
            // Output: void (Validates input, calculates distance, animates ball, sets isCompleteTask flag).
            @Override
            public void onClick(View view) {
                // Step 1.1: Parse velocity and acceleration from EditTexts and validate input
                if (velocityEditText.getText().toString().isEmpty() || accelerationEditText.getText().toString().isEmpty()) {
                    // Step 1.1.1: If either field is empty, show a toast and return
                    Toast.makeText(getContext(), "Please enter both velocity and acceleration.", Toast.LENGTH_SHORT).show();
                    return; // Exit the click listener
                }

                // Step 1.2: Parse the input strings to double, handling potential NumberFormatException (though try-catch is outside)
                // Note: The try-catch for NumberFormatException is not directly around these parses in the original code,
                // but TextWatchers add basic validation. A robust approach would add try-catch here or ensure validation prevents bad input.
                double initVel = Double.parseDouble(velocityEditText.getText().toString());
                double accel = Double.parseDouble(accelerationEditText.getText().toString());

                // Step 1.3: Validate input range for velocity
                if (initVel < 0 || initVel > 100) {
                    Toast.makeText(getContext(), "Velocity must be between 0 and 100.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Step 1.4: Validate input range for acceleration
                if (accel < 0 || accel > 50) {
                    Toast.makeText(getContext(), "Acceleration must be between 0 and 50.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Step 1.5: Get screen width using requireActivity() for context
                DisplayMetrics displayMetrics = new DisplayMetrics();
                requireActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
                int screenWidth = displayMetrics.widthPixels;

                // Step 1.6: Calculate the distance traveled using the kinematic equation: d = v_0*t + 0.5*a*t^2
                double time = 5.0; // Fixed time duration
                double distance = initVel * time + 0.5 * accel * time * time;
                // Step 1.7: Display the calculated distance in a TextView
                distanceTraveledTextView.setText("Distance Traveled: " + String.format("%.2f", distance) + " m"); // Format distance

                // Step 1.8: Determine a scaling factor to map the calculated distance to screen pixels
                double maxPossibleDistance = 100 * time + 0.5 * 50 * time * time; // Calculate max possible distance with max inputs
                double scalingFactor = (double) (screenWidth - 300) / maxPossibleDistance; // Scale distance to fit within screen width (minus margins)

                // Step 1.9: Scale the calculated distance using the scaling factor
                distance *= scalingFactor;

                // Step 1.10: Calculate the final translation distance in pixels (toXDelta)
                float toXDelta = (float) distance;

                // Step 1.11: Measure the width of the ball ImageView. Use requireView() to get the fragment's root view.
                ball.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
                int ballWidth = ball.getMeasuredWidth();

                // Step 1.12: Normalize or clamp the translation distance to ensure it stays within screen bounds
                // Note: The 'ballMargin' variable is declared but not used here.
                toXDelta = Math.min(toXDelta, screenWidth - 300); // Clamp to a maximum value

                // Step 1.13: Determine the animation duration
                long duration = (long) (time * 1000); // Set duration based on the fixed time (5 seconds)

                // Step 1.14: Compute the rolling rotation for the ball
                float circumference = ballWidth * (float) Math.PI; // Calculate the ball's circumference
                float rotationDegrees = (toXDelta / circumference) * 360; // Calculate rotations based on distance and circumference

                // Step 1.15: Create ObjectAnimator for translation (horizontal movement)
                ObjectAnimator translationAnimator = ObjectAnimator.ofFloat(ball, "translationX", 0f, toXDelta);
                translationAnimator.setDuration(duration); // Set duration

                // Step 1.16: Create ObjectAnimator for rotation (rolling effect)
                ObjectAnimator rotationAnimator = ObjectAnimator.ofFloat(ball, "rotation", 0f, rotationDegrees);
                rotationAnimator.setDuration(duration); // Set duration

                // Step 1.17: Play both animations simultaneously using an AnimatorSet
                AnimatorSet animatorSet = new AnimatorSet(); // Create an AnimatorSet
                animatorSet.playTogether(translationAnimator, rotationAnimator); // Play translation and rotation together
                animatorSet.start(); // Start the animation set

                // Step 1.18: Mark the task as completed (animation has been run)
                isCompleteTask = true;
            }
        });

        // Step 2: Set a click listener for the Continue button
        continueButton.setOnClickListener(new View.OnClickListener() {
            // Function: onClick
            // Description: Called when the Continue button is clicked. Updates subtopic progress and navigates to the next fragment.
            // Input: View view - The clicked view (the button).
            // Output: void (Updates progress and navigates).
            @Override
            public void onClick(View view) {
                // Step 2.1: Update the subtopic progress in Firestore based on task completion
                updateSubtopicProgress();

                // Step 2.2: Use FragmentManager to replace the current fragment with the next one (MasteringFrictionFragment)
                getParentFragmentManager().beginTransaction() // Get the parent fragment manager
                        .replace(R.id.fragment_container_main, new MasteringFrictionFragment()) // Replace current fragment with the new one
                        .addToBackStack(null) // Optional: Add the current fragment to the back stack so the user can navigate back
                        .commit(); // Commit the transaction
            }
        });
    }

    // Function: initializeUI
    // Description: Initializes UI elements by finding them in the layout and sets up TextWatchers for input validation.
    // Input: View view - The root view of the fragment's layout.
    // Output: void (Initializes UI elements and sets up validation listeners).
    private void initializeUI(View view) {
        // Step 1: Find and assign TextViews
        distanceTraveledTextView = view.findViewById(R.id.distanceTraveled);
        timeLimitTextView = view.findViewById(R.id.timeLimitText); // Note: timeLimitText is not set dynamically in this code.

        // Step 2: Find and assign EditTexts
        velocityEditText = view.findViewById(R.id.velocityInput);
        accelerationEditText = view.findViewById(R.id.accelerationInput);

        // Step 3: Find and assign Buttons
        startButton = view.findViewById(R.id.startButton);
        continueButton = view.findViewById(R.id.continueButton2); // Note: Assumes button ID from layout

        // Step 4: Find and assign other Views (X-axis, Ball)
        xAxis = view.findViewById(R.id.xAxis);
        ball = view.findViewById(R.id.ball);

        // Step 5: Initialize Firebase instances (redundant with onCreateView, can be removed here)
        // mAuth = FirebaseAuth.getInstance(); // Redundant
        // firestore = FirebaseFirestore.getInstance(); // Redundant

        // Step 6: Add text watchers to EditText fields for basic input validation feedback
        // TextWatcher for Velocity EditText
        velocityEditText.addTextChangedListener(new TextWatcher() {
            // Function: beforeTextChanged
            // Description: Called before the text changes. Not used for validation here.
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Not used in this case
            }
            // Function: onTextChanged
            // Description: Called when the text is changing. Not used for validation here.
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Not used in this case
            }
            // Function: afterTextChanged
            // Description: Called after the text has changed. Validates velocity input.
            @Override
            public void afterTextChanged(Editable editable) {
                // Step 6.1.1: Attempt to parse the text to a double
                try {
                    double initialVelocity = Double.parseDouble(editable.toString());
                    // Step 6.1.2: Check if the velocity exceeds the limit
                    if (initialVelocity > 100) { // Set your velocity limit here
                        // Step 6.1.3: Set an error message on the EditText if the limit is exceeded
                        velocityEditText.setError("Velocity cannot exceed 100");
                    } else {
                        // Step 6.1.4: Clear any previous error if the input is valid
                        velocityEditText.setError(null);
                    }
                } catch (NumberFormatException e) {
                    // Step 6.1.5: If parsing fails, set an error message (Handle invalid input)
                    velocityEditText.setError("Invalid number");
                }
            }
        });

        // TextWatcher for Acceleration EditText
        accelerationEditText.addTextChangedListener(new TextWatcher() {
            // Function: beforeTextChanged
            // Description: Called before the text changes. Not used for validation here.
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Not used in this case
            }
            // Function: onTextChanged
            // Description: Called when the text is changing. Not used for validation here.
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Not used in this case
            }
            // Function: afterTextChanged
            // Description: Called after the text has changed. Validates acceleration input.
            @Override
            public void afterTextChanged(Editable s) {
                // Step 6.2.1: Attempt to parse the text to a double
                try {
                    double acceleration = Double.parseDouble(s.toString());
                    // Step 6.2.2: Check if the acceleration exceeds the limit
                    if (acceleration > 50) { // Set your acceleration limit here
                        // Step 6.2.3: Set an error message on the EditText if the limit is exceeded
                        accelerationEditText.setError("Acceleration cannot exceed 50");
                    } else {
                        // Step 6.2.4: Clear any previous error if the input is valid
                        accelerationEditText.setError(null);
                    }
                } catch (NumberFormatException e) {
                    // Step 6.2.5: If parsing fails, set an error message (Handle invalid input)
                    accelerationEditText.setError("Invalid number");
                }
            }
        });
    }

    // Function: updateSubtopicProgress
    // Description: Updates the progress for the 'Kinematic Equations' Physics subtopic in Firestore.
    // It retrieves the current user's courses, finds the specific subtopic, sets its progress
    // (100% if task is complete, 50% otherwise), saves the modified course list back to Firestore,
    // and shows a toast message on success or failure.
    // Input: none
    // Output: void (Fetches user data, updates Firestore, shows feedback).
    // Inside a method in your MainActivity (or wherever you want to perform this update)
    private void updateSubtopicProgress() {
        // Step 1: Get the currently logged-in Firebase user
        FirebaseUser currentUser = mAuth.getCurrentUser(); // Use mAuth to get the current user

        // Step 2: Check if the user is signed in
        if (currentUser == null) {
            // Step 2.1: If user is not signed in, show a toast and exit the method
            // User is not signed in, handle appropriately (e.g., redirect to login)
            Toast.makeText(getContext(), "User not signed in", Toast.LENGTH_SHORT).show();
            return; // Exit the method
        }

        // Step 3: Get the user's UID
        String userId = currentUser.getUid();
        // Step 4: Get a document reference to the user's data in Firestore
        DocumentReference userRef = firestore.collection("users").document(userId); // Use firestore instance

        // Step 5: Retrieve current user data from Firestore asynchronously using addOnCompleteListener
        userRef.get().addOnCompleteListener(task -> {
            // Function: onComplete (OnCompleteListener for Firestore get)
            // Description: Called when the task to get user data completes.
            // Input: Task<DocumentSnapshot> task - The completed task.
            // Output: void (Processes user data, updates subtopic, saves to Firestore, shows feedback).
            // Step 5.1: Check if the task was successful
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                // Step 5.2: Check if the document exists and is not null
                if (document != null && document.exists()) {
                    // Step 5.3: Convert the document to a UserInfoClass object
                    UserInfoClass userInfo = document.toObject(UserInfoClass.class);

                    // Step 5.4: Check if UserInfo object and its classes list are valid
                    if (userInfo != null && userInfo.getClasses() != null) {
                        // Step 5.5: Get the list of existing courses (creates a local copy/reference)
                        // 2. *Modify* the data *locally*.
                        ArrayList<CourseClass> courses = userInfo.getClasses(); // Get the existing list

                        // Step 5.6: Find the specific subtopic ('Kinematic Equations') and update its progress
                        boolean updated = false; // Flag to track if progress was updated
                        // Find and update
                        for (CourseClass course : courses) {
                            if (course.getSubtopics() != null) { // Null Check for subtopics list
                                for (SubTopicClass subTopic : course.getSubtopics()) {
                                    // Step 5.6.1: Check if the current subtopic matches the target subtopic name
                                    if (subTopic.getName().equals(Constants.KEY_PHYSICS_KINEMATIC_EQUATIONS)) {
                                        // Step 5.6.2: Set the progress based on whether the task was completed (animation run)
                                        if (isCompleteTask)
                                            subTopic.setProgress(100); // Set progress to 100% if task completed
                                        else
                                            subTopic.setProgress(50); // Set progress to 50% if task not completed (e.g., user clicked continue without starting)
                                        updated = true; // Set the flag to true
                                        break; // Exit the inner subtopic loop once found.
                                    }
                                }
                            }
                            // Step 5.6.3: If the subtopic was updated, exit the outer course loop as well
                            if (updated) break; // Exit also the course loop
                        }

                        // Step 5.7: Update the 'classes' field in the user's Firestore document with the modified courses list
                        // 3. *Update* Firestore with the *modified* data.
                        userRef.update("classes", courses) // Now 'courses' has the updated progress
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    // Function: onSuccess (OnSuccessListener for Firestore update)
                                    // Description: Called when the Firestore update succeeds.
                                    // Input: Void aVoid - Placeholder.
                                    // Output: void (Shows success toast).
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        // Step 5.7.1.1: Show a toast message indicating progress update success
                                        Toast.makeText(getContext(), "Subtopic progress updated!", Toast.LENGTH_SHORT).show();

                                        // Step 5.7.1.2: (Optional) Update the UI *locally* to reflect the change *immediately*.
                                        // The commented lines below are likely incorrect as they clear and re-add the same modified list.
                                        // courses.clear();  <-- This line is problematic.  You probably don't want to clear the local list here.
                                        // courses.addAll(courses); <-- You probably don't want this either.  You've already modified the `courses` list in place.
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    // Function: onFailure (OnFailureListener for Firestore update)
                                    // Description: Called when the Firestore update fails.
                                    // Input: Exception e - The exception detailing the failure.
                                    // Output: void (Shows error toast and logs error).
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        // Step 5.7.2.1: Show a toast message with the error details
                                        Toast.makeText(getContext(), "Error updating Firestore: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                        // Step 5.7.2.2: Log the error
                                        Log.e("Firestore", "Error updating subtopic progress", e);
                                    }
                                });

                    } else {
                        // Step 5.8: Show a toast if user data or course list is unexpectedly null
                        Toast.makeText(requireContext(), "User data or course list is null.", Toast.LENGTH_SHORT).show(); // Use requireContext()
                    }
                } else {
                    // Step 5.9: Show a toast if the user document is not found in Firestore
                    Toast.makeText(requireContext(), "User document not found.", Toast.LENGTH_SHORT).show(); // Use requireContext()
                }
            } else {
                // Step 5.10: Show a toast and log if fetching user data from Firestore failed
                Toast.makeText(requireContext(), "Error getting user data: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show(); // Use requireContext()
                Log.e("Firestore", "Error getting user data", task.getException());
            }
        });
    }

    // Function: onResume
    // Description: Called when the fragment is visible to the user and actively running.
    // Refreshes the options menu.
    // Input: none
    // Output: void (Refreshes menu).
    @Override
    public void onResume() {
        // Step 1: Call the superclass onResume method
        super.onResume();
        // Step 2: Invalidate the options menu to trigger onCreateOptionsMenu and refresh its state/visibility
        requireActivity().invalidateOptionsMenu(); // Refresh menu visibility
    }

    // Function: onCreateOptionsMenu
    // Description: Initializes the options menu for the fragment's toolbar.
    // Makes the Home menu item visible.
    // Input: Menu menu - The options menu.
    // Input: MenuInflater inflater - The inflater to inflate the menu layout.
    // Output: void (Inflates menu and sets Home item visibility).
    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        // Step 1: Call the superclass method (usually clears and inflates the base menu)
        super.onCreateOptionsMenu(menu, inflater);
        // Note: Original code clears and reinflates in each fragment's onCreateOptionsMenu.
        // Consider inflating only once in the hosting activity if menu is consistent.

        // Step 2: Find the Home menu item
        MenuItem home = menu.findItem(R.id.menu_home);
        // Step 3: Make the Home menu item visible
        home.setVisible(true);
    }

    // Function: onOptionsItemSelected
    // Description: Called when an item in the options menu is selected. Handles navigation/actions based on the selected item.
    // Input: MenuItem item - The menu item that was selected.
    // Output: boolean - True if the event was consumed, false otherwise.
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Step 1: Get the ID of the selected menu item
        int id = item.getItemId();
        // Step 2: Check the ID and perform the corresponding action
        if (id == R.id.menu_log_out) {
            // Step 2.1: If Log Out is selected, remove the "Remember User" flag from SharedPreferences
            SharedPreferences sharedPreferences = requireActivity()
                    .getSharedPreferences(Constants.KEY_REMEMBER_USER, requireActivity().MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(Constants.KEY_REMEMBER_USER, false); // Set flag to false
            editor.apply(); // Apply changes

            // Step 2.2: Clear the global currently selected subtopic
            SubtopicAdapter.currentlySelectedSubtopic = null;
            // Step 2.3: Sign out the user from Firebase Authentication (Optional based on flow)
            mAuth.signOut(); // Optionally sign out the user
            // Step 2.4: Navigate to the LogInActivity
            Intent intent = new Intent(getActivity(), LogInActivity.class); // Use getActivity() or requireActivity()
            startActivity(intent);
            // Step 2.5: Finish the current hosting activity if it exists
            if (getActivity() != null) { // Check if activity is not null
                getActivity().finish(); // Finish the hosting activity
            }
        } else if (id == R.id.menu_go_back) {
            // Step 2.6: If Go Back is selected, get the FragmentManager
            // Pop the fragment back stack
            if (getParentFragmentManager() != null) { // Use getParentFragmentManager() or requireActivity().getSupportFragmentManager()
                // Step 2.6.1: Pop the back stack to navigate to the previous fragment
                getParentFragmentManager().popBackStack();
            }
            // Note: If back stack is empty, no action is taken here. Consider navigating to MainActivity if needed.
        } else if (id == R.id.menu_settings) {
            // Step 2.7: If Settings is selected, navigate to the SettingsActivity
            Intent intent = new Intent(getActivity(), SettingsActivity.class); // Use getActivity() or requireActivity()
            startActivity(intent);
            // Note: Original code also finished the current activity here, which might not be desired depending on back navigation flow.
        } else if (id == R.id.menu_profile) {
            // Step 2.8: If Profile is selected, navigate to the ProfileActivity
            // Optional: Handle profile action
            Intent intent = new Intent(getActivity(), ProfileActivity.class); // Use getActivity() or requireActivity()
            startActivity(intent);
        }
        else if (id == R.id.menu_home) {
            // Step 2.9: If Home is selected, navigate back to MainActivity
            Intent intent = new Intent(getActivity(), MainActivity.class); // Use getActivity() or requireActivity()
            // Step 2.9.1: Clear the global currently selected subtopic (important when going home)
            SubtopicAdapter.currentlySelectedSubtopic = null;
            startActivity(intent);
            // Note: Finishing the activity here might be desired depending on navigation flow, but is not present in original.
        }
        // Step 3: Return true to indicate that the event was consumed
        return true;
    }
}