package com.example.myfinalproject.gamesActivities.ComputerScience;

import android.content.Intent; // Import Intent
import android.content.SharedPreferences; // Import SharedPreferences
import android.os.Bundle; // Import Bundle
import android.util.Log; // Import Log
import android.view.LayoutInflater; // Import LayoutInflater
import android.view.Menu; // Import Menu
import android.view.MenuInflater; // Import MenuInflater
import android.view.MenuItem; // Import MenuItem
import android.view.View; // Import View
import android.view.ViewGroup; // Import ViewGroup
import android.widget.Button; // Import Button
import android.widget.EditText; // Import EditText
import android.widget.RadioGroup; // Import RadioGroup
import android.widget.TextView; // Import TextView
import android.widget.Toast; // Import Toast

import androidx.annotation.NonNull; // Import annotations
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity; // Import AppCompatActivity
import androidx.appcompat.widget.Toolbar; // Import Toolbar
import androidx.core.content.ContextCompat; // Import ContextCompat
import androidx.fragment.app.Fragment; // Import Fragment
import androidx.fragment.app.FragmentManager; // Import FragmentManager

import com.example.myfinalproject.R; // Import R
import com.example.myfinalproject.activities.LogInActivity; // Import activities
import com.example.myfinalproject.activities.MainActivity;
import com.example.myfinalproject.activities.ProfileActivity;
import com.example.myfinalproject.activities.SettingsActivity;
import com.example.myfinalproject.adapters.SubtopicAdapter; // Import SubtopicAdapter
import com.example.myfinalproject.java_classes.Constants; // Import Constants
import com.example.myfinalproject.java_classes.CourseClass; // Import data classes
import com.example.myfinalproject.java_classes.SubTopicClass;
import com.example.myfinalproject.java_classes.UserInfoClass;
import com.google.android.gms.tasks.OnFailureListener; // Import Firebase task listeners
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task; // Import Task
import com.google.firebase.auth.FirebaseAuth; // Import Firebase Auth
import com.google.firebase.auth.FirebaseUser; // Import FirebaseUser
import com.google.firebase.firestore.DocumentReference; // Import Firestore classes
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList; // Import ArrayList
import java.util.Random; // Import Random

// Class: ConditionalsFragment
// Description: A Fragment representing an exercise on computer science conditionals.
// It includes two separate exercises (number check and guessing game) that must
// be completed to update the user's progress for this subtopic in Firestore.
// Input: none (as it's a Fragment, gets data via UI interaction and Firebase)
// Output: Displays UI, handles user interaction, validates exercises, updates Firestore, navigates.
public class ConditionalsFragment extends Fragment {

    // --- Exercise 1 Views (Number Check) ---
    private EditText etNumberInput; // EditText for user to input a number
    private Button btnCheckNumber; // Button to trigger the number check logic
    private TextView tvResult; // TextView to display the result of the number check

    // --- Exercise 2 Views (Guessing Game) ---
    private EditText etGuess; // EditText for user to input a guess
    private Button btnSubmitGuess; // Button to submit the user's guess
    private TextView tvFeedback; // TextView to display feedback (too high/low/correct)
    private TextView tvSuccess; // TextView shown specifically when the guess is correct
    private Button btnFinish;   // Button to complete the entire exercise set

    // --- Game State Variables ---
    private int randomNumber; // The random number the user needs to guess in Exercise 2
    private boolean exercise1Completed = false; // Flag to track if Exercise 1 is completed
    private boolean exercise2Completed = false; // Flag to track if Exercise 2 is completed

    // --- Firebase Variables ---
    private FirebaseAuth mAuth; // Firebase Authentication instance
    private FirebaseFirestore db; // Firestore database instance
    private String userId; // User ID (might be redundant with currentUser.getUid() but used)


    // Function: onCreateView
    // Description: Called to create the view hierarchy for the fragment.
    // Inflates the layout, initializes views, listeners, Firebase, generates a random number,
    // and sets up the toolbar menu.
    // Input: LayoutInflater inflater - The LayoutInflater object that can be used to inflate any views in the fragment.
    // Input: ViewGroup container - If non-null, this is the parent view that the fragment's UI should be attached to.
    // Input: Bundle savedInstanceState - If non-null, this fragment is being re-constructed from a previous saved state.
    // Output: View - The root View of the fragment's layout.
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Step 1: Inflate the layout for this fragment from cs_conditionals_fragment.xml
        View view = inflater.inflate(R.layout.cs_conditionals_fragment, container, false);

        // Step 2: Initialize UI views found in the inflated layout
        initViews(view);
        // Step 3: Initialize event listeners for the UI elements
        initListeners();

        // Step 4: Initialize Firebase Authentication and Firestore instances
        mAuth = FirebaseAuth.getInstance(); // Get Auth instance
        db = FirebaseFirestore.getInstance(); // Get Firestore instance

        // Step 5: Get the current user's UID
        // Note: This assumes the user is already logged in when this fragment is created.
        // A null check might be needed here or earlier in the flow.
        userId = mAuth.getCurrentUser().getUid();

        // Step 6: Generate a random number between 1 and 100 for the guessing game (Exercise 2)
        randomNumber = new Random().nextInt(100) + 1; // nextInt(100) gives 0-99, +1 makes it 1-100

        // Step 7: Indicate that this fragment has its own options menu
        setHasOptionsMenu(true); // Ensure menu options show up

        // Step 8: Get the main activity's Toolbar and set it as the action bar for the fragment
        Toolbar toolbar = requireActivity().findViewById(R.id.toolbarMain); // Find toolbar in the hosting activity
        ((AppCompatActivity) requireActivity()).setSupportActionBar(toolbar); // Set it as the action bar

        // Step 9: Return the root view of the fragment
        return view;
    }

    // Function: initViews
    // Description: Initializes UI elements by finding them in the layout. Organizes finding by exercise.
    // Input: View view - The root view of the fragment's layout.
    // Output: void (Initializes UI views).
    private void initViews(View view) {
        // Step 1: Initialize views for Exercise 1 (Number Check)
        etNumberInput = view.findViewById(R.id.etNumberInput);
        btnCheckNumber = view.findViewById(R.id.btnCheckNumber);
        tvResult = view.findViewById(R.id.tvResult);

        // Step 2: Initialize views for Exercise 2 (Guessing Game)
        etGuess = view.findViewById(R.id.etGuess);
        btnSubmitGuess = view.findViewById(R.id.btnSubmitGuess);
        tvFeedback = view.findViewById(R.id.tvFeedback);
        tvSuccess = view.findViewById(R.id.tvSuccess); // TextView for correct guess success message
        btnFinish = view.findViewById(R.id.finishCondition); // Button to finish the exercises
    }

    // Function: initListeners
    // Description: Sets up click listeners for buttons.
    // Input: none
    // Output: void (Sets up listeners).
    private void initListeners() {
        // Step 1: Set a click listener for the Check Number button (Exercise 1)
        btnCheckNumber.setOnClickListener(new View.OnClickListener() {
            // Function: onClick
            // Description: Called when the Check Number button is clicked. Validates input and
            // checks if the entered number is positive, negative, or zero, displaying the result.
            // Input: View v - The clicked view (the button).
            // Output: void (Validates input, performs number check, updates result TextView).
            @Override
            public void onClick(View v) {
                // Step 1.1: Get the text from the number input EditText and trim whitespace
                String input = etNumberInput.getText().toString().trim();
                // Step 1.2: Check if the input string is empty
                if (input.isEmpty()) {
                    // Step 1.2.1: If empty, display a prompt message
                    tvResult.setText("Enter a number...");
                    // Step 1.2.2: Mark Exercise 1 as not completed
                    exercise1Completed = false;
                    return; // Exit the click listener
                }
                // Step 1.3: Attempt to parse the input string into an integer
                try {
                    int num = Integer.parseInt(input); // Parse the input
                    // Step 1.4: Use if/else if/else statements to check the number's value
                    if (num > 0) {
                        // Step 1.4.1: If positive, set the result text
                        tvResult.setText("The number is positive.");
                    } else if (num < 0) {
                        // Step 1.4.2: If negative, set the result text
                        tvResult.setText("The number is negative.");
                    } else {
                        // Step 1.4.3: If zero, set the result text
                        tvResult.setText("The number is zero.");
                    }
                    // Step 1.5: If parsing and check were successful, mark Exercise 1 as completed
                    exercise1Completed = true;
                } catch (NumberFormatException e) {
                    // Step 1.6: If parsing fails (not a valid number), display an error message
                    tvResult.setText("Invalid number entered.");
                    // Step 1.6.1: Mark Exercise 1 as not completed
                    exercise1Completed = false;
                }
            }
        });

        // Step 2: Set a click listener for the Submit Guess button (Exercise 2)
        btnSubmitGuess.setOnClickListener(new View.OnClickListener() {
            // Function: onClick
            // Description: Called when the Submit Guess button is clicked. Validates input
            // and checks the user's guess against the random number, providing feedback.
            // Input: View v - The clicked view (the button).
            // Output: void (Validates input, performs guess check, updates feedback TextViews).
            @Override
            public void onClick(View v) {
                // Step 2.1: Get the text from the guess EditText and trim whitespace
                String guessStr = etGuess.getText().toString().trim();
                // Step 2.2: Check if the guess string is empty
                if (guessStr.isEmpty()) {
                    // Step 2.2.1: If empty, display a prompt message for feedback
                    tvFeedback.setText("Please enter your guess.");
                    // Step 2.2.2: Mark Exercise 2 as not completed
                    exercise2Completed = false;
                    return; // Exit the click listener
                }
                // Step 2.3: Attempt to parse the guess string into an integer
                try {
                    int guess = Integer.parseInt(guessStr); // Parse the guess
                    // Step 2.4: Use if/else if/else statements to compare the guess to the random number
                    if (guess > randomNumber) {
                        // Step 2.4.1: If guess is too high, set feedback text
                        tvFeedback.setText("Too high! Try again.");
                        // Step 2.4.2: Mark Exercise 2 as not completed
                        exercise2Completed = false;
                    } else if (guess < randomNumber) {
                        // Step 2.4.3: If guess is too low, set feedback text
                        tvFeedback.setText("Too low! Try again.");
                        // Step 2.4.4: Mark Exercise 2 as not completed
                        exercise2Completed = false;
                    } else {
                        // Step 2.4.5: If guess is correct
                        tvFeedback.setText("Correct! You guessed the number!"); // Set correct feedback text
                        tvSuccess.setVisibility(View.VISIBLE); // Make the success message visible
                        // Step 2.4.6: Mark Exercise 2 as completed
                        exercise2Completed = true;
                    }
                } catch (NumberFormatException e) {
                    // Step 2.5: If parsing fails (not a valid number), display an error message
                    tvFeedback.setText("Invalid guess entered.");
                    // Step 2.5.1: Mark Exercise 2 as not completed
                    exercise2Completed = false;
                }
            }
        });

        // Step 3: Set a click listener for the Finish button
        btnFinish.setOnClickListener(new View.OnClickListener() {
            // Function: onClick
            // Description: Called when the Finish button is clicked. Checks if both exercises
            // are completed. If so, updates progress and navigates.
            // Input: View v - The clicked view (the button).
            // Output: void (Checks completion, updates progress, navigates, or shows toast).
            @Override
            public void onClick(View v) {
                // Step 3.1: Check if both exercise completion flags are true
                boolean allCompleted = exercise1Completed && exercise2Completed;
                // Step 3.2: If both exercises are completed
                if (allCompleted) {
                    // Step 3.2.1: Call the helper method to update subtopic progress in Firestore
                    updateSubtopicProgress(); // Update progress in Firestore and finish.
                } else {
                    // Step 3.3: If not all exercises are completed, show a toast message
                    Toast.makeText(getContext(), "Please complete all exercises before finishing.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Function: updateSubtopicProgress
    // Description: Updates the progress for the 'Conditionals' CS subtopic in Firestore to 100%.
    // It retrieves the current user's courses, finds the specific subtopic, sets its progress,
    // saves the modified course list back to Firestore, and navigates back to MainActivity on success.
    // Input: none
    // Output: void (Fetches user data, updates Firestore, navigates, shows feedback).
    private void updateSubtopicProgress() {
        // Step 1: Reset the global currently selected subtopic (optional, depends on app flow)
        SubtopicAdapter.currentlySelectedSubtopic = null;

        // Step 2: Get the currently logged-in Firebase user
        FirebaseUser currentUser = mAuth.getCurrentUser();
        // Step 3: Check if the user is logged in
        if (currentUser == null) {
            // Step 3.1: If not logged in, show a toast and exit the method
            Toast.makeText(getContext(), "User not signed in", Toast.LENGTH_SHORT).show();
            return; // Exit the method
        }

        // Step 4: Get the current user's UID
        String userId = currentUser.getUid();
        // Step 5: Get a document reference to the user's data in Firestore
        DocumentReference userRef = db.collection("users").document(userId);

        // Step 6: Retrieve current user data from Firestore asynchronously
        userRef.get().addOnCompleteListener(task -> {
            // Function: onComplete (OnCompleteListener for Firestore get)
            // Description: Called when the task to get user data completes.
            // Input: Task<DocumentSnapshot> task - The completed task.
            // Output: void (Processes user data, updates subtopic, saves to Firestore, navigates).
            // Step 6.1: Check if the task was successful
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                // Step 6.2: Check if the document exists and is not null
                if (document != null && document.exists()) {
                    // Step 6.3: Convert the document to a UserInfoClass object
                    UserInfoClass userInfo = document.toObject(UserInfoClass.class);
                    // Step 6.4: Check if UserInfo object and its classes list are valid
                    if (userInfo != null && userInfo.getClasses() != null) {
                        // Step 6.5: Get the list of existing courses
                        ArrayList<CourseClass> courses = userInfo.getClasses(); // Existing courses list
                        boolean updated = false; // Flag to track if progress was updated

                        // Step 6.6: Iterate through courses and subtopics to find the target subtopic
                        for (CourseClass course : courses) {
                            if (course.getSubtopics() != null) {
                                for (SubTopicClass subTopic : course.getSubtopics()) {
                                    // Step 6.6.1: Check if the current subtopic matches the target subtopic ('Conditionals')
                                    if (subTopic.getName().equals(Constants.KEY_CS_CONDITIONALS)) {
                                        // Step 6.6.2: Update the progress for this specific subtopic to 100%
                                        subTopic.setProgress(100); // Mark as completed
                                        updated = true; // Set the flag to true
                                        break; // Exit the inner subtopic loop once found
                                    }
                                }
                            }
                            // Step 6.6.3: If the subtopic was updated, exit the outer course loop as well
                            if (updated) break;
                        }

                        // Step 6.7: Update the 'classes' field in the user's Firestore document with the modified courses list
                        userRef.update("classes", courses)
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    // Function: onSuccess (OnSuccessListener for Firestore update)
                                    // Description: Called when the Firestore update succeeds.
                                    // Input: Void aVoid - Placeholder.
                                    // Output: void (Shows success toast and navigates back to MainActivity).
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        // Step 6.7.1.1: Show a toast message indicating progress update success
                                        Toast.makeText(getContext(), "Subtopic progress updated!", Toast.LENGTH_SHORT).show();
                                        // Step 6.7.1.2: Navigate back to MainActivity after successful update
                                        // TODO: If I decide in the future to have sandbox change here
                                        Intent intent = new Intent(requireActivity(), MainActivity.class);
                                        startActivity(intent);
                                        requireActivity().finish(); // Finish the hosting activity
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    // Function: onFailure (OnFailureListener for Firestore update)
                                    // Description: Called when the Firestore update fails.
                                    // Input: Exception e - The exception detailing the failure.
                                    // Output: void (Shows error toast and logs error).
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        // Step 6.7.2.1: Show a toast message with the error details
                                        Toast.makeText(getContext(), "Error updating Firestore: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                        // Step 6.7.2.2: Log the error
                                        Log.e("Firestore", "Error updating subtopic progress", e);
                                        // Note: Navigation might not happen on failure, keeping the user on the current fragment.
                                    }
                                });
                    } else {
                        // Step 6.8: Show a toast if user data or course list is unexpectedly null
                        Toast.makeText(requireContext(), "User data or course list is null.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Step 6.9: Show a toast if the user document is not found in Firestore
                    Toast.makeText(requireContext(), "User document not found.", Toast.LENGTH_SHORT).show();
                }
            } else {
                // Step 6.10: Show a toast and log if fetching user data from Firestore failed
                Toast.makeText(requireContext(), "Error getting user data: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("Firestore", "Error getting user data", task.getException());
            }
        });
    }

    // Function: onCreateOptionsMenu
    // Description: Initializes the options menu for the fragment's toolbar.
    // Input: Menu menu - The options menu.
    // Input: MenuInflater inflater - The inflater to inflate the menu layout.
    // Output: void (Inflates menu).
    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        // Step 1: Call the superclass method
        super.onCreateOptionsMenu(menu, inflater);
        // Step 2: Clear any existing menu items (important for fragments sharing a toolbar)
        menu.clear();
        // Step 3: Inflate the menu layout (R.menu.menu) into the provided Menu object
        inflater.inflate(R.menu.menu, menu);
    }

    // Function: onOptionsItemSelected
    // Description: Called when an item in the options menu is selected. Handles navigation based on the selected item.
    // Input: MenuItem item - The menu item that was selected.
    // Output: boolean - True if the event was consumed, false otherwise.
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Step 1: Get the ID of the selected menu item
        int id = item.getItemId();
        // Step 2: Check the ID and perform the corresponding action
        if (id == R.id.menu_log_out) {
            // Step 2.1: If Log Out is selected, call the logoutUser helper method
            logoutUser();
        } else if (id == R.id.menu_go_back) {
            // Step 2.2: If Go Back is selected, get the FragmentManager from the hosting activity
            FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();

            // Step 2.2.1: Check if there are fragments in the back stack managed by this FragmentManager
            if (fragmentManager.getBackStackEntryCount() > 0) {
                // Step 2.2.1.1: If yes, pop the back stack to go to the previous fragment
                fragmentManager.popBackStack(); // Go back to the previous fragment
            } else {
                // Step 2.2.1.2: If no fragments left in this manager's back stack, navigate back to MainActivity
                Intent intent = new Intent(requireActivity(), MainActivity.class);
                startActivity(intent);
                requireActivity().finish(); // Close current activity (hosting MainActivity)
            }
        } else if (id == R.id.menu_settings) {
            // Step 2.3: If Settings is selected, start the SettingsActivity
            startActivity(new Intent(requireActivity(), SettingsActivity.class));
        } else if (id == R.id.menu_profile) {
            // Step 2.4: If Profile is selected, start the ProfileActivity
            startActivity(new Intent(requireActivity(), ProfileActivity.class));
        } else if (id == R.id.menu_home) {
            // Step 2.5: If Home is selected, navigate back to MainActivity
            Intent intent = new Intent(requireActivity(), MainActivity.class);
            // Step 2.5.1: Clear the global currently selected subtopic (important when going home)
            SubtopicAdapter.currentlySelectedSubtopic = null;
            startActivity(intent);
            // Note: Finishing the activity here might be desired depending on navigation flow, but is not present in original.
        }
        // Step 3: Return true to indicate that the event was consumed
        return true;
    }

    // Function: logoutUser
    // Description: Logs out the currently authenticated user from Firebase, updates shared preferences,
    // clears the global selected subtopic, and navigates back to the LogInActivity.
    // Input: none
    // Output: void (Logs out user, updates state, navigates).
    private void logoutUser() {
        // Step 1: Get SharedPreferences for remembering user login status
        SharedPreferences sharedPreferences = requireActivity()
                .getSharedPreferences(Constants.KEY_REMEMBER_USER, requireActivity().MODE_PRIVATE);
        // Step 2: Get an editor for SharedPreferences
        SharedPreferences.Editor editor = sharedPreferences.edit();
        // Step 3: Set the "Remember User" flag to false
        editor.putBoolean(Constants.KEY_REMEMBER_USER, false);
        // Step 4: Apply the changes to SharedPreferences
        editor.apply();

        // Step 5: Clear the global currently selected subtopic
        SubtopicAdapter.currentlySelectedSubtopic = null;
        // Step 6: Sign out the user from Firebase Authentication
        mAuth.signOut();

        // Step 7: Create an Intent to navigate to the LogInActivity
        Intent intent = new Intent(requireActivity(), LogInActivity.class);
        // Step 8: Start the LogInActivity
        startActivity(intent);
        // Step 9: Finish the current hosting activity (which is MainActivity) to prevent going back
        requireActivity().finish();
    }
}