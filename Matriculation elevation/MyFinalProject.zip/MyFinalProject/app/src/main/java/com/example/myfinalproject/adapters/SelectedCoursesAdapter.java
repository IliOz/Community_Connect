package com.example.myfinalproject.adapters;

import android.annotation.SuppressLint; // Import annotation
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.myfinalproject.R;
import com.example.myfinalproject.java_classes.CourseClass; // Assuming CourseClass is used

import java.util.ArrayList;

// Class: SelectedCoursesAdapter
// Description: Custom ArrayAdapter for displaying a list of selected CourseClass objects,
// typically in a ListView or GridView.
// Input: Requires a Context and an ArrayList of CourseClass objects.
// Output: Provides Views for individual items (selected courses).
public class SelectedCoursesAdapter extends ArrayAdapter<CourseClass> {

    // Function: Constructor
    // Description: Initializes the SelectedCoursesAdapter with the context and the list of courses.
    // Input: Context context - The context of the activity or fragment.
    // Input: ArrayList<CourseClass> courses - The list of CourseClass objects to display.
    // Output: Initializes the adapter.
    public SelectedCoursesAdapter(Context context, ArrayList<CourseClass> courses) {
        // Step 1: Call the superclass constructor
        // Pass the context, the resource ID for the item layout (0 as it's handled in getView), and the list of objects.
        super(context, 0, courses);
    }

    // Function: getView
    // Description: Get a View that displays the data at the specified position in the data set.
    // This method is called to create or reuse a view for each item in the list/grid.
    // Input: int position - The position of the item within the adapter's data set whose view we want.
    // Input: View convertView - The old view to reuse, if possible.
    // Input: ViewGroup parent - The parent that this view will eventually be attached to.
    // Output: View - A View corresponding to the data at the specified position.
    @SuppressLint("SetTextI18n") // Annotation to suppress warning about hardcoded text in setText
    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Step 1: Get the data item (CourseClass object) for this position
        CourseClass course = getItem(position);

        // Step 2: Check if an existing view (convertView) is being reused. If not, inflate a new one.
        if (convertView == null) {
            // Step 2.1: If no view to reuse, inflate the item layout (selected_courses.xml)
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.selected_courses, parent, false);
        }

        // Step 3: Find the TextViews within the inflated item layout by their IDs
        TextView tvCourseName = convertView.findViewById(R.id.tvCourseName); // TextView for course name
        TextView pointsOfStudy = convertView.findViewById(R.id.coursePointsLevel); // TextView for course points/level

        // Step 4: Handle the case where the retrieved course object might be null (shouldn't happen with valid data)
        if (course != null) {
            // Step 4.1: Populate the TextView for the course name with the course's name
            tvCourseName.setText(course.getCourseName());

            // Step 4.2: Populate the TextView for course points. Convert the integer points to a String.
            pointsOfStudy.setText(String.valueOf(course.getPoints()));
        }

        // Step 5: Return the completed view to be rendered on the screen
        return convertView;
    }
}