package com.example.myfinalproject.java_classes;

import java.io.Serializable; // Import Serializable

// Class: SubTopicClass
// Description: Represents a single subtopic within a course. Contains details about
// the subtopic's name, description, its parent topic name, current progress, and selection status.
// It is Serializable to allow passing between components via Intents.
// Input: Data representing the attributes of a subtopic.
// Output: Provides access to the subtopic's attributes and limited modification via setters.
public class SubTopicClass implements Serializable {
    // --- Attributes ---
    private String topicName; // The name of the parent topic (e.g., "Physics", "Chemistry")
    private String name; // The name of the subtopic (e.g., "Kinematic Equations", "Variables")
    private int progress; // Completion percentage of the subtopic (0 to 100)
    private boolean selected; // Flag to indicate if the subtopic is currently selected

    // Function: Constructor (No-argument)
    // Description: Default constructor required for Firebase Firestore object mapping.
    // Input: none
    // Output: Initializes an empty SubTopicClass object.
    public SubTopicClass(){
        // Default constructor
    }

    // Function: Constructor (Parameterized)
    // Description: Initializes a new SubTopicClass object with its name, description, and parent topic name.
    // Progress is initialized to 0, and selected status is initialized to false.
    // Input:
    // String name - The name of the subtopic.
    // String description - A brief description of the subtopic.
    // String topicName - The name of the parent topic.
    // Output: Initializes the object with default progress and selection status.
    public SubTopicClass(String name, String topicName) {
        // Step 1: Assign the provided subtopic name
        this.name = name;
        // Step 3: Initialize progress to 0 (Initially no progress)
        this.progress = 0;
        // Step 4: Initialize selected status to false
        this.selected = false;
        // Step 5: Assign the provided parent topic name
        this.topicName = topicName;
    }

    // --- Getters and Setters ---

    // Function: getTopicName
    // Description: Returns the name of the parent topic.
    // Input: none
    // Output: String - The parent topic name.
    public String getTopicName(){
        return this.topicName;
    }

    // Function: isSelected
    // Description: Returns the selection status of the subtopic.
    // Input: none
    // Output: boolean - True if selected, false otherwise.
    public boolean isSelected() {
        return selected;
    }

    // Function: setSelected
    // Description: Sets the selection status of the subtopic.
    // Input: boolean selected - The new selection status.
    // Output: void (Updates the selected status).
    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    // Function: getName
    // Description: Returns the name of the subtopic.
    // Input: none
    // Output: String - The subtopic name.
    public String getName() {
        return name;
    }

    // Function: setName
    // Description: Sets the name of the subtopic.
    // Input: String name - The new name for the subtopic.
    // Output: void (Updates the name).
    public void setName(String name) {
        this.name = name;
    }

    // Function: getProgress
    // Description: Returns the completion percentage of the subtopic.
    // Input: none
    // Output: int - The progress percentage (0-100).
    public int getProgress() {
        return progress;
    }

    // Function: setProgress
    // Description: Sets the completion percentage of the subtopic. Ensures the progress
    // stays within the valid range of 0 to 100.
    // Input: int progress - The new progress value.
    // Output: void (Updates the progress, clamping it between 0 and 100).
    public void setProgress(int progress) {
        // Step 1: Check if the provided progress is less than 0
        if (progress < 0) {
            // Step 1.1: If less than 0, clamp the progress to 0
            this.progress = 0; // Ensure no negative progress
        }
        // Step 2: Check if the provided progress is greater than or equal to 100
        else if (progress >= 100) {
            // Step 2.1: If 100 or more, clamp the progress to 100
            this.progress = 100; // Cap progress at 100%
        }
        // Step 3: If the progress is between 0 and 100 (inclusive)
        else {
            // Step 3.1: Assign the provided progress value directly
            this.progress = progress;
        }
    }

    // Function: copy
    // Description: Creates a shallow copy of the SubTopicClass object. Creates a new instance
    // and copies the primitive and immutable fields from the current object. Mutable objects
    // like lists would need deep copying if they were present and required independent copies.
    // Input: none
    // Output: SubTopicClass - A new SubTopicClass object with the same values as the original.
    public SubTopicClass copy() {
        // Step 1: Create a new SubTopicClass object using the parameterized constructor,
        // copying name, description, and topicName from the current object.
        SubTopicClass copy = new SubTopicClass(this.name, this.topicName); // Create new object
        // Step 2: Copy the 'progress' primitive field value to the new object.
        copy.setProgress(this.progress); // Copy primitive fields (using setter for validation)
        // Step 3: Copy the 'selected' primitive field value to the new object.
        copy.setSelected(this.selected);   // Copy primitive fields (using setter)
        // Step 4: Return the newly created copy.
        return copy;
    }
}