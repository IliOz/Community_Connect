package com.example.myfinalproject.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myfinalproject.R;
import com.example.myfinalproject.adapters.CoursesRecyclerViewAdapter;
import com.example.myfinalproject.fragments.CourseActionBottomSheetFragment;
import com.example.myfinalproject.java_classes.Constants;
import com.example.myfinalproject.java_classes.CourseClass;
import com.example.myfinalproject.services.MusicPlayer;
import com.example.myfinalproject.java_classes.UserInfoClass;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

/**
 * Class: MainActivity
 * Description: The main activity of the application. Displays a list of courses in a RecyclerView.
 */
public class MainActivity extends AppCompatActivity {
    // Constants
    private static final int NOTIFICATION_ID = 1; // ID for notifications

    // UI Variables
    private Toolbar toolbar; // Toolbar for the activity
    private RecyclerView coursesRecyclerView; // RecyclerView to display courses

    // Adapter
    private CoursesRecyclerViewAdapter coursesAdapter; // Adapter for the RecyclerView

    // Firebase Variables
    private FirebaseUser user; // Currently authenticated Firebase user
    private FirebaseAuth mAuth; // Firebase Authentication instance
    private FirebaseFirestore db; // Firestore database instance

    // Data Variables
    private ArrayList<CourseClass> classes; // List to hold CourseClass objects

    private FloatingActionButton addFab;
    private FloatingActionButton removeFab;

    // Function: onCreate
    // Input: Bundle savedInstanceState - contains data from a previous instance if available
    // Output: void (initializes the activity)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Step 1: Call the superclass onCreate method
        super.onCreate(savedInstanceState);
        // Step 2: Set the activity layout from the XML file
        setContentView(R.layout.activity_main);

        // Step 3: Get Firebase Auth and current user instances
        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();

        // Step 4: Initialize UI views
        initViews();

        // Listen for fragment callbacks
        getSupportFragmentManager().setFragmentResultListener("courses_updated", this, (key, bundle) -> {
            Log.d("MainActivity", "Courses updated, refreshing...");
            fetchUserCourses(); // your method to re-fetch and update UI
        });

        initfabs();

        // Step 5: Initialize and set up the RecyclerView
        coursesRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Step 6: Initialize the list and adapter for courses
        classes = new ArrayList<>(); // Initialize the list
        coursesAdapter = new CoursesRecyclerViewAdapter(this, classes); // Pass 'this' as context
        coursesRecyclerView.setAdapter(coursesAdapter); // Set the adapter to the RecyclerView

        // Step 7: Fetch courses from Firestore
        getCourses(); // Call getCourses() to load data from Firestore

        // Step 8: Start background music service
        Intent serviceIntent = new Intent(this, MusicPlayer.class);
        serviceIntent.setAction(Constants.ACTION_PLAY);
        startService(serviceIntent);
    }

    // Function: fetchUserCourses
// Description: Reloads the user's course list from Firestore and updates the RecyclerView
    private void fetchUserCourses() {
        if (user == null) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LogInActivity.class));
            finish();
            return;
        }

        DocumentReference userRef = FirebaseFirestore.getInstance()
                .collection("users").document(user.getUid());

        userRef.get().addOnSuccessListener(documentSnapshot -> {
            if (documentSnapshot.exists()) {
                UserInfoClass userInfo = documentSnapshot.toObject(UserInfoClass.class);
                if (userInfo != null && userInfo.getClasses() != null) {
                    classes.clear();
                    classes.addAll(userInfo.getClasses());
                    coursesAdapter.notifyDataSetChanged();
                    Log.d("MainActivity", "Courses updated.");
                } else {
                    Log.w("MainActivity", "Classes list is null.");
                }
            } else {
                Log.w("MainActivity", "User document not found.");
            }
        }).addOnFailureListener(e -> {
            Log.e("MainActivity", "Failed to fetch courses", e);
            Toast.makeText(this, "Failed to fetch courses", Toast.LENGTH_SHORT).show();
        });
    }


    // Function: initViews
    // Input: none
    // Output: void (initializes UI elements by finding them in the layout and setting up the toolbar/recycler view basics)
    private void initViews() {
        // Step 1: Find the courses RecyclerView by its ID
        coursesRecyclerView = findViewById(R.id.recyclerView_courses);

        // Step 2: Set the layout manager for the RecyclerView (vertical list)
        coursesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        // Step 3: Initialize the list and adapter (adapter setup is also done in onCreate, this might be redundant or for clarity)
        classes = new ArrayList<>();
        coursesAdapter = new CoursesRecyclerViewAdapter(this, classes);
        coursesRecyclerView.setAdapter(coursesAdapter); // Set the adapter

        // Step 4: Find the Toolbar by its ID
        toolbar = findViewById(R.id.toolbarMain);
        // Step 5: Set the Toolbar title (empty in this case)
        toolbar.setTitle("");
        // Step 6: Set the Toolbar as the activity's action bar
        setSupportActionBar(toolbar);

        addFab = findViewById(R.id.fab_add_course);
        removeFab = findViewById(R.id.fab_remove_course);
    }


    private void initfabs(){
        addFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CourseActionBottomSheetFragment fragment = new CourseActionBottomSheetFragment();
                Bundle args = new Bundle();
                args.putString("mode", "add");
                fragment.setArguments(args);
                fragment.show(getSupportFragmentManager(), fragment.getTag());
            }
        });

        removeFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CourseActionBottomSheetFragment fragment = new CourseActionBottomSheetFragment();
                Bundle args = new Bundle();
                args.putString("mode", "remove");
                fragment.setArguments(args);
                fragment.show(getSupportFragmentManager(), fragment.getTag());
            }
        });
    }

    /**
     * Function: getCourses
     * Input: none
     * Output: void (Retrieves the user's courses from Firestore and updates the RecyclerView)
     */
    private void getCourses() {
        // Step 1: Check if the user is currently signed in
        if (user == null) {
            // Step 1.1: If not signed in, handle the case (show toast, redirect to login)
            Toast.makeText(this, "User not signed in.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, LogInActivity.class); // Create login intent
            startActivity(intent); // Start login activity
            finish(); // Prevent going back to MainActivity without logging in.
            return; // Exit the function
        }
        // Step 2: Get the current user's unique ID
        String userId = user.getUid();
        // Step 3: Get Firestore instance
        db = FirebaseFirestore.getInstance();
        // Step 4: Get a reference to the user's document in the "users" collection
        DocumentReference userRef = db.collection("users").document(userId);

        // Step 5: Fetch the user document data from Firestore asynchronously
        userRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                // Step 5.1: Check if the task to get the document was successful
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    // Step 5.2: Check if the document exists
                    if (document.exists()) {
                        // Step 5.3: Convert the Firestore document to a UserInfoClass object
                        UserInfoClass userInfo = document.toObject(UserInfoClass.class);

                        // Step 5.4: Check if the UserInfo object and its classes list are not null
                        if (userInfo != null && userInfo.getClasses() != null) {
                            // Step 5.4.1: Clear the current classes list
                            classes.clear();
                            // Step 5.4.2: Add all fetched courses to the list
                            classes.addAll(userInfo.getClasses());
                            // Step 5.4.3: Update the adapter with the new list of courses
                            coursesAdapter.setCourses(classes);
                            // Step 5.4.4: Notify the adapter that the data set has changed to refresh the UI
                            coursesAdapter.notifyDataSetChanged();
                        } else {
                            // Step 5.4.5: Log and show message if UserInfo or classes list is null
                            Log.d("Firestore", "UserInfo or classes is null");
                            Toast.makeText(MainActivity.this, "No course data found.", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        // Step 5.5: Log and show message if the user document does not exist
                        Log.d("Firestore", "No such document");
                        Toast.makeText(MainActivity.this, "User document not found.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Step 5.6: Log and show message if the task to get the document failed
                    Log.d("Firestore", "get failed with ", task.getException());
                    Toast.makeText(MainActivity.this, "Error getting data: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    // Function: onCreateOptionsMenu
    // Input: Menu menu - The options menu in which you place your items.
    // Output: boolean - You must return true for the menu to be displayed; if you return false it will not be shown.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Step 1: Inflate the menu layout file into the Menu object
        getMenuInflater().inflate(R.menu.menu, menu);

        // Step 2: Find the "Home" menu item
        MenuItem home = menu.findItem(R.id.menu_home);
        // Step 3: Hide the "Home" menu item on the Home screen itself
        home.setVisible(false);

        // Step 4: Return true to indicate that the options menu should be displayed
        return super.onCreateOptionsMenu(menu);
    }

    // Function: onOptionsItemSelected
    // Input: MenuItem item - The menu item that was selected.
    // Output: boolean - Return false to allow normal menu processing to proceed, true to consume it here.
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Step 1: Check the ID of the selected menu item
        if (item.getItemId() == R.id.menu_log_out) {
            // Step 1.1: If Log Out is selected, sign out the user from Firebase Auth
            mAuth.signOut();
            // Step 1.2: Create an Intent to navigate to the LogInActivity
            Intent intent = new Intent(MainActivity.this, LogInActivity.class);
            // Step 1.3: Start the LogInActivity
            startActivity(intent);
            // Step 1.4: Finish the current activity (MainActivity) to prevent going back without logging in
            finish();
            // Step 1.5: Consume the event
            return true;

        } else if (item.getItemId() == R.id.menu_profile) {
            // Step 2.1: If Profile is selected, create an Intent to navigate to the ProfileActivity
            Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
            // Step 2.2: Add an extra flag indicating this navigation is from an activity (for potential back navigation logic)
            intent.putExtra("fromActivity", true);
            // Step 2.3: Start the ProfileActivity
            startActivity(intent);
            // Step 2.4: Consume the event
            return true;

        } else if (item.getItemId() == R.id.menu_settings) {
            // Step 3.1: If Settings is selected, create an Intent to navigate to the SettingsActivity
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            // Step 3.2: Start the SettingsActivity
            startActivity(intent);
            // Step 3.3: Consume the event
            return true;
        } else if (item.getItemId() == R.id.menu_go_back) {
            // Step 4.1: If Go Back is selected, get the FragmentManager
            FragmentManager fragmentManager = getSupportFragmentManager();

            // Step 4.2: Check if there are any fragments in the back stack
            if (fragmentManager.getBackStackEntryCount() > 0) {
                // Step 4.2.1: If there's a fragment in the back stack, pop it to go back to the previous fragment
                fragmentManager.popBackStack();
            } else {
                // Step 4.2.2: If no fragments, check if the activity was started with a "fromActivity" flag
                if (getIntent().getBooleanExtra("fromActivity", false)) {
                    // Step 4.2.2.1: If started from another activity, finish this activity to go back
                    finish(); // Close MainActivity and go back
                } else {
                    // Step 4.2.2.2: If not started from another activity (e.g., launched directly or only activity left), perform default action (Log out)
                    // Step 4.2.2.2.1: Get SharedPreferences
                    SharedPreferences sharedPreferences = getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE);
                    // Step 4.2.2.2.2: Set "Remember User" to false
                    sharedPreferences.edit().putBoolean(Constants.KEY_REMEMBER_USER, false).apply();
                    // Step 4.2.2.2.3: Create Intent for LogInActivity
                    Intent intent = new Intent(MainActivity.this, LogInActivity.class);
                    // Step 4.2.2.2.4: Start LogInActivity
                    startActivity(intent);
                    // Step 4.2.2.2.5: Finish MainActivity
                    finish(); // Prevent going back
                }
            }
            // Step 4.3: Consume the event
            return true;
        }

        // Step 5: If the item ID doesn't match any specific handling, call the superclass method for default handling
        return super.onOptionsItemSelected(item);
    }
}