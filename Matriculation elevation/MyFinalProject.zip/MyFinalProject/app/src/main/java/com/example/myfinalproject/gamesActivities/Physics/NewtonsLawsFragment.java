package com.example.myfinalproject.gamesActivities.Physics;

import android.content.Intent; // Import Intent
import android.content.SharedPreferences; // Import SharedPreferences
import android.os.Bundle; // Import Bundle
import android.util.Log; // Import Log
import android.view.LayoutInflater; // Import LayoutInflater
import android.view.Menu; // Import Menu
import android.view.MenuInflater; // Import MenuInflater
import android.view.MenuItem; // Import MenuItem
import android.view.View; // Import View
import android.view.ViewGroup; // Import ViewGroup
import android.widget.Button; // Import Button
import android.widget.Toast; // Import Toast

import androidx.annotation.NonNull; // Import annotations
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity; // Import AppCompatActivity
import androidx.appcompat.widget.Toolbar; // Import Toolbar
import androidx.fragment.app.Fragment; // Import Fragment

import com.example.myfinalproject.R; // Import R
import com.example.myfinalproject.activities.LogInActivity; // Import activities
import com.example.myfinalproject.activities.MainActivity;
import com.example.myfinalproject.activities.ProfileActivity;
import com.example.myfinalproject.activities.SettingsActivity;
import com.example.myfinalproject.adapters.SubtopicAdapter; // Import SubtopicAdapter
import com.example.myfinalproject.java_classes.Constants; // Import Constants
import com.example.myfinalproject.java_classes.CourseClass; // Import data classes
import com.example.myfinalproject.java_classes.SubTopicClass;
import com.example.myfinalproject.java_classes.UserInfoClass;
import com.google.android.gms.tasks.OnFailureListener; // Import Firebase task listeners
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task; // Import Task
import com.google.firebase.auth.FirebaseAuth; // Import Firebase Auth
import com.google.firebase.auth.FirebaseUser; // Import FirebaseUser
import com.google.firebase.firestore.DocumentReference; // Import Firestore classes
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList; // Import ArrayList

// Class: NewtonsLawsFragment
// Description: A Fragment representing content related to Newton's Laws of Physics.
// It serves as an introductory screen for this subtopic and provides a button
// to proceed to the next lesson/exercise. Clicking the button updates user progress in Firestore.
// Input: none (as it's a Fragment, interacts via UI and Firebase)
// Output: Displays introductory content, handles button click, updates Firestore, navigates.
public class NewtonsLawsFragment extends Fragment {

    // --- UI Variables ---
    private Button continueButton; // Button to proceed to the next subtopic
    private Toolbar toolbar; // Toolbar reference (Note: toolbar setup also happens in onCreateView)

    // --- Firebase Variables ---
    private FirebaseAuth mAuth; // Firebase Authentication instance
    private FirebaseFirestore firestore; // Firestore database instance
    // userId variable declared but not used in the provided methods (user UID is obtained via mAuth.getCurrentUser())


    // Function: onCreateView
    // Description: Called to create the view hierarchy for the fragment.
    // Inflates the layout, initializes views, listeners, Firebase, and sets up the toolbar menu.
    // Input: LayoutInflater inflater - The LayoutInflater object that can be used to inflate any views in the fragment.
    // Input: ViewGroup container - If non-null, this is the parent view that the fragment's UI should be attached to.
    // Input: Bundle savedInstanceState - If non-null, this fragment is being re-constructed from a previous saved state.
    // Output: View - The root View of the fragment's layout.
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Step 1: Inflate the layout for this fragment from activity_physics_game.xml
        View view = inflater.inflate(R.layout.activity_physics_game, container, false);

        // Step 2: Initialize UI views and Firebase instances
        initializeUI(view);
        // Step 3: Set up event listeners for UI elements
        setupListeners();
        // Step 4: Indicate that this fragment has its own options menu
        setHasOptionsMenu(true); // IMPORTANT: Enables menu callbacks

        // Step 5: Get the main activity's Toolbar and set it as the action bar for the fragment
        // Note: This step seems to duplicate part of initializeUI, but is often necessary
        // in fragments using the activity's toolbar. The `initializeUI` version finds the toolbar
        // *within the fragment's layout* (R.id.toolbarMain which should likely be in the activity),
        // while this version finds it *within the activity's layout* (R.id.toolbarMain).
        // The version using `requireActivity().findViewById(R.id.toolbarMain)` is more likely correct
        // if the toolbar is in the activity's main layout.
        Toolbar toolbar = requireActivity().findViewById(R.id.toolbarMain); // Get the Toolbar object from the hosting Activity
        ((AppCompatActivity) requireActivity()).setSupportActionBar(toolbar); // Set it as the action bar for the fragment

        // Step 6: Return the root view of the fragment
        return view;
    }

    // Function: initializeUI
    // Description: Initializes UI elements by finding them in the layout and initializes Firebase instances.
    // Also attempts to set up the toolbar as the activity's support action bar.
    // Input: View view - The root view of the fragment's layout.
    // Output: void (Initializes UI views and Firebase, sets up toolbar).
    private void initializeUI(View view) {
        // Step 1: Find and assign the Toolbar (Note: This assumes R.id.toolbarMain is in the fragment's layout, which might conflict with the activity's toolbar)
        toolbar = view.findViewById(R.id.toolbarMain); // Potential conflict if toolbar is only in Activity layout

        // Step 2: Set the toolbar as the hosting Activity's support action bar
        // Use requireActivity() to get a non-null reference to the hosting activity
        AppCompatActivity activity = (AppCompatActivity) requireActivity();
        activity.setSupportActionBar(toolbar); // Set the toolbar found in the fragment layout

        // Step 3: Hide the default title from the action bar if it was set successfully
        if (activity.getSupportActionBar() != null) {
            activity.getSupportActionBar().setDisplayShowTitleEnabled(false); // Hide the toolbar title
        }

        // Step 4: Find and assign the Continue button
        continueButton = view.findViewById(R.id.continueButton1); // Note: Assumes button ID from layout

        // Step 5: Initialize Firebase Authentication and Firestore instances
        mAuth = FirebaseAuth.getInstance(); // Get Auth instance
        firestore = FirebaseFirestore.getInstance(); // Get Firestore instance
        // currentUser variable is initialized implicitly via mAuth.getCurrentUser() when needed.
    }

    // Function: setupListeners
    // Description: Sets up click listeners for the Continue button.
    // Clicking the button updates subtopic progress in Firestore and navigates to the next fragment.
    // Input: none
    // Output: void (Sets up listeners).
    private void setupListeners() {
        // Step 1: Set a click listener for the Continue button
        continueButton.setOnClickListener(new View.OnClickListener() {
            // Function: onClick
            // Description: Called when the Continue button is clicked. Updates subtopic progress and navigates to the next fragment.
            // Input: View view - The clicked view (the button).
            // Output: void (Updates progress and navigates).
            @Override
            public void onClick(View view) {
                // Step 1.1: Update the subtopic progress in Firestore
                updateSubtopicProgress();
                // Step 1.2: Transition to the next fragment (KinematicEquationFragment) using the parent fragment manager
                getParentFragmentManager().beginTransaction() // Use the parent fragment manager
                        .replace(R.id.fragment_container_main, new KinematicEquationFragment()) // Replace current fragment with the new one
                        .addToBackStack(null) // Optional: Add the current fragment to the back stack so user can navigate back
                        .commit(); // Commit the transaction
            }
        });
    }

    // Function: updateSubtopicProgress
    // Description: Updates the progress for the 'Newton's Laws' Physics subtopic in Firestore to 100%.
    // It retrieves the current user's courses, finds the specific subtopic, sets its progress,
    // saves the modified course list back to Firestore, and shows a toast message on success or failure.
    // Includes checks for user authentication.
    // Input: none
    // Output: void (Fetches user data, updates Firestore, shows feedback).
    private void updateSubtopicProgress() {
        // Step 1: Get the currently logged-in Firebase user
        FirebaseUser currentUser = mAuth.getCurrentUser(); // Use mAuth to get the current user

        // Step 2: Check if the user is signed in
        if (currentUser == null) {
            // Step 2.1: If user is not signed in, show a toast and exit the method
            Toast.makeText(getContext(), "User not signed in", Toast.LENGTH_SHORT).show();
            return; // Exit the method
        }

        // Step 3: Get the user's UID
        String userId = currentUser.getUid();
        // Step 4: Get a document reference to the user's data in Firestore
        DocumentReference userRef = firestore.collection("users").document(userId); // Use firestore instance

        // Step 5: Retrieve current user data from Firestore asynchronously using addOnCompleteListener
        // Get current user data from Firestore.
        userRef.get().addOnCompleteListener(task -> {
            // Function: onComplete (OnCompleteListener for Firestore get)
            // Description: Called when the task to get user data completes.
            // Input: Task<DocumentSnapshot> task - The completed task.
            // Output: void (Processes user data, updates subtopic, saves to Firestore, shows feedback).
            // Step 5.1: Check if the task was successful
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                // Step 5.2: Check if the document exists and is not null
                if (document != null && document.exists()) {
                    // Step 5.3: Convert the document to a UserInfoClass object
                    UserInfoClass userInfo = document.toObject(UserInfoClass.class);
                    // Step 5.4: Check if UserInfo object and its classes list are valid
                    if (userInfo != null && userInfo.getClasses() != null) {
                        // Step 5.5: Get the list of existing courses (creates a local copy/reference)
                        ArrayList<CourseClass> courses = userInfo.getClasses();
                        boolean updated = false; // Flag to track if progress was updated
                        // Step 5.6: Find the specific subtopic ('Newton's Laws') and update its progress
                        // Find and update the specific subtopic.
                        for (CourseClass course : courses) {
                            if (course.getSubtopics() != null) { // Null Check for subtopics list
                                for (SubTopicClass subTopic : course.getSubtopics()) {
                                    // Step 5.6.1: Check if the current subtopic matches the target subtopic name
                                    if (subTopic.getName().equals(Constants.KEY_PHYSICS_NEWTONS_LAWS)) {
                                        // Step 5.6.2: Set the progress for this specific subtopic to 100%
                                        subTopic.setProgress(100); // Mark as completed
                                        updated = true; // Set the flag to true
                                        break; // Exit the inner loop once found.
                                    }
                                }
                            }
                            // Step 5.6.3: If the subtopic was updated, exit the outer course loop as well
                            if (updated) break;
                        }
                        // Step 5.7: Update the 'classes' field in the user's Firestore document with the modified courses list
                        // Update the courses list in Firestore.
                        userRef.update("classes", courses)
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    // Function: onSuccess (OnSuccessListener for Firestore update)
                                    // Description: Called when the Firestore update succeeds.
                                    // Input: Void aVoid - Placeholder.
                                    // Output: void (Shows success toast).
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        // Step 5.7.1.1: Show a toast message indicating progress update success
                                        Toast.makeText(getContext(), "Subtopic progress updated!", Toast.LENGTH_SHORT).show();
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    // Function: onFailure (OnFailureListener for Firestore update)
                                    // Description: Called when the Firestore update fails.
                                    // Input: Exception e - The exception detailing the failure.
                                    // Output: void (Shows error toast and logs error).
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        // Step 5.7.2.1: Show a toast message with the error details
                                        Toast.makeText(getContext(), "Error updating Firestore: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                        // Step 5.7.2.2: Log the error
                                        Log.e("Firestore", "Error updating subtopic progress", e);
                                    }
                                });
                    } else {
                        // Step 5.8: Show a toast if user data or course list is unexpectedly null
                        Toast.makeText(requireContext(), "User data or course list is null.", Toast.LENGTH_SHORT).show(); // Use requireContext()
                    }
                } else {
                    // Step 5.9: Show a toast if the user document is not found in Firestore
                    Toast.makeText(requireContext(), "User document not found.", Toast.LENGTH_SHORT).show(); // Use requireContext()
                }
            } else {
                // Step 5.10: Show a toast and log if fetching user data from Firestore failed
                Toast.makeText(requireContext(), "Error getting user data: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show(); // Use requireContext()
                Log.e("Firestore", "Error getting user data", task.getException());
            }
        });
    }

    // Function: onResume
    // Description: Called when the fragment is visible to the user and actively running.
    // Refreshes the options menu.
    // Input: none
    // Output: void (Refreshes menu).
    @Override
    public void onResume() {
        // Step 1: Call the superclass onResume method
        super.onResume();
        // Step 2: Invalidate the options menu to trigger onCreateOptionsMenu and refresh its state/visibility
        requireActivity().invalidateOptionsMenu(); // Refresh menu visibility
    }

    // Function: onCreateOptionsMenu
    // Description: Initializes the options menu for the fragment's toolbar.
    // Makes the Home menu item visible.
    // Input: Menu menu - The options menu.
    // Input: MenuInflater inflater - The inflater to inflate the menu layout.
    // Output: void (Inflates menu and sets Home item visibility).
    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        // Step 1: Call the superclass method (usually clears and inflates the base menu)
        super.onCreateOptionsMenu(menu, inflater);
        // Note: Original code in other fragments clears and reinflates here.
        // Consider inflating only once in the hosting activity if menu is consistent.

        // Step 2: Find the Home menu item
        MenuItem home = menu.findItem(R.id.menu_home);
        // Step 3: Make the Home menu item visible
        home.setVisible(true);
    }

    // Function: onOptionsItemSelected
    // Description: Called when an item in the options menu is selected. Handles navigation/actions based on the selected item.
    // Input: MenuItem item - The menu item that was selected.
    // Output: boolean - True if the event was consumed, false otherwise.
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Step 1: Get the ID of the selected menu item
        int id = item.getItemId();

        // Step 2: Check the ID and perform the corresponding action
        if (id == R.id.menu_log_out) {
            // Step 2.1: Handle Log Out action: Remove "Remember Me" flag from SharedPreferences
            // Remove remember me using requireActivity()
            SharedPreferences sharedPreferences = requireActivity().getSharedPreferences(Constants.PREF_NAME, requireActivity().MODE_PRIVATE); // Use Constants.PREF_NAME
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(Constants.KEY_REMEMBER_USER, false); // Set flag to false
            editor.apply(); // Apply changes

            // Step 2.2: Clear the global currently selected subtopic
            SubtopicAdapter.currentlySelectedSubtopic = null;

            // Step 2.3: Sign out the user from Firebase Authentication
            mAuth.signOut();

            // Step 2.4: Navigate to the LogInActivity
            Intent intent = new Intent(getActivity(), LogInActivity.class); // Use getActivity()
            startActivity(intent);
            // Step 2.5: Finish the current hosting activity if it exists
            if (getActivity() != null) { // Check if activity is not null
                getActivity().finish();
            }

            return true; // Consume the event
        } else if (id == R.id.menu_go_back) {
            // Step 2.6: Handle Go Back action: Finish the current hosting activity to go back
            // Note: This finishes the *Activity*, not just the fragment. If you intended to pop the fragment back stack,
            // use getParentFragmentManager().popBackStack() instead.
            if (getActivity() != null) { // Check if activity is not null
                getActivity().finish(); // Close the current activity and go back
            }
            return true; // Consume the event
        } else if (id == R.id.menu_settings) {
            // Step 2.7: Handle Settings action: Navigate to the SettingsActivity
            // Navigate to MainActivity
            Intent intent = new Intent(getActivity(), SettingsActivity.class); // Use getActivity()
            startActivity(intent);
            // Note: Original code in other fragments sometimes finishes the current activity here. Review desired flow.
            return true; // Consume the event
        } else if (id == R.id.menu_profile) {
            // Step 2.8: Handle Profile action: Navigate to the ProfileActivity
            Intent intent = new Intent(getActivity(), ProfileActivity.class); // Use getActivity()
            startActivity(intent);
            return true; // Consume the event
        } else if (id == R.id.menu_home) {
            // Step 2.9: Handle Home action: Navigate back to MainActivity
            Intent intent = new Intent(getActivity(), MainActivity.class); // Use getActivity()
            // Step 2.9.1: Clear the global currently selected subtopic (important when going home)
            SubtopicAdapter.currentlySelectedSubtopic = null;
            startActivity(intent);
            // Note: Finishing the activity here might be desired depending on navigation flow, but is not present in original.
            return true; // Consume the event
        }

        // Step 3: If the item ID doesn't match any specific handling, call the superclass method for default handling
        return super.onOptionsItemSelected(item);
    }
}