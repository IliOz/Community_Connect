package com.example.myfinalproject.java_classes;

// Class: Song
// Description: Represents a single song with a title and a resource identifier (ID).
// This class is used to manage song data within the application, particularly for the MusicPlayer service.
// Input: Data representing a song's title and its resource ID.
// Output: Provides access to the song's title and identifier.
public class Song {
    // --- Song Attributes ---
    private String title; // The title of the song
    private int identifier; // The resource ID of the song file (e.g., R.raw.mysong)

    // Function: Constructor
    // Description: Initializes a new Song object with a title and a resource identifier.
    // Input:
    // String title - The title of the song.
    // int identifier - The resource ID of the song file.
    // Output: Initializes the object.
    public Song(String title, int identifier) {
        // Step 1: Assign the provided title to the class variable
        this.title = title;
        // Step 2: Assign the provided identifier (resource ID) to the class variable
        this.identifier = identifier;
    }

    // --- Getters ---

    // Function: getTitle
    // Description: Returns the title of the song.
    // Input: none
    // Output: String - The song title.
    public String getTitle() {
        return title;
    }

    // Function: getIdentifier
    // Description: Returns the resource identifier (ID) of the song file.
    // Input: none
    // Output: int - The song resource ID.
    public int getIdentifier() {
        return identifier;
    }

    // Function: toString
    // Description: Returns a string representation of the Song object, which is simply its title.
    // Useful for displaying the song in lists or logs.
    // Input: none
    // Output: String - The title of the song.
    @Override
    public String toString() {
        // Step 1: Return the song's title
        return title;
    }
}