package com.example.myfinalproject.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.myfinalproject.R;
import com.example.myfinalproject.adapters.CustomGridListeners;
import com.example.myfinalproject.adapters.IconAdapter;
import com.example.myfinalproject.adapters.SelectedCoursesAdapter;
import com.example.myfinalproject.fragments.LoadingFragment;
import com.example.myfinalproject.java_classes.Constants;
import com.example.myfinalproject.java_classes.CourseClass;
import com.example.myfinalproject.java_classes.SubTopicClass;
import com.example.myfinalproject.java_classes.UserInfoClass;
import com.example.myfinalproject.java_classes.ValidationManager;
import com.example.myfinalproject.services.MusicPlayer;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

/**
 * Class: SignUpActivity
 * Description: Manages sign-up: icon grid, course list, validation, and user creation.
 */
public class SignUpActivity extends AppCompatActivity {

    private static final String TAG = "SignUpActivity";

    private ListView listViewSelectedCourses;
    private GridView gridViewIcons;
    private Toolbar toolbar;
    private EditText usernameInput, passwordInput, emailInput;
    private Button btnSignup;

    private ArrayList<CourseClass> selectedCourses;
    private ArrayList<CourseClass> courseList;
    private CustomGridListeners customGridListeners;

    private FirebaseAuth mAuth;
    private FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        // Initialize all views and components in the activity
        initViews();
        // Set up the toolbar to provide a consistent navigation experience
        setupToolbar();
        // Set up the icons grid to display and select user icons
        setupIconsGrid();
        // Initialize and populate the list of courses for the user to select
        setupCoursesList();
        // Set up the sign-up button, ensuring all fields are valid before proceeding
        setupSignupButton();
        // Start playing background music
        //startMusic();
//        Intent intent = new Intent(SignUpActivity.this, MusicPlayer.class);
//        intent.setAction("PLAY");
//        SignUpActivity.this.startService(intent);

    }

    /**
     * Function Name: initViews
     * Description  : Binds UI elements and initializes Firebase instances.
     * Input        : None
     * Output       : None
     */
    private void initViews() {
        // Bind the EditText and Button elements from the layout to the Java variables
        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        emailInput = findViewById(R.id.emailInput);
        btnSignup = findViewById(R.id.btn_signup);
        listViewSelectedCourses = findViewById(R.id.listview_selected_courses);
        gridViewIcons = findViewById(R.id.gridview_icons);
        toolbar = findViewById(R.id.toolbarSignUp);

        // Initialize Firebase Auth and Firestore instances for authentication and data storage
        mAuth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
    }

    /**
     * Function Name: startMusic
     * Description  : Starts background music via service.
     * Input        : None
     * Output       : None
     */
    private void startMusic() {
        // Create an intent to start the music service
        Intent serviceIntent = new Intent(this, MusicPlayer.class);
        // Pass the action 'PLAY' to the music service to start music playback
        serviceIntent.putExtra("Action", "PLAY");
        startService(serviceIntent); // Start the service to play music
    }

    /**
     * Function Name: setupToolbar
     * Description  : Sets up the toolbar for the activity, enabling navigation support.
     * Input        : None
     * Output       : None
     */
    private void setupToolbar() {
        // Set the toolbar as the action bar to provide navigation and options
        setSupportActionBar(toolbar);
    }

    /**
     * Function Name: setupIconsGrid
     * Description  : Initializes the icon grid with a single visible icon and sets up click listener.
     * Input        : None
     * Output       : None
     */
    private void setupIconsGrid() {
        // Prepare the full list of icons available for the user to choose from
        ArrayList<Integer> fullIconList = new ArrayList<>();
        fullIconList.add(R.drawable.user_icon1);
        fullIconList.add(R.drawable.user_icon2);
        fullIconList.add(R.drawable.user_icon3);

        // Initialize the initial list with only one icon for the initial view
        ArrayList<Integer> initialIconList = new ArrayList<>();
        if (!fullIconList.isEmpty()) {
            initialIconList.add(fullIconList.get(0)); // Show the first icon initially
        }

        // Create and set the adapter for the GridView
        IconAdapter iconAdapter = new IconAdapter(this, initialIconList);
        gridViewIcons.setAdapter(iconAdapter);
        gridViewIcons.setNumColumns(1); // Set the grid to have a single column

        // Initialize the custom listener for icon selection
        customGridListeners = new CustomGridListeners(this);
        customGridListeners.setFullIconList(fullIconList); // Pass the full list to the listener

        // Set up the click listener for grid item selection
        gridViewIcons.setOnItemClickListener(
                customGridListeners.getIconClickListener(gridViewIcons, iconAdapter)
        );
    }

    /**
     * Function Name: setupCoursesList
     * Description  : Populates the list with courses and sets up course selection logic.
     * Input        : None
     * Output       : None
     */
    private void setupCoursesList() {
        // Initialize the lists for selected courses and all available courses
        selectedCourses = new ArrayList<>();
        courseList = new ArrayList<>();

        // Add Physics course and its sub-topics to the list
        ArrayList<SubTopicClass> physics = new ArrayList<>();
        physics.add(new SubTopicClass(Constants.KEY_PHYSICS_NEWTONS_LAWS, "Learn Newton's laws.", Constants.KEY_PHYSICS));
        physics.add(new SubTopicClass(Constants.KEY_PHYSICS_KINEMATIC_EQUATIONS, "Study motion.", Constants.KEY_PHYSICS));
        physics.add(new SubTopicClass(Constants.KEY_PHYSICS_MASTERING_FRICTION, "Understand friction.", Constants.KEY_PHYSICS));
        physics.add(new SubTopicClass(Constants.KEY_PHYSICS_SANDBOX, "Practice sandbox.", Constants.KEY_PHYSICS));
        CourseClass pCourse = new CourseClass(Constants.KEY_PHYSICS, "Become Physics expert", 3, 5, physics);

        // Add Computer Science course and its sub-topics to the list
        ArrayList<SubTopicClass> cs = new ArrayList<>();
        cs.add(new SubTopicClass(Constants.KEY_CS_INTRODUCTION, "Course intro.", Constants.KEY_CS));
        cs.add(new SubTopicClass(Constants.KEY_CS_VARIABLES, "Store variables.", Constants.KEY_CS));
        cs.add(new SubTopicClass(Constants.KEY_CS_VARIABLES_QUIZ, "Quiz yourself.", Constants.KEY_CS));
        cs.add(new SubTopicClass(Constants.KEY_CS_CONDITIONALS, "If statements.", Constants.KEY_CS));
        CourseClass csCourse = new CourseClass(Constants.KEY_CS, "Become Java expert", 3, 5, cs);

        // Add the courses to the list of available courses
        courseList.add(pCourse);
        courseList.add(csCourse);

        // Set up the adapter to display the courses in the ListView
        SelectedCoursesAdapter adapter = new SelectedCoursesAdapter(this, courseList);
        listViewSelectedCourses.setAdapter(adapter);

        // Set up the click listener for selecting courses
        listViewSelectedCourses.setOnItemClickListener(
                customGridListeners.getCourseClickListener(selectedCourses)
        );
    }

    /**
     * Function Name: setupSignupButton
     * Description  : Handles signup button logic including validation and sending data to fragment.
     * Input        : None
     * Output       : None
     */
    private void setupSignupButton() {
        // Set the OnClickListener for the signup button
        btnSignup.setOnClickListener(v -> {
            // Get the user input from the EditText fields
            String u = usernameInput.getText().toString().trim();
            String p = passwordInput.getText().toString().trim();
            String e = emailInput.getText().toString().trim();

            // Check if any of the fields are empty and display an error message
            if (u.isEmpty() || p.isEmpty() || e.isEmpty()) {
                Toast.makeText(this, "All fields must be filled.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Get the selected icon resource ID, and show an error if no icon is selected
            int iconRes = customGridListeners.getSelectedIconResId();
            if (iconRes < 0) {
                Toast.makeText(this, "Select an icon.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Ensure that at least one course is selected
            if (selectedCourses.isEmpty()) {
                Toast.makeText(this, "Select at least one course.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Create a UserInfoClass object to store the user's sign-up information
            UserInfoClass user = new UserInfoClass(u, p, e, courseList, iconRes);

            // Validate the user information using the ValidationManager
            if (!ValidationManager.validateUserInfo(user, usernameInput, passwordInput, emailInput)) {
                Toast.makeText(this, "Enter valid info.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Proceed with creating the user account using Firebase
            createUserWithEmailAndPassword(e, p, u, iconRes, selectedCourses);
        });
    }

    /**
     * Function Name: createUserWithEmailAndPassword
     * Description  : Sends user data to a loading fragment to handle registration.
     * Input        : email - user's email
     * password - user's password
     * username - user's name
     * id - selected icon ID
     * sel - selected courses list
     * Output       : None
     */
    private void createUserWithEmailAndPassword(String email, String password,
                                                String username, int id,
                                                ArrayList<CourseClass> sel) {
        // Log the icon ID being passed to the LoadingFragment for debugging
        Log.d("IconSelectDebug", "Passing icon ID to LoadingFragment: " + id);

        // Create a new instance of the LoadingFragment
        LoadingFragment frag = new LoadingFragment();
        // Prepare a Bundle to pass the user data as arguments to the fragment
        Bundle args = new Bundle();
        args.putString(Constants.KEY_EMAIL, email);
        args.putString(Constants.KEY_PASSWORD, password);
        args.putString(Constants.KEY_USERNAME, username);
        args.putInt(Constants.KEY_ICON, id);
        args.putSerializable(Constants.KEY_COURSE_SELECTED, sel);
        frag.setArguments(args); // Attach the arguments to the fragment

        // Replace the current fragment with the LoadingFragment
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container_sign_up, frag)
                .commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu to add items to the action bar
        getMenuInflater().inflate(R.menu.menu, menu);
        // Hide certain menu items that aren't relevant to this activity
        menu.findItem(R.id.menu_profile).setVisible(false);
        menu.findItem(R.id.menu_log_out).setVisible(false);
        menu.findItem(R.id.menu_home).setVisible(false);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Handle action bar item clicks
        if (item.getItemId() == R.id.menu_go_back) {
            // Navigate to the login activity if '
            // Navigate to the login activity if 'Go Back' is selected from the options menu
            Intent intent = new Intent(SignUpActivity.this, LogInActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
