package com.example.myfinalproject.gamesActivities.ComputerScience;

import android.content.Intent; // Import Intent
import android.content.SharedPreferences; // Import SharedPreferences
import android.os.Bundle; // Import Bundle
import android.os.Handler; // Import Handler
import android.text.Editable; // Import Editable for TextWatcher
import android.text.TextWatcher; // Import TextWatcher for EditText listener
import android.util.Log; // Import Log
import android.view.LayoutInflater; // Import LayoutInflater
import android.view.Menu; // Import Menu
import android.view.MenuInflater; // Import MenuInflater
import android.view.MenuItem; // Import MenuItem
import android.view.View; // Import View
import android.view.ViewGroup; // Import ViewGroup
import android.widget.AdapterView; // Import AdapterView for Spinner
import android.widget.ArrayAdapter; // Import ArrayAdapter for Spinner
import android.widget.Button; // Import Button
import android.widget.CheckBox; // Import CheckBox
import android.widget.CompoundButton; // Import CompoundButton for CheckBox listener
import android.widget.EditText; // Import EditText
import android.widget.LinearLayout; // Import LinearLayout
import android.widget.RadioButton; // Import RadioButton
import android.widget.RadioGroup; // Import RadioGroup
import android.widget.Spinner; // Import Spinner
import android.widget.TextView; // Import TextView
import android.widget.Toast; // Import Toast

import androidx.annotation.NonNull; // Import annotations
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity; // Import AppCompatActivity
import androidx.appcompat.widget.Toolbar; // Import Toolbar
import androidx.cardview.widget.CardView; // Import CardView
import androidx.fragment.app.Fragment; // Import Fragment
import androidx.fragment.app.FragmentManager; // Import FragmentManager

import com.example.myfinalproject.R; // Import R
import com.example.myfinalproject.activities.LogInActivity; // Import activities
import com.example.myfinalproject.activities.MainActivity;
import com.example.myfinalproject.activities.ProfileActivity;
import com.example.myfinalproject.activities.SettingsActivity;
import com.example.myfinalproject.adapters.SubtopicAdapter; // Import SubtopicAdapter
import com.example.myfinalproject.java_classes.Constants; // Import Constants
import com.example.myfinalproject.java_classes.CourseClass; // Import data classes
import com.example.myfinalproject.java_classes.SubTopicClass;
import com.example.myfinalproject.java_classes.UserInfoClass;
import com.google.android.gms.tasks.OnFailureListener; // Import Firebase task listeners
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth; // Import Firebase Auth
import com.google.firebase.auth.FirebaseUser; // Import FirebaseUser
import com.google.firebase.firestore.DocumentReference; // Import Firestore classes
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList; // Import ArrayList

// Class: VariablesExerciseFragment
// Description: A Fragment representing an interactive exercise/quiz about computer science variables.
// It presents multiple questions with different input types (RadioGroup, Spinner, CheckBoxes, Buttons, EditText).
// The user's answers are checked, a score is calculated, and the subtopic progress is updated in Firestore.
// Input: none (as it's a Fragment, interacts via UI and Firebase)
// Output: Displays UI, handles user interaction, calculates score, updates Firestore, navigates.
public class VariablesExerciseFragment extends Fragment {

    // --- Question Views ---
    // Question 1 views (RadioGroup)
    private CardView cardQuestion1; // CardView container for Question 1
    private RadioGroup radioGroup1; // RadioGroup for Question 1 options
    private RadioButton radioOption1; // RadioButton Option 1 for Q1 (correct answer)
    private RadioButton radioOption2; // RadioButton Option 2 for Q1
    private RadioButton radioOption3; // RadioButton Option 3 for Q1

    // Question 2 views (Spinner)
    private CardView cardQuestion2; // CardView container for Question 2
    private Spinner spinnerQuestion2; // Spinner for Question 2 options

    // Question 3 views (CheckBoxes)
    private CardView cardQuestion3; // CardView container for Question 3
    private CheckBox checkInt; // CheckBox for 'int' option (incorrect)
    private CheckBox checkString; // CheckBox for 'String' option (correct)
    private CheckBox checkBoolean; // CheckBox for 'boolean' option (correct)

    // Question 4 views (True/False Buttons)
    private CardView cardQuestion4; // CardView container for Question 4
    private Button btnTrue; // Button for 'True' option (incorrect)
    private Button btnFalse; // Button for 'False' option (correct)

    // Question 5 views (EditText for text input)
    private CardView cardQuestion5; // CardView container for Question 5
    private EditText etAnswer5; // EditText for user to type answer for Q5

    // --- Action Buttons ---
    private Button btnFinish; // Button to finish the exercise and calculate score
    private Button btnNextPopup; // Button in the score popup to navigate next

    // --- Score Popup Views ---
    private LinearLayout layoutPopupScore; // Layout for the score popup (shown/hidden)
    private TextView tvPopupScore; // TextView to display the calculated score in the popup
    private Button btnClosePopup; // Button to close the score popup

    // --- Firebase Variables ---
    private FirebaseAuth mAuth; // Firebase Authentication instance
    private FirebaseFirestore db; // Firestore database instance
    // User ID (might be redundant with mAuth.getCurrentUser().getUid() but used)
    private String userId; // User ID of the currently logged-in user

    // --- Exercise State Variables ---
    // Flags to track if each question is answered correctly
    private boolean question1Correct = false;
    private boolean question2Correct = false;
    private boolean question3Correct = false; // This is set based on checkAll
    private boolean question4Correct = false;
    private boolean question5Correct = false;

    // CheckBox specific flags for Q3 (track individual selections)
    private boolean check1 = false; // State of checkInt
    private boolean check2 = false; // State of checkBoolean
    private boolean check3 = false; // State of checkString
    private boolean checkAll = false; // True if correct checkboxes for Q3 are checked (checkString and checkBoolean)

    private int score = 0; // User's final score for the exercise (out of 5)
    private int questionAnswered = 0; // Count of questions that have been answered (at least once)

    // --- Handler and Runnable for potential delayed actions ---
    // Not currently used for delayed progress update in this code snippet, but variables are declared.
    private Handler finishHandler = new Handler();
    private Runnable finishRunnable;

    // Function: onCreateView
    // Description: Called to create the view hierarchy for the fragment.
    // Inflates the layout, initializes views, listeners, Firebase, gets user ID,
    // and sets up the toolbar menu.
    // Input: LayoutInflater inflater - The LayoutInflater object that can be used to inflate any views in the fragment.
    // Input: ViewGroup container - If non-null, this is the parent view that the fragment's UI should be attached to.
    // Input: Bundle savedInstanceState - If non-null, this fragment is being re-constructed from a previous saved state.
    // Output: View - The root View of the fragment's layout.
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Step 1: Inflate the layout for this fragment from variables_exercise_cs.xml
        View view = inflater.inflate(R.layout.variables_exercise_cs, container, false);

        // Step 2: Initialize UI views found in the inflated layout
        initViews(view);
        // Step 3: Initialize event listeners for the UI elements
        initListeners();

        // Step 4: Initialize Firebase Authentication and Firestore instances
        mAuth = FirebaseAuth.getInstance(); // Get Auth instance
        db = FirebaseFirestore.getInstance(); // Get Firestore instance

        // Step 5: Get the current user's UID
        // Note: This assumes the user is already logged in when this fragment is created.
        // A null check might be needed here or earlier in the flow.
        userId = mAuth.getCurrentUser().getUid();

        // Step 6: Indicate that this fragment has its own options menu
        setHasOptionsMenu(true); // Ensure menu options show up

        // Step 7: Get the main activity's Toolbar and set it as the action bar for the fragment
        Toolbar toolbar = requireActivity().findViewById(R.id.toolbarMain); // Find toolbar in the hosting activity
        ((AppCompatActivity) requireActivity()).setSupportActionBar(toolbar); // Set it as the action bar

        // Step 8: Return the root view of the fragment
        return view;
    }

    // Function: initViews
    // Description: Initializes UI elements by finding them in the layout. Organizes finding by question/section.
    // Input: View view - The root view of the fragment's layout.
    // Output: void (Initializes UI views).
    private void initViews(View view) {
        // Step 1: Initialize views for Question 1 (RadioGroup)
        cardQuestion1 = view.findViewById(R.id.cardQuestion1);
        radioGroup1 = view.findViewById(R.id.radioGroup1);
        radioOption1 = view.findViewById(R.id.radioOption1); // Correct option
        radioOption2 = view.findViewById(R.id.radioOption2);
        radioOption3 = view.findViewById(R.id.radioOption3);

        // Step 2: Initialize views for Question 2 (Spinner)
        cardQuestion2 = view.findViewById(R.id.cardQuestion2);
        spinnerQuestion2 = view.findViewById(R.id.spinnerQuestion2);

        // Step 3: Initialize views for Question 3 (CheckBoxes)
        cardQuestion3 = view.findViewById(R.id.cardQuestion3);
        checkInt = view.findViewById(R.id.checkInt); // Incorrect option
        checkString = view.findViewById(R.id.checkString); // Correct option
        checkBoolean = view.findViewById(R.id.checkBoolean); // Correct option

        // Step 4: Initialize views for Question 4 (True/False Buttons)
        cardQuestion4 = view.findViewById(R.id.cardQuestion4);
        btnTrue = view.findViewById(R.id.btnTrue); // Incorrect option
        btnFalse = view.findViewById(R.id.btnFalse); // Correct option

        // Step 5: Initialize views for Question 5 (EditText)
        cardQuestion5 = view.findViewById(R.id.cardQuestion5);
        etAnswer5 = view.findViewById(R.id.etAnswer5); // EditText for answer input

        // Step 6: Initialize the Finish button
        btnFinish = view.findViewById(R.id.btnFinishVarExercises);

        // Step 7: Initialize Score Popup Views
        layoutPopupScore = view.findViewById(R.id.layoutPopupScore); // Popup container layout
        tvPopupScore = view.findViewById(R.id.tvPopupScore); // TextView for score
        btnClosePopup = view.findViewById(R.id.btnClosePopup); // Button to close popup
        btnNextPopup = view.findViewById(R.id.btnNextPopup); // Button in popup to navigate next

        // Step 8: Set up Spinner options for Question 2
        ArrayList<String> options = new ArrayList<>();
        options.add("int");
        options.add("String"); // Correct option
        options.add("boolean");
        // Create an ArrayAdapter using the options list
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item, options);
        // Set the adapter on the Spinner
        spinnerQuestion2.setAdapter(adapter);
    }

    // Function: initListeners
    // Description: Sets up listeners for all interactive UI elements (RadioGroup, Spinner, CheckBoxes, Buttons, EditText, Popup buttons).
    // These listeners handle checking answers, updating question completion status, and controlling the score popup/navigation.
    // Input: none
    // Output: void (Sets up listeners).
    private void initListeners() {
        // Step 1: Set a checked change listener for Question 1 RadioGroup
        radioGroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            // Flag to ensure questionAnswered is incremented only once for this question
            boolean answered = false;
            // Function: onCheckedChanged
            // Description: Called when the selected radio button in Q1's group changes. Checks correctness and updates state.
            // Input: RadioGroup radioGroup - The RadioGroup whose selection has changed.
            // Input: int i - The ID of the newly selected radio button.
            // Output: void (Updates questionAnswered count and question1Correct flag).
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                // Step 1.1: If this is the first time an option is selected in this group
                if (!answered) {
                    // Step 1.1.1: Increment the count of answered questions
                    questionAnswered++;
                    // Step 1.1.2: Set the answered flag to true
                    answered = true;
                }
                // Step 1.2: Check if the selected radio button's ID matches the correct option's ID
                question1Correct = (i == radioOption1.getId());
            }
        });

        // Step 2: Set an item selected listener for Question 2 Spinner
        spinnerQuestion2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            // Function: onItemSelected
            // Description: Called when an item in Q2's Spinner has been selected. Checks correctness and updates state.
            // Input: AdapterView<?> adapterView - The AdapterView where the selection happened.
            // Input: View view - The view within the AdapterView that was clicked.
            // Input: int i - The position of the view in the adapter.
            // Input: long l - The row id of the item that is selected.
            // Output: void (Checks correctness and updates question2Correct flag and questionAnswered count).
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                // Step 2.1: Get the selected answer string from the adapter
                String answer = adapterView.getItemAtPosition(i).toString();
                // Step 2.2: Define the correct answer string
                String correctAnswer = "String";
                // Step 2.3: Check if the selected answer matches the correct answer
                if (answer.equals(correctAnswer)) {
                    // Step 2.3.1: If correct, set the correctness flag to true
                    question2Correct = true;
                    // Step 2.3.2: Increment the count of answered questions (assuming selecting means answering)
                    questionAnswered++;
                } else {
                    // Step 2.3.3: If incorrect, set the correctness flag to false
                    question2Correct = false;
                    // Note: Logic here might need refinement if selecting an incorrect answer multiple times increments questionAnswered repeatedly.
                    // A better approach might be to track if *any* selection has been made.
                }
            }
            // Function: onNothingSelected
            // Description: Called when the selection disappears from the Spinner.
            // Input: AdapterView<?> adapterView - The AdapterView that now contains no selected item.
            // Output: void (Sets question2Correct to true - potentially unintended logic).
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // Step 2.4: This part's logic seems unusual. Setting question2Correct to true on nothing selected
                // might not be the intended behavior. Review required.
                question2Correct = true; // REVIEW: Is this intended?
            }
        });

        // Step 3: Set checked change listeners for Question 3 CheckBoxes
        // Listener for 'int' checkbox
        checkInt.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            // Flag to ensure questionAnswered is handled correctly with check boxes
            boolean answered = false; // This flag logic for CheckBoxes is complex and potentially flawed.
            // Function: onCheckedChanged
            // Description: Called when the checked state of the 'int' checkbox changes. Updates state and checkAll flag.
            // Input: CompoundButton compoundButton - The CheckBox view.
            // Input: boolean b - The new checked state.
            // Output: void (Updates check1 flag and checkAll flag).
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                // Step 3.1: This answered flag logic is complex and might not accurately count questions answered.
                // It seems intended to count when *any* change happens.
                if (!answered && b) {
                    questionAnswered++; // Increments when checked
                    answered = true;
                } else if (answered && !b) {
                    questionAnswered--; // Decrements when unchecked
                    answered = false;
                }
                // Step 3.2: Update the flag for the 'int' checkbox state
                check1 = b;
                // Step 3.3: Update the checkAll flag based on the required correct selections ('String' and 'boolean')
                checkAll = check1 && check2 && check3; // REVIEW: check1 is for 'int', which is incorrect. checkAll should be (checkString && checkBoolean && !checkInt)
            }
        });
        // Listener for 'boolean' checkbox
        checkBoolean.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            // Function: onCheckedChanged
            // Description: Called when the checked state of the 'boolean' checkbox changes. Updates state and checkAll flag.
            // Input: CompoundButton compoundButton - The CheckBox view.
            // Input: boolean b - The new checked state.
            // Output: void (Updates check2 flag and checkAll flag, increments questionAnswered - potentially flawed).
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                // Step 3.4: Update the flag for the 'boolean' checkbox state
                check2 = b;
                // Step 3.5: Update the checkAll flag based on the required correct selections
                checkAll = check1 && check2 && check3; // REVIEW: Logic for checkAll and questionAnswered needs review for CheckBoxes.
                questionAnswered++; // Increments on any change? This is likely incorrect.
            }
        });
        // Listener for 'String' checkbox
        checkString.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            // Function: onCheckedChanged
            // Description: Called when the checked state of the 'String' checkbox changes. Updates state and checkAll flag.
            // Input: CompoundButton compoundButton - The CheckBox view.
            // Input: boolean b - The new checked state.
            // Output: void (Updates check3 flag and checkAll flag, increments questionAnswered - potentially flawed).
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                // Step 3.6: Update the flag for the 'String' checkbox state
                check3 = b;
                // Step 3.7: Update the checkAll flag based on the required correct selections
                checkAll = check1 && check2 && check3; // REVIEW: Logic for checkAll and questionAnswered needs review for CheckBoxes.
                questionAnswered++; // Increments on any change? This is likely incorrect.
            }
        });
        // Note on Q3 CheckBox Listeners: The logic for `checkAll` seems incorrect based on the correct answer
        // (String and boolean should be checked, int should not). The `questionAnswered` logic is also
        // problematic as it increments on *any* state change, not just the first check that potentially completes the question.

        // Step 4: Set click listeners for Question 4 True/False Buttons
        // Listener for 'True' button
        btnTrue.setOnClickListener(new View.OnClickListener() {
            // Flag to ensure questionAnswered is incremented only once for this question
            boolean answered = false;
            // Function: onClick
            // Description: Called when the 'True' button for Q4 is clicked. Updates state.
            // Input: View view - The clicked view (the button).
            // Output: void (Updates questionAnswered count and question4Correct flag).
            @Override
            public void onClick(View view) {
                // Step 4.1: If this is the first time an option is selected for this question
                if (!answered) {
                    // Step 4.1.1: Increment the count of answered questions
                    questionAnswered++;
                    // Step 4.1.2: Set the answered flag to true
                    answered = true;
                }
                // Step 4.2: 'True' is the incorrect answer for Q4, so set correctness flag to false
                question4Correct = false; // Assuming False is correct
            }
        });
        // Listener for 'False' button
        btnFalse.setOnClickListener(new View.OnClickListener() {
            // Flag to ensure questionAnswered is incremented only once for this question
            boolean answered = false;
            // Function: onClick
            // Description: Called when the 'False' button for Q4 is clicked. Updates state.
            // Input: View view - The clicked view (the button).
            // Output: void (Updates questionAnswered count and question4Correct flag).
            @Override
            public void onClick(View view) {
                // Step 4.3: If this is the first time an option is selected for this question
                if (!answered) {
                    // Step 4.3.1: Increment the count of answered questions
                    questionAnswered++;
                    // Step 4.3.2: Set the answered flag to true
                    answered = true;
                }
                // Step 4.4: 'False' is the correct answer for Q4, so set correctness flag to true
                question4Correct = true; // Assuming False is correct
            }
        });

        // Step 5: Set a TextWatcher for Question 5 EditText
        etAnswer5.addTextChangedListener(new TextWatcher() {
            // Flag to ensure questionAnswered is incremented only once for this question
            boolean answered = false;
            // Function: beforeTextChanged
            // Description: Called before the text changes in the EditText.
            // Input: CharSequence charSequence - The char sequence before the text change.
            // Input: int i, int i1, int i2 - Details about the change.
            // Output: void (No action taken in this implementation).
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            // Function: onTextChanged
            // Description: Called when the text is changing in the EditText.
            // Input: CharSequence charSequence - The char sequence during the text change.
            // Input: int i, int i1, int i2 - Details about the change.
            // Output: void (No action taken in this implementation).
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            // Function: afterTextChanged
            // Description: Called after the text has changed in the EditText. Checks correctness and updates state.
            // Input: Editable editable - The Editable containing the new text.
            // Output: void (Updates questionAnswered count and question5Correct flag).
            @Override
            public void afterTextChanged(Editable editable) {
                // Step 5.1: If this is the first time text is entered (and it's not empty)
                if (!answered && !editable.toString().isEmpty()) {
                    // Step 5.1.1: Increment the count of answered questions
                    questionAnswered++;
                    // Step 5.1.2: Set the answered flag to true
                    answered = true;
                } else if (answered && editable.toString().isEmpty()) {
                    // Step 5.2: If text was previously entered but is now cleared
                    // Step 5.2.1: Decrement the count of answered questions
                    questionAnswered--;
                    // Step 5.2.2: Set the answered flag to false
                    answered = false;
                }
                // Step 5.3: Check if the entered text equals the correct answer ("12")
                question5Correct = editable.toString().equals("12");
            }
        });

        // Step 6: Set a click listener for the Finish button
        btnFinish.setOnClickListener(new View.OnClickListener() {
            // Function: onClick
            // Description: Called when the Finish button is clicked. Checks if all questions are answered,
            // calculates the score, and shows the score popup.
            // Input: View view - The clicked view (the button).
            // Output: void (Checks completion, calculates score, shows popup, or shows toast).
            @Override
            public void onClick(View view) {
                // Step 6.1: Define the total number of questions
                int totalQuestions = 5; // Total number of questions
                // Step 6.2: Check if the number of questions answered is less than the total
                if (questionAnswered < totalQuestions) {
                    // Step 6.2.1: If not all questions are answered, show a toast message
                    Toast.makeText(getContext(), "Please answer all questions before finishing!", Toast.LENGTH_SHORT).show();
                    return; // Exit the click listener
                }

                // Step 6.3: Calculate the user's score based on the correctness flags
                score = 0; // Initialize score to 0
                if (question1Correct) score++; // Add 1 if Q1 is correct
                if (question2Correct) score++; // Add 1 if Q2 is correct
                // Step 6.3.1: Check correctness for Q3 using the checkAll flag (REVIEW: checkAll logic might be flawed)
                if (checkAll) score++; // Add 1 if Q3 is correct (based on checkAll)
                if (question4Correct) score++; // Add 1 if Q4 is correct
                if (question5Correct) score++; // Add 1 if Q5 is correct

                // Step 6.4: Show the Score Popup
                // Step 6.4.1: Set the text of the score TextView in the popup
                tvPopupScore.setText("Your Score: " + score + "/5");
                // Step 6.4.2: Make the score popup layout visible
                layoutPopupScore.setVisibility(View.VISIBLE);
            }
        });

        // Step 7: Set a click listener for the Close Popup button
        btnClosePopup.setOnClickListener(new View.OnClickListener() {
            // Function: onClick
            // Description: Called when the Close Popup button is clicked. Hides the score popup.
            // Input: View view - The clicked view (the button).
            // Output: void (Hides the popup).
            @Override
            public void onClick(View view) {
                // Step 7.1: Hide the score popup layout
                layoutPopupScore.setVisibility(View.GONE);
            }
        });

        // Step 8: Set a click listener for the Next button in the Popup
        btnNextPopup.setOnClickListener(new View.OnClickListener() {
            // Function: onClick
            // Description: Called when the Next button in the popup is clicked. Hides the popup
            // and triggers updating subtopic progress and navigation.
            // Input: View view - The clicked view (the button).
            // Output: void (Hides popup and calls updateSubtopicProgress).
            @Override
            public void onClick(View view) {
                // Step 8.1: Hide the score popup layout
                layoutPopupScore.setVisibility(View.GONE);
                // Step 8.2: Navigate to the next activity or fragment by updating progress
                updateSubtopicProgress(); // Calls update progress and then navigates
            }
        });
    }

    // Function: updateSubtopicProgress
    // Description: Updates the progress for the 'Variables Exercise Quiz' CS subtopic in Firestore
    // based on the calculated score. It retrieves the current user's courses, finds the specific
    // subtopic, sets its progress (score * 20), saves the modified course list back to Firestore,
    // and navigates to the next fragment ('Conditionals') on success.
    // Includes checks to ensure the fragment is attached to avoid issues with async operations.
    // Input: none
    // Output: void (Fetches user data, updates Firestore, navigates, shows feedback).
    private void updateSubtopicProgress() {
        // Step 1: Reset the global currently selected subtopic (optional, depends on app flow)
        SubtopicAdapter.currentlySelectedSubtopic = null;
        // Step 2: Get the currently logged-in Firebase user
        FirebaseUser currentUser = mAuth.getCurrentUser();
        // Step 3: Check if the user is logged in
        if (currentUser == null) {
            // Step 3.1: If not logged in, show a toast and exit the method
            Toast.makeText(getContext(), "User not signed in", Toast.LENGTH_SHORT).show();
            return; // Exit the method
        }
        // Step 4: Get the current user's UID
        String userId = currentUser.getUid();
        // Step 5: Get a document reference to the user's data in Firestore
        DocumentReference userRef = db.collection("users").document(userId);

        // Step 6: Retrieve current user data from Firestore asynchronously
        userRef.get().addOnCompleteListener(task -> {
            // Function: onComplete (OnCompleteListener for Firestore get)
            // Description: Called when the task to get user data completes.
            // Input: Task<DocumentSnapshot> task - The completed task.
            // Output: void (Processes user data, updates subtopic, saves to Firestore, navigates).
            // Step 6.1: Check if the task was successful
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                // Step 6.2: Check if the document exists and is not null
                if (document != null && document.exists()) {
                    // Step 6.3: Convert the document to a UserInfoClass object
                    UserInfoClass userInfo = document.toObject(UserInfoClass.class);
                    // Step 6.4: Check if UserInfo object and its classes list are valid
                    if (userInfo != null && userInfo.getClasses() != null) {
                        // Step 6.5: Get the list of existing courses
                        ArrayList<CourseClass> courses = userInfo.getClasses();
                        boolean updated = false; // Flag to track if progress was updated

                        // Step 6.6: Iterate through courses and subtopics to find the target subtopic
                        for (CourseClass course : courses) {
                            if (course.getSubtopics() != null) {
                                for (SubTopicClass subTopic : course.getSubtopics()) {
                                    // Step 6.6.1: Check if the current subtopic matches the target subtopic ('Variables Exercise Quiz')
                                    if (subTopic.getName().equals(Constants.KEY_CS_VARIABLES_QUIZ)) {
                                        // Step 6.6.2: Update the progress for this specific subtopic based on the score (score * 20)
                                        subTopic.setProgress(score * 20); // Set progress (e.g., 5/5 = 100%)
                                        updated = true; // Set the flag to true
                                        break; // Exit the inner subtopic loop once found
                                    }
                                }
                            }
                            // Step 6.6.3: If the subtopic was updated, exit the outer course loop as well
                            if (updated) break;
                        }
                        // Step 6.7: Update the 'classes' field in the user's Firestore document with the modified courses list
                        userRef.update("classes", courses)
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    // Function: onSuccess (OnSuccessListener for Firestore update)
                                    // Description: Called when the Firestore update succeeds.
                                    // Input: Void aVoid - Placeholder.
                                    // Output: void (Shows success toast and navigates to the next fragment).
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        // Step 6.7.1.1: Check if fragment is attached before showing UI
                                        if (!isAdded()) return;
                                        // Step 6.7.1.2: Show a toast message indicating progress update success
                                        Toast.makeText(getContext(), "Subtopic progress updated!", Toast.LENGTH_SHORT).show();
                                        // Step 6.7.1.3: Navigate to the next fragment (ConditionalsFragment) after successful update
                                        requireActivity().getSupportFragmentManager().beginTransaction()
                                                .replace(R.id.fragment_container_main, new ConditionalsFragment()) // Replace current fragment
                                                .addToBackStack(null) // Add to back stack for navigation
                                                .commit(); // Commit the transaction
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    // Function: onFailure (OnFailureListener for Firestore update)
                                    // Description: Called when the Firestore update fails.
                                    // Input: Exception e - The exception detailing the failure.
                                    // Output: void (Shows error toast and logs error).
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        // Step 6.7.2.1: Check if fragment is attached before showing UI
                                        if (!isAdded()) return;
                                        // Step 6.7.2.2: Show a toast message with the error details
                                        Toast.makeText(getContext(), "Error updating Firestore: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                        // Step 6.7.2.3: Log the error
                                        Log.e("Firestore", "Error updating subtopic progress", e);
                                        // Note: Navigation might not happen on failure, keeping the user on the current fragment.
                                    }
                                });
                    } else {
                        // Step 6.8: Check if fragment is attached before showing UI
                        if (isAdded()) {
                            // Step 6.8.1: Show a toast if user data or course list is unexpectedly null
                            Toast.makeText(requireContext(), "User data or course list is null.", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    // Step 6.9: Check if fragment is attached before showing UI
                    if (isAdded()) {
                        // Step 6.9.1: Show a toast if the user document is not found in Firestore
                        Toast.makeText(requireContext(), "User document not found.", Toast.LENGTH_SHORT).show();
                    }
                }
            } else {
                // Step 6.10: Check if fragment is attached before showing UI
                if (isAdded()) {
                    // Step 6.10.1: Show a toast and log if fetching user data from Firestore failed
                    Toast.makeText(requireContext(), "Error getting user data: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    Log.e("Firestore", "Error getting user data", task.getException());
                }
            }
        });
    }

    // Function: onCreateOptionsMenu
    // Description: Initializes the options menu for the fragment's toolbar.
    // Input: Menu menu - The options menu.
    // Input: MenuInflater inflater - The inflater to inflate the menu layout.
    // Output: void (Inflates menu).
    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        // Step 1: Call the superclass method
        super.onCreateOptionsMenu(menu, inflater);
        // Step 2: Clear any existing menu items (important for fragments sharing a toolbar)
        menu.clear();
        // Step 3: Inflate the menu layout (R.menu.menu) into the provided Menu object
        inflater.inflate(R.menu.menu, menu);
    }

    // Function: onOptionsItemSelected
    // Description: Called when an item in the options menu is selected. Handles navigation/actions based on the selected item.
    // Input: MenuItem item - The menu item that was selected.
    // Output: boolean - True if the event was consumed, false otherwise.
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Step 1: Get the ID of the selected menu item
        int id = item.getItemId();
        // Step 2: Check the ID and perform the corresponding action
        if (id == R.id.menu_log_out) {
            // Step 2.1: If Log Out is selected, call the logoutUser helper method
            logoutUser();
        } else if (id == R.id.menu_go_back) {
            // Step 2.2: If Go Back is selected, get the FragmentManager from the hosting activity
            FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
            // Step 2.2.1: Check if there are fragments in the back stack managed by this FragmentManager
            if (fragmentManager.getBackStackEntryCount() > 0) {
                // Step 2.2.1.1: If yes, pop the back stack to go to the previous fragment
                fragmentManager.popBackStack();
            } else {
                // Step 2.2.1.2: If no fragments left in this manager's back stack, navigate back to MainActivity
                Intent intent = new Intent(requireActivity(), MainActivity.class);
                startActivity(intent);
                requireActivity().finish(); // Close current activity (hosting MainActivity)
            }
        } else if (id == R.id.menu_settings) {
            // Step 2.3: If Settings is selected, start the SettingsActivity
            startActivity(new Intent(requireActivity(), SettingsActivity.class));
        } else if (id == R.id.menu_profile) {
            // Step 2.4: If Profile is selected, start the ProfileActivity
            startActivity(new Intent(requireActivity(), ProfileActivity.class));
        } else if (id == R.id.menu_home) {
            // Step 2.5: If Home is selected, navigate back to MainActivity
            Intent intent = new Intent(requireActivity(), MainActivity.class);
            // Step 2.5.1: Clear the global currently selected subtopic (important when going home)
            SubtopicAdapter.currentlySelectedSubtopic = null;
            startActivity(intent);
            // Note: Finishing the activity here might be desired depending on navigation flow, but is not present in original.
        }
        // Step 3: Return true to indicate that the event was consumed
        return true;
    }

    // Function: logoutUser
    // Description: Logs out the currently authenticated user from Firebase, updates shared preferences,
    // clears the global selected subtopic, and navigates back to the LogInActivity.
    // Input: none
    // Output: void (Logs out user, updates state, navigates).
    private void logoutUser() {
        // Step 1: Get SharedPreferences for remembering user login status
        SharedPreferences sharedPreferences = requireActivity()
                .getSharedPreferences(Constants.KEY_REMEMBER_USER, requireActivity().MODE_PRIVATE);
        // Step 2: Get an editor for SharedPreferences
        SharedPreferences.Editor editor = sharedPreferences.edit();
        // Step 3: Set the "Remember User" flag to false
        editor.putBoolean(Constants.KEY_REMEMBER_USER, false);
        // Step 4: Apply the changes to SharedPreferences
        editor.apply();
        // Step 5: Clear the global currently selected subtopic
        SubtopicAdapter.currentlySelectedSubtopic = null;
        // Step 6: Sign out the user from Firebase Authentication
        mAuth.signOut();
        // Step 7: Create an Intent to navigate to the LogInActivity
        Intent intent = new Intent(requireActivity(), LogInActivity.class);
        // Step 8: Start the LogInActivity
        startActivity(intent);
        // Step 9: Finish the current hosting activity (which is MainActivity) to prevent going back
        requireActivity().finish();
    }
}