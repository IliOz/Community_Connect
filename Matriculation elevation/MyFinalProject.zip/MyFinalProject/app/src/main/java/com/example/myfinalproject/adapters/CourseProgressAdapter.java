package com.example.myfinalproject.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.myfinalproject.R;
import com.example.myfinalproject.java_classes.CourseClass;

import java.util.ArrayList;

// Class: CourseProgressAdapter
// Description: RecyclerView adapter to display a list of courses and their progress.
// Input: Data is an ArrayList of CourseClass objects.
// Output: Populates rows in a RecyclerView.
public class CourseProgressAdapter extends RecyclerView.Adapter<CourseProgressAdapter.CourseViewHolder> {

    // Variables
    private Context context; // Context to inflate layout
    private ArrayList<CourseClass> courseList; // List of CourseClass objects to display

    // Function: Constructor
    // Input: Context context - the context of the activity or fragment
    // Input: ArrayList<CourseClass> courseList - the list of courses to display
    // Output: Initializes the adapter with context and data.
    public CourseProgressAdapter(Context context, ArrayList<CourseClass> courseList) {
        // Step 1: Assign the provided context to the class variable
        this.context = context;
        // Step 2: Assign the provided course list to the class variable
        this.courseList = courseList;
    }

    // Class: CourseViewHolder
    // Description: Holds the views for a single item (row) in the RecyclerView.
    // Input: View itemView - the inflated layout for a single item.
    // Output: Provides references to the TextViews within the item layout.
    public static class CourseViewHolder extends RecyclerView.ViewHolder {
        // View variables
        TextView courseNameText; // TextView to display the course name
        TextView coursePointsText; // TextView to display the course progress/points

        // Function: Constructor
        // Input: View itemView - the root view of the item layout
        // Output: Initializes the ViewHolder and finds the necessary views.
        public CourseViewHolder(View itemView) {
            // Step 1: Call the superclass constructor
            super(itemView);
            // Step 2: Find the TextView for the course name by its ID
            courseNameText = itemView.findViewById(R.id.tvCourseName);
            // Step 3: Find the TextView for the course points/progress by its ID
            coursePointsText = itemView.findViewById(R.id.coursePointsLevel);
        }
    }

    // Function: onCreateViewHolder
    // Description: Called when RecyclerView needs a new ViewHolder of the given type to represent an item.
    // Input: ViewGroup parent - The ViewGroup into which the new View will be added after it is bound to an adapter position.
    // Input: int viewType - The view type of the new View.
    // Output: CourseViewHolder - A new ViewHolder that holds a View of the given view type.
    @Override
    public CourseViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Step 1: Inflate the layout for a single course item from the XML file
        View view = LayoutInflater.from(context).inflate(R.layout.selected_courses, parent, false);
        // Step 2: Create a new CourseViewHolder instance with the inflated view
        return new CourseViewHolder(view);
    }

    // Function: onBindViewHolder
    // Description: Called by RecyclerView to display the data at the specified position.
    // Input: CourseViewHolder holder - The ViewHolder which should be updated to represent the contents of the item at the given position.
    // Input: int position - The position of the item within the adapter's data set.
    // Output: void (Updates the contents of the ViewHolder's views)
    @Override
    public void onBindViewHolder(CourseViewHolder holder, int position) {
        // Step 1: Get the CourseClass object for the item at the current position
        CourseClass course = courseList.get(position);
        // Step 2: Check if the course object is not null
        if (course != null) {
            // Step 3: Set the course name text in the ViewHolder's TextView
            holder.courseNameText.setText(course.getCourseName());
            // Step 4: Set the course progress text in the ViewHolder's TextView
            holder.coursePointsText.setText("Progress: " + course.getProgress());
        }
    }

    // Function: setCoursesList
    // Description: Updates the adapter's list of courses and refreshes the RecyclerView.
    // Input: ArrayList<CourseClass> courseList - The new list of courses to display.
    // Output: void (Updates the internal data and refreshes the UI)
    public void setCoursesList(ArrayList<CourseClass> courseList) {
        // Step 1: Check if the provided course list is not null
        if (courseList != null) {
            // Step 2: Clear the existing list held by the adapter
            this.courseList.clear(); // Clear the existing list if needed
            // Step 3: Add all items from the new list to the adapter's list
            this.courseList.addAll(courseList); // Add new list items
        } else {
            // Step 4: If the provided list is null, replace the adapter's list with an empty one
            this.courseList = new ArrayList<>(); // Handle the null case by assigning an empty list
        }
        // Step 5: Notify the RecyclerView that the data set has changed, prompting it to refresh
        notifyDataSetChanged(); // Notify RecyclerView to refresh the views
    }


    // Function: getItemCount
    // Description: Returns the total number of items in the data set held by the adapter.
    // Input: none
    // Output: int - The total number of items in this adapter.
    @Override
    public int getItemCount() {
        // Step 1: Return the size of the course list
        return courseList.size();
    }
}