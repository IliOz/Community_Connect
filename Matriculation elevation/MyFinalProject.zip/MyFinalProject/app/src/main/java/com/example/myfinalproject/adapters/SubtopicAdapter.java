package com.example.myfinalproject.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat; // Import ContextCompat for color
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager; // Import FragmentManager
import androidx.recyclerview.widget.RecyclerView;

import com.example.myfinalproject.R; // Import R
import com.example.myfinalproject.activities.MainActivity; // Import MainActivity for FragmentManager
import com.example.myfinalproject.gamesActivities.ComputerScience.CSIntroductionFragment; // Import fragment classes
import com.example.myfinalproject.gamesActivities.ComputerScience.CodeWithVariablesFragment;
import com.example.myfinalproject.gamesActivities.ComputerScience.ConditionalsFragment;
import com.example.myfinalproject.gamesActivities.ComputerScience.VariablesExerciseFragment;
import com.example.myfinalproject.gamesActivities.Physics.NewtonsLawsFragment; // Import physics fragment classes
import com.example.myfinalproject.java_classes.Constants; // Import Constants
import com.example.myfinalproject.java_classes.SubTopicClass; // Import SubTopicClass

import java.util.ArrayList; // Import ArrayList
import java.util.List; // Import List

/**
 * Class: SubtopicAdapter
 * Description: Adapter for displaying a list of {@link SubTopicClass} objects in a RecyclerView.
 * This adapter handles binding subtopic data to views and manages click events, including
 * single-selection highlighting and loading corresponding game/content fragments.
 * Input: Requires a Context and a List of SubTopicClass objects.
 * Output: Populates rows (subtopic items) within a RecyclerView.
 */
public class SubtopicAdapter extends RecyclerView.Adapter<SubtopicAdapter.SubtopicViewHolder> {

    // Variables
    private final Context context; // Context (final, cannot be reassigned)
    private List<SubTopicClass> subtopics; // List of SubTopicClass objects to display
    // Tracks the locally selected position within this specific adapter instance
    private int selectedPosition = RecyclerView.NO_POSITION; // Local tracking per adapter instance

    // Global static reference for cross-adapter selection tracking
    // This allows different SubtopicAdapter instances (e.g., in different expanded courses)
    // to know which subtopic is currently selected globally.
    public static SubTopicClass currentlySelectedSubtopic = null;

    /**
     * Function: Constructor
     * Description: Constructs a SubtopicAdapter.
     * Input: Context context - the context of the activity (should be MainActivity) or fragment
     * Input: ArrayList<SubTopicClass> subtopics - the initial list of subtopics to display
     * Output: Initializes the adapter with context and data.
     */
    public SubtopicAdapter(Context context, ArrayList<SubTopicClass> subtopics) {
        // Step 1: Assign the provided context to the class variable
        this.context = context;
        // Step 2: Assign the provided list of subtopics to the class variable
        this.subtopics = subtopics;
    }

    /**
     * Function: setSubtopics
     * Description: Replaces the current list of subtopics with a new list and resets the local selection state.
     * This is used when the data changes (e.g., when a course card is expanded).
     * Input: List<SubTopicClass> subtopics - The new list of subtopics to display.
     * Output: void (Updates the internal data and resets local state).
     */
    public void setSubtopics(List<SubTopicClass> subtopics) {
        // Step 1: Assign the new list of subtopics to the class variable
        this.subtopics = subtopics;
        // Step 2: Reset the local selected position as the data has changed
        selectedPosition = RecyclerView.NO_POSITION; // Reset local selection on data change
        // Step 3: Notify the adapter that the data set has changed, prompting a refresh
        notifyDataSetChanged();
    }

    // Function: onCreateViewHolder
    // Description: Called when RecyclerView needs a new ViewHolder of the given type to represent an item.
    // Input: ViewGroup parent - The ViewGroup into which the new View will be added after it is bound to an adapter position.
    // Input: int viewType - The view type of the new View.
    // Output: SubtopicViewHolder - A new ViewHolder that holds a View of the given view type.
    @NonNull
    @Override
    public SubtopicViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Step 1: Inflate the layout for a single subtopic item (sub_topic_list_view.xml).
        View view = LayoutInflater.from(context).inflate(R.layout.sub_topic_list_view, parent, false);
        // Step 2: Create a new SubtopicViewHolder instance with the inflated view
        return new SubtopicViewHolder(view);
    }

    // Function: onBindViewHolder
    // Description: Called by RecyclerView to display the data at the specified position.
    // Input: SubtopicViewHolder holder - The ViewHolder which should be updated to represent the contents of the item at the given position.
    // Input: int position - The position of the item within the adapter's data set.
    // Output: void (Updates the contents of the ViewHolder's views and sets click listener).
    @Override
    public void onBindViewHolder(@NonNull SubtopicViewHolder holder, int position) {
        // Step 1: Get the SubTopicClass object for the item at the current position
        SubTopicClass subtopic = subtopics.get(position);

        // Step 2: Set the subtopic name and progress text in the ViewHolder's TextViews
        holder.subTopicName.setText(subtopic.getName());
        holder.subTopicProgress.setText("Progress: " + subtopic.getProgress() + "%");

        // Step 3: Set background color based on selection state
        // Step 3.1: Check if this item's position matches the local selected position AND the subtopic is marked as selected
        if (position == selectedPosition && subtopic.isSelected()) {
            // Step 3.2: If selected, set the background color to red_300
            holder.itemView.setBackgroundColor(ContextCompat.getColor(context, R.color.red_300));
        } else {
            // Step 3.3: If not selected, set the background color to white (or default)
            holder.itemView.setBackgroundColor(ContextCompat.getColor(context, R.color.white));
        }

        // Step 4: Set a click listener on the entire item view
        holder.itemView.setOnClickListener(v -> {
            // Step 4.1: Call the helper method to handle the selection logic
            handleSubtopicClick(position);

            // Step 4.2: Get the clicked SubTopicClass object
            SubTopicClass clickedSubtopic = subtopics.get(position);

            // Step 4.3: Check if the clicked subtopic object is not null
            if (clickedSubtopic != null) {
                // Step 4.4: Get the topic name and subtopic name
                String topicName = clickedSubtopic.getTopicName();
                String subTopicName = clickedSubtopic.getName();

                FrameLayout fragmentContainer = ((MainActivity) context).findViewById(R.id.fragment_container_main);
                fragmentContainer.setVisibility(View.VISIBLE);

                // Step 4.5: Determine which fragment to load based on topic and subtopic names
                if (topicName.equals(Constants.KEY_PHYSICS)) {
                    // Step 4.5.1: Handle Physics subtopics
                    switch (subTopicName) {
                        case Constants.KEY_PHYSICS_NEWTONS_LAWS:
                            loadFragment(new NewtonsLawsFragment()); // Load NewtonsLawsFragment
                            break;
                        case Constants.KEY_PHYSICS_KINEMATIC_EQUATIONS:
                            loadFragment(new com.example.myfinalproject.gamesActivities.Physics.KinematicEquationFragment()); // Load KinematicEquationFragment
                            break;
                        case Constants.KEY_PHYSICS_MASTERING_FRICTION:
                            loadFragment(new com.example.myfinalproject.gamesActivities.Physics.MasteringFrictionFragment()); // Load MasteringFrictionFragment
                            break;
                        case Constants.KEY_PHYSICS_SANDBOX:
                            loadFragment(new com.example.myfinalproject.gamesActivities.Physics.PhysicSandBoxFragment()); // Load PhysicSandBoxFragment
                            break;
                        default:
                            // Step 4.5.1.1: Show a toast for an unknown physics subtopic
                            Toast.makeText(context, "Unknown subtopic: " + subTopicName, Toast.LENGTH_SHORT).show();
                            break;
                    }
                } else if (topicName.equals(Constants.KEY_CS)) {
                    // Step 4.5.2: Handle Computer Science subtopics
                    switch (subTopicName) {
                        case Constants.KEY_CS_INTRODUCTION:
                            loadFragment(new CSIntroductionFragment()); // Load CSIntroductionFragment
                            break;
                        case Constants.KEY_CS_VARIABLES:
                            loadFragment(new CodeWithVariablesFragment()); // Load CodeWithVariablesFragment
                            break;
                        case Constants.KEY_CS_VARIABLES_QUIZ:
                            loadFragment(new VariablesExerciseFragment()); // Load VariablesExerciseFragment
                            break;
                        case Constants.KEY_CS_CONDITIONALS:
                            loadFragment(new ConditionalsFragment()); // Load ConditionalsFragment
                            break;
                        default:
                            // Step 4.5.2.1: Show a toast for an unknown CS subtopic
                            Toast.makeText(context, "Unknown subtopic: " + subTopicName, Toast.LENGTH_SHORT).show();
                            break;
                    }
                }
            }
        });
    }

    // Function: loadFragment
    // Description: Replaces the current fragment in a container with a new fragment and adds the transaction to the back stack.
    // This method assumes the context is an instance of MainActivity and has a fragment container with ID R.id.fragment_container_main.
    // Input: Fragment fragment - The fragment instance to load.
    // Output: void (Loads the fragment into the container).
    private void loadFragment(Fragment fragment) {
        // Step 1: Get the FragmentManager from the MainActivity context
        FragmentManager fragmentManager = ((MainActivity) context).getSupportFragmentManager();
        // Step 2: Begin a FragmentTransaction
        fragmentManager.beginTransaction() // Use the passed fragmentManager
                // Step 3: Replace the fragment in the specified container with the new fragment
                .replace(R.id.fragment_container_main, fragment) // Use replace, not add
                // Step 4: Add the transaction to the back stack so the user can navigate back to the previous fragment
                .addToBackStack(null) // Add to the back stack so the user can navigate back
                // Step 5: Commit the transaction for it to take effect
                .commit();
    }

    /**
     * Function: handleSubtopicClick
     * Description: Manages single-selection logic for subtopics when one is clicked.
     * It updates the local and global selection states and notifies the adapter to refresh affected items.
     * Input: int position - The position of the clicked subtopic in the current list.
     * Output: void (Updates selection states and triggers UI refresh).
     */
    private void handleSubtopicClick(int position) {
        // Step 1: Get the SubTopicClass object for the clicked position
        SubTopicClass clickedSubtopic = subtopics.get(position);
        // Step 2: Store the previously selected position for efficient notification
        int previousPosition = selectedPosition;

        // Step 3: Deselect the previously selected subtopic if it exists and is different from the clicked one
        if (currentlySelectedSubtopic != null && currentlySelectedSubtopic != clickedSubtopic) {
            currentlySelectedSubtopic.setSelected(false);
        }

        // Step 4: Toggle selection of the clicked subtopic
        if (clickedSubtopic.isSelected()) {
            // Step 4.1: If it was already selected, deselect it (toggle off)
            clickedSubtopic.setSelected(false);
            currentlySelectedSubtopic = null; // Clear global selection
            selectedPosition = RecyclerView.NO_POSITION; // Clear local selection
        } else {
            // Step 4.2: If it was not selected, select it (toggle on)
            clickedSubtopic.setSelected(true);
            currentlySelectedSubtopic = clickedSubtopic; // Set global selection
            selectedPosition = position; // Set local selection
        }

        // Step 5: Notify the adapter to refresh the affected items' views
        // Step 5.1: If there was a previously selected item, notify its view to change
        if (previousPosition != RecyclerView.NO_POSITION) {
            notifyItemChanged(previousPosition);
        }
        // Step 5.2: Notify the newly selected (or deselected) item's view to change
        notifyItemChanged(selectedPosition);

        // Note: Using notifyDataSetChanged() might be simpler if many adapters are involved
        // or if state changes affect items not immediately adjacent to the clicked one,
        // but notifyItemChanged is more efficient for single item changes.
    }

    // Function: getItemCount
    // Description: Returns the total number of items (subtopics) in the data set held by the adapter.
    // Input: none
    // Output: int - The total number of subtopics. Returns 0 if the list is null.
    @Override
    public int getItemCount() {
        // Step 1: Return the size of the subtopics list if it's not null, otherwise return 0
        return subtopics != null ? subtopics.size() : 0;
    }

    /**
     * Class: SubtopicViewHolder
     * Description: ViewHolder for subtopic items. Holds references to the TextViews within each item layout.
     * Input: View itemView - the inflated layout for a single item.
     * Output: Provides references to the TextViews.
     */
    static class SubtopicViewHolder extends RecyclerView.ViewHolder {
        // View variables
        TextView subTopicName, subTopicProgress; // TextViews for name and progress

        // Function: Constructor
        // Description: Initializes the ViewHolder and finds the necessary TextViews within the item layout.
        // Input: View itemView - The root view of the subtopic item layout.
        // Output: Initializes the ViewHolder.
        SubtopicViewHolder(@NonNull View itemView) {
            // Step 1: Call the superclass constructor
            super(itemView);
            // Step 2: Find the TextView for the subtopic name by its ID
            subTopicName = itemView.findViewById(R.id.subTopicName);
            // Step 3: Find the TextView for the subtopic progress by its ID
            subTopicProgress = itemView.findViewById(R.id.subTopicProgress);
        }
    }
}
