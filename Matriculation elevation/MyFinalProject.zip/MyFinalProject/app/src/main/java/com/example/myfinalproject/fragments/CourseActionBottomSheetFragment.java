package com.example.myfinalproject.fragments;

import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.myfinalproject.R;
import com.example.myfinalproject.java_classes.Constants;
import com.example.myfinalproject.java_classes.CourseClass;
import com.example.myfinalproject.java_classes.SubTopicClass;
import com.example.myfinalproject.java_classes.UserInfoClass;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.Iterator;

public class CourseActionBottomSheetFragment extends BottomSheetDialogFragment {
    private String mode;
    private FirebaseFirestore firestore;
    private String userId;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        firestore = FirebaseFirestore.getInstance();
        userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        if (getArguments() != null) {
            mode = getArguments().getString("mode");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_course_action_bottom_sheet, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if ("add".equals(mode)) {
            setupAddMode();
        } else if ("remove".equals(mode)) {
            setupRemoveMode();
        } else {
            dismiss();
        }
    }

    // --- ADD MODE ---
    private void setupAddMode() {
        ListView listView = getView().findViewById(R.id.courseListContainer);
        ArrayList<CourseClass> courses = getAvailableCourses();
        final ArrayList<String> names = new ArrayList<>();
        for (CourseClass c : courses) names.add(c.getCourseName());

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, names);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, v, pos, id) -> {
            CourseClass selected = courses.get(pos);
            updateUserCourses(selected, true);
        });
    }

    // --- REMOVE MODE ---
    private void setupRemoveMode() {
        ListView listView = getView().findViewById(R.id.courseListContainer);

        // Fetch current user, then populate list
        firestore.collection("users")
                .document(userId)
                .get()
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful() || !task.getResult().exists()) {
                        Toast.makeText(getContext(), "Failed to load courses", Toast.LENGTH_SHORT).show();
                        dismiss();
                        return;
                    }
                    UserInfoClass user = task.getResult().toObject(UserInfoClass.class);
                    ArrayList<CourseClass> courses = user != null && user.getClasses() != null
                            ? user.getClasses() : new ArrayList<>();
                    final ArrayList<String> names = new ArrayList<>();
                    for (CourseClass c : courses) names.add(c.getCourseName());

                    ArrayAdapter<String> adapter =
                            new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, names);
                    listView.setAdapter(adapter);

                    listView.setOnItemClickListener((parent, v, pos, id) -> {
                        String name = names.get(pos);
                        showRemoveConfirmation(name, courses.get(pos));
                    });
                });
    }

    private void showRemoveConfirmation(String courseName, CourseClass courseObj) {
        new AlertDialog.Builder(getContext())
                .setMessage("Remove \"" + courseName + "\"?")
                .setPositiveButton("Yes", (dialog, which) -> updateUserCourses(courseObj, false))
                .setNegativeButton("No", null)
                .show();
    }

    // --- FIREBASE UPDATE (ADD or REMOVE) ---
    private void updateUserCourses(CourseClass course, boolean add) {
        DocumentReference ref = firestore.collection("users").document(userId);

        ref.get().addOnCompleteListener(task -> {
            if (!task.isSuccessful() || !task.getResult().exists()) {
                Toast.makeText(getContext(), "Update failed", Toast.LENGTH_SHORT).show();
                return;
            }

            UserInfoClass user = task.getResult().toObject(UserInfoClass.class);
            ArrayList<CourseClass> list = (user != null && user.getClasses() != null)
                    ? user.getClasses() : new ArrayList<>();

            if (add) {
                // Check if course already exists to prevent duplicates
                boolean alreadyAdded = false;
                for (CourseClass c : list) {
                    if (c.getCourseName().equals(course.getCourseName())) {
                        alreadyAdded = true;
                        break;
                    }
                }
                if (alreadyAdded) {
                    Toast.makeText(getContext(), "Course already added!", Toast.LENGTH_SHORT).show();
                    return;
                }
                list.add(course);
            } else {
                Iterator<CourseClass> it = list.iterator();
                while (it.hasNext()) {
                    if (it.next().getCourseName().equals(course.getCourseName())) {
                        it.remove();
                        break;
                    }
                }
            }

            ref.update("classes", list)
                    .addOnSuccessListener(aVoid -> {
                        String verb = add ? "added" : "removed";
                        Toast.makeText(getContext(),
                                course.getCourseName() + " " + verb + "!", Toast.LENGTH_SHORT).show();

                        // 🔥 NOW tell the parent to refresh
                        getParentFragmentManager()
                                .setFragmentResult("courses_updated", new Bundle());

                        dismiss();
                    })
                    .addOnFailureListener(e -> {
                        Log.e("FIREBASE", "Error updating courses", e);
                        Toast.makeText(getContext(), "Could not update", Toast.LENGTH_SHORT).show();
                    });
        });
    }

    // --- HARDCODED COURSE LIST ---
    private ArrayList<CourseClass> getAvailableCourses() {
        ArrayList<CourseClass> courseList = new ArrayList<>();

        // Physics
        ArrayList<SubTopicClass> physics = new ArrayList<>();
        physics.add(new SubTopicClass(Constants.KEY_PHYSICS_NEWTONS_LAWS,
                "Learn Newton's laws.", Constants.KEY_PHYSICS));
        physics.add(new SubTopicClass(Constants.KEY_PHYSICS_KINEMATIC_EQUATIONS,
                "Study motion.", Constants.KEY_PHYSICS));
        physics.add(new SubTopicClass(Constants.KEY_PHYSICS_MASTERING_FRICTION,
                "Understand friction.", Constants.KEY_PHYSICS));
        physics.add(new SubTopicClass(Constants.KEY_PHYSICS_SANDBOX,
                "Practice sandbox.", Constants.KEY_PHYSICS));

        courseList.add(new CourseClass(
                Constants.KEY_PHYSICS,
                "Become Physics expert",
                R.drawable.baseline_light_mode, // replace with your icon
                5,
                physics
        ));

        // Computer Science
        ArrayList<SubTopicClass> cs = new ArrayList<>();
        cs.add(new SubTopicClass(Constants.KEY_CS_INTRODUCTION,
                "Course intro.", Constants.KEY_CS));
        cs.add(new SubTopicClass(Constants.KEY_CS_VARIABLES,
                "Store variables.", Constants.KEY_CS));
        cs.add(new SubTopicClass(Constants.KEY_CS_VARIABLES_QUIZ,
                "Quiz yourself.", Constants.KEY_CS));
        cs.add(new SubTopicClass(Constants.KEY_CS_CONDITIONALS,
                "If statements.", Constants.KEY_CS));
        courseList.add(new CourseClass(
                Constants.KEY_CS,
                "Become Java expert",
                R.drawable.baseline_pc_for_cs_course, // replace with your icon
                5,
                cs
        ));

        return courseList;
    }
}
