package com.example.myfinalproject.fragments;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer; // Import MediaPlayer
import android.os.Bundle; // Import Bundle
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater; // Import LayoutInflater
import android.view.View; // Import View
import android.view.ViewGroup; // Import ViewGroup
import android.widget.Button; // Import Button
import android.widget.Switch; // Import android.widget.Switch
import android.widget.TextView; // Import TextView
import android.widget.Toast; // Import Toast

import androidx.annotation.NonNull; // Import annotations
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment; // Import Fragment

import com.example.myfinalproject.R; // Import R
// Make sure you have MaterialCardView if you are using it, though it's not directly referenced in this Java class
// import com.google.android.material.card.MaterialCardView;

import java.util.Random;

// Class: FunSettingsFragment
// Description: A Fragment providing fun and cosmetic settings, including buttons to
// show facts/jokes and a switch for disco lights.
// It also includes a button to play a specific sound effect.
// Input: none (as it's a Fragment for a ViewPager/settings screen)
// Output: Configures visual/audio effects and displays fun content based on user interaction.
public class FunSettingsFragment extends Fragment {
    private static final String TAG = "FunSettingsFragment"; // Tag for logging

    // UI Variables
    // private MaterialCardView funCosmeticSettingsCard; // Card view, not directly manipulated in this class after inflation
    private TextView textViewFunCosmetic; // Title text view
    private Button buttonFunFact; // Button to show a fun fact
    private Button buttonTellJoke; // Button to tell a joke
    private Button buttonSoundEffects; // Button to trigger a sound effect
    private Switch switchDiscoLights; // Switch for 'Disco Lights' effect
    private TextView funFactTextView; // TextView to display the fun fact
    private TextView jokeTextView; // TextView to display the joke

    // Media Player Variable
    private MediaPlayer mediaPlayer; // MediaPlayer instance for sound effects

    // State Variable
    private boolean soundEffectsEnabled = false; // Tracks if sound effects are conceptually enabled (used by the button text)

    // Disco Lights Variables
    private Handler discoHandler;
    private Runnable discoRunnable;
    private boolean isDiscoModeActive = false;
    private int[] discoColors = {
            Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.CYAN, Color.MAGENTA, Color.parseColor("#FFA500") // Orange
    };
    private int currentColorIndex = 0;
    private final long DISCO_INTERVAL = 300; // Milliseconds between color changes
    private Drawable originalBackground; // To store the original background of the view

    // Data: Fun Facts
    // Array of strings containing fun facts
    private final String[] funFacts = {
            "Did you know? A group of flamingos is called a flamboyance.",
            "Bananas are berries, but strawberries aren’t.",
            "Octopuses have three hearts. Bet your ex had none.",
            "Honey never spoils. Even ancient Egyptians had it.",
            "Sharks existed before trees. That’s some prehistoric beef."
    };

    // Data: Jokes
    // Array of strings containing jokes
    private final String[] jokes = {
            "Why did the scarecrow win an award? Because he was outstanding in his field.",
            "What do you call fake spaghetti? An impasta.",
            "Why don’t scientists trust atoms? Because they make up everything.",
            "Parallel lines have so much in common. Too bad they’ll never meet.",
            "Why did the math book look sad? It had too many problems."
    };

    // Function: onCreateView
    // Description: Called to create the view hierarchy for the fragment.
    // Input: LayoutInflater inflater - The LayoutInflater object that can be used to inflate any views in the fragment.
    // Input: ViewGroup container - If non-null, this is the parent view that the fragment's UI should be attached to.
    // Input: Bundle savedInstanceState - If non-null, this fragment is being re-constructed from a previous saved state.
    // Output: View - The root View of the fragment's layout.
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Step 1: Inflate the layout for this fragment from your XML file
        // Assuming your XML file is named 'item_fun_and_cosmetic.xml' or similar
        View view = inflater.inflate(R.layout.item_fun_and_cosmetic, container, false); // Replace with your actual layout file name
        // Step 2: Initialize UI views within the inflated layout
        initViews(view);
        // Step 3: Initialize Disco Light handler
        discoHandler = new Handler(Looper.getMainLooper());
        // Step 4: Set up event listeners for UI elements
        setListeners();
        // Step 5: Return the root view of the fragment
        return view;
    }

    // Function: initViews
    // Description: Initializes UI elements by finding them in the layout.
    // Input: View view - The root view of the fragment's layout.
    // Output: void (Initializes UI views).
    private void initViews(View view) {
        // Step 1: Find and assign the MaterialCardView (optional if not directly manipulated)
        // funCosmeticSettingsCard = view.findViewById(R.id.fun_cosmetic_settings_card);
        // Step 2: Find and assign the main TextView
        textViewFunCosmetic = view.findViewById(R.id.textViewFunCosmetic);
        // Step 3: Find and assign the Fun Fact button
        buttonFunFact = view.findViewById(R.id.button_fun_fact);
        // Step 4: Find and assign the Tell Joke button
        buttonTellJoke = view.findViewById(R.id.button_tell_joke);
        // Step 5: Find and assign the Sound Effects button
        buttonSoundEffects = view.findViewById(R.id.button_sound_effects);
        // Step 6: Find and assign the Disco Lights switch
        switchDiscoLights = view.findViewById(R.id.switch_disco_lights);
        // Step 7: Find and assign the TextView for displaying fun facts
        funFactTextView = view.findViewById(R.id.funFact);
        // Step 8: Find and assign the TextView for displaying jokes
        jokeTextView = view.findViewById(R.id.joke);

        // Store the original background of the fragment's root view
        if (getView() != null) {
            originalBackground = getView().getBackground();
        } else {
            // If getView() is null here (e.g., called too early), try to get it in onViewCreated or store a default
            // For simplicity, we'll rely on it being available later or default to white if needed.
            originalBackground = new ColorDrawable(Color.WHITE); // Default fallback
        }


        Log.d(TAG, "Views initialized.");
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // It's safer to get the view's background here as the view is guaranteed to be created.
        if (view != null) {
            originalBackground = view.getBackground();
            if (originalBackground == null) { // If no background is set, default to white for restoration
                originalBackground = new ColorDrawable(Color.WHITE);
            }
        }
    }

    // Function: setListeners
    // Description: Sets up click and checked change listeners for buttons and switches.
    // Input: none
    // Output: void (Sets up listeners).
    private void setListeners() {
        // Step 1: Set a click listener for the Fun Fact button
        buttonFunFact.setOnClickListener(v -> {
            // Step 1.1: Generate a random index within the bounds of the funFacts array
            int index = new Random().nextInt(funFacts.length);
            // Step 1.2: Set the text of the funFactTextView to the randomly selected fun fact
            funFactTextView.setText(funFacts[index]);
            // Step 1.3: Make the funFactTextView visible
            funFactTextView.setVisibility(View.VISIBLE);
            // Step 1.4: Hide the joke TextView if it's visible
            jokeTextView.setVisibility(View.GONE);
            Log.d(TAG, "Fun Fact button clicked. Displaying fact: " + funFacts[index]);
        });

        // Step 2: Set a click listener for the Tell Joke button
        buttonTellJoke.setOnClickListener(v -> {
            // Step 2.1: Generate a random index within the bounds of the jokes array
            int index = new Random().nextInt(jokes.length);
            // Step 2.2: Set the text of the jokeTextView to the randomly selected joke
            jokeTextView.setText(jokes[index]);
            // Step 2.3: Make the jokeTextView visible
            jokeTextView.setVisibility(View.VISIBLE);
            // Step 2.4: Hide the fun fact TextView if it's visible
            funFactTextView.setVisibility(View.GONE);
            Log.d(TAG, "Tell Joke button clicked. Displaying joke: " + jokes[index]);
        });

        // Step 3: Set a click listener for the Sound Effects button
        buttonSoundEffects.setOnClickListener(v -> {
            // Step 3.1: Toggle the soundEffectsEnabled boolean state
            soundEffectsEnabled = !soundEffectsEnabled;
            Context context = getContext(); // Get context for Toast

            // Step 3.2: Check the new state of soundEffectsEnabled
            if (soundEffectsEnabled) {
                // Step 3.2.1: If enabled, show a toast message
                if (context != null) Toast.makeText(context, "Silly Sound FX enabled!", Toast.LENGTH_SHORT).show();
                // Step 3.2.2: Update the button text
                buttonSoundEffects.setText("Disable Silly Sound FX");
                // Step 3.2.3: Play the sound effect using the helper method
                playSoundEffect();
                Log.d(TAG, "Sound Effects button clicked. Enabled.");
            } else {
                // Step 3.2.4: If disabled, show a toast message
                if (context != null) Toast.makeText(context, "Silly Sound FX disabled!", Toast.LENGTH_SHORT).show();
                // Step 3.2.5: Update the button text
                buttonSoundEffects.setText("Enable Silly Sound FX");
                // Step 3.2.6: Stop any currently playing sound effect
                stopSoundEffect();
                Log.d(TAG, "Sound Effects button clicked. Disabled.");
            }
        });

        // Step 4: Set a checked change listener for the Disco Lights switch (using lambda)
        switchDiscoLights.setOnCheckedChangeListener((buttonView, isChecked) -> {
            Context context = getContext(); // Get context for Toast
            isDiscoModeActive = isChecked; // Update the flag

            if (isChecked) {
                if (context != null) Toast.makeText(context, "Disco lights are ON 🎇", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "Disco Lights switch toggled. ON.");
                startDiscoLights();
            } else {
                if (context != null) Toast.makeText(context, "Disco lights are OFF.", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "Disco Lights switch toggled. OFF.");
                stopDiscoLights();
            }
        });
        Log.d(TAG, "Listeners set.");
    }

    private void startDiscoLights() {
        if (getView() == null) {
            Log.e(TAG, "Cannot start disco lights, view is null.");
            return;
        }
        // Store original background if not already stored or if it was null
        if (originalBackground == null) {
            originalBackground = getView().getBackground();
            if (originalBackground == null) {
                originalBackground = new ColorDrawable(Color.WHITE); // Default if still null
            }
        }

        isDiscoModeActive = true;
        currentColorIndex = 0; // Reset color index

        discoRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isDiscoModeActive || getView() == null) {
                    // If disco mode was turned off or fragment view is gone, stop.
                    if (getView() != null && originalBackground != null) {
                        getView().setBackground(originalBackground); // Restore original
                    }
                    return;
                }
                // Set the background color
                getView().setBackgroundColor(discoColors[currentColorIndex]);
                // Move to the next color
                currentColorIndex = (currentColorIndex + 1) % discoColors.length;
                // Schedule the next color change
                discoHandler.postDelayed(this, DISCO_INTERVAL);
            }
        };
        // Start the disco effect
        discoHandler.post(discoRunnable);
    }

    private void stopDiscoLights() {
        isDiscoModeActive = false;
        if (discoHandler != null && discoRunnable != null) {
            discoHandler.removeCallbacks(discoRunnable);
        }
        // Restore original background
        if (getView() != null && originalBackground != null) {
            getView().setBackground(originalBackground);
            Log.d(TAG, "Disco lights stopped. Original background restored.");
        } else if (getView() != null) {
            // Fallback if originalBackground was somehow null
            getView().setBackgroundColor(Color.WHITE); // Or your app's default background
            Log.d(TAG, "Disco lights stopped. Fallback background restored.");
        }
    }


    // Function: playSoundEffect
    // Description: Creates and starts a MediaPlayer to play a specific sound effect from raw resources.
    // Releases any previous MediaPlayer instance before playing a new sound.
    // Input: none
    // Output: void (Plays the sound effect or shows an error toast).
    private void playSoundEffect() {
        Context context = getContext();
        if (context == null) {
            Log.e(TAG, "Context is null in playSoundEffect. Cannot play sound.");
            return;
        }

        // Step 1: Release any existing MediaPlayer instance to prevent resource leaks
        stopSoundEffect(); // Use a separate method to stop and release

        // Step 2: Create a new MediaPlayer instance from the raw resource file
        // IMPORTANT: Make sure you have a sound file named 'epic_hybrid_logo_157092.mp3' (or similar)
        // in your 'res/raw/' directory.
        mediaPlayer = MediaPlayer.create(context, R.raw.epic_hybrid_logo_157092);

        // Step 3: Check if the MediaPlayer was created successfully
        if (mediaPlayer != null) {
            // Step 3.1: If successful, start playback of the sound effect
            mediaPlayer.start();
            Log.d(TAG, "Sound effect started.");
            // Step 3.2: Set a listener to release the player when playback completes
            mediaPlayer.setOnCompletionListener(mp -> {
                Log.d(TAG, "Sound effect completed.");
                stopSoundEffect(); // Release when done
            });
            mediaPlayer.setOnErrorListener((mp, what, extra) -> {
                Log.e(TAG, "MediaPlayer error: what=" + what + ", extra=" + extra);
                if (getContext() != null) Toast.makeText(getContext(), "Error playing sound effect.", Toast.LENGTH_SHORT).show();
                stopSoundEffect(); // Release on error
                return true; // True if the error has been handled
            });
        } else {
            // Step 3.3: If creation failed (e.g., file not found or invalid), show an error toast
            Log.e(TAG, "Failed to create MediaPlayer. Check res/raw/epic_hybrid_logo_157092");
            if (getContext() != null) Toast.makeText(getContext(), "Failed to load sound. Check your res/raw/ sound file!", Toast.LENGTH_LONG).show();
        }
    }

    // Function: stopSoundEffect
    // Description: Stops and releases the MediaPlayer instance if it exists.
    private void stopSoundEffect() {
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                mediaPlayer.release();
            } catch (IllegalStateException e) {
                Log.e(TAG, "Error stopping/releasing MediaPlayer: " + e.getMessage());
            } finally {
                mediaPlayer = null; // Set to null after releasing
                Log.d(TAG, "MediaPlayer released/nulled.");
            }
        }
    }

    // Function: onStop
    // Description: Called when the fragment is no longer visible to the user.
    // Good place to release resources like MediaPlayer and stop animations.
    @Override
    public void onStop() {
        super.onStop();
        Log.d(TAG, "onStop called.");
        // Step 1: Release the MediaPlayer when the fragment is stopped to free resources
        stopSoundEffect();
        // Step 2: Stop disco lights if active
        if (isDiscoModeActive) {
            stopDiscoLights();
            // Optionally, persist the state of the switch if needed
            // switchDiscoLights.setChecked(false); // Or save to SharedPreferences
        }
    }

    // Function: onDestroyView
    // Description: Called when the view previously created by onCreateView has been detached from the fragment.
    // Good place to clean up references to views and remove callbacks.
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.d(TAG, "onDestroyView called.");

        // Stop disco lights and remove callbacks
        if (discoHandler != null && discoRunnable != null) {
            discoHandler.removeCallbacks(discoRunnable);
        }
        isDiscoModeActive = false; // Ensure flag is reset

        // Set view references to null to help with garbage collection
        buttonFunFact = null;
        buttonTellJoke = null;
        buttonSoundEffects = null;
        switchDiscoLights = null;
        funFactTextView = null;
        jokeTextView = null;
        textViewFunCosmetic = null;
        // funCosmeticSettingsCard = null;
        discoHandler = null; // Nullify handler
        discoRunnable = null; // Nullify runnable
        originalBackground = null; // Nullify background reference
    }
}