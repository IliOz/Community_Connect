package com.example.myfinalproject.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myfinalproject.fragments.LoadingFragment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.example.myfinalproject.R;
import com.example.myfinalproject.java_classes.Constants;
import com.example.myfinalproject.services.MusicPlayer;
import com.example.myfinalproject.java_classes.ValidationManager;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

/**
 * Activity responsible for user authentication.
 * Handles login, auto-login (remember me), and sign-up redirection.
 */
public class LogInActivity extends AppCompatActivity {
    private EditText emailInput, passwordInput;
    private Button btnSignIn;
    private TextView tvSignupLink;
    private CheckBox rememberMe;
    private FirebaseAuth mAuth;
    private Toolbar toolbar;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable enableButtonRunnable;

    private static final String PREF_NAME = "audio_settings_prefs";
    private static final String KEY_MUSIC_ON = "music_on_status";
    private static final String KEY_VOLUME = "music_volume_level";

    /**
     * SYSTEM FUNCTION — called when Activity is created.
     * Command:
     * - Call `initViews()` to hook up UI.
     * - Start background music.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        initViews();     // connect UI elements
        startMusic();
    }

    /**
     * FUNCTION: startMusic()
     * PURPOSE: Starts the music service using intent with "PLAY" action.
     * Input: none
     * Output: none
     */
    private void startMusic() {
        SharedPreferences prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        if (!prefs.contains(KEY_MUSIC_ON)) {
            editor.putBoolean(KEY_MUSIC_ON, true); // Default music to ON
            editor.putInt(KEY_VOLUME, 50);        // Default volume to 50 (assuming 0-100 range)
            editor.apply();                       // Apply the changes asynchronously
        }

        // Check if music should be played based on preferences
        if (!prefs.getBoolean(KEY_MUSIC_ON, false)){
            return; // Don't start music if it's set to off
        }

        // Get volume and convert to float (0.0 to 1.0)
        float musicAudio = prefs.getInt(KEY_VOLUME, 50) / 100f;

        Intent serviceIntent = new Intent(this, MusicPlayer.class);
        // ***** THE CRITICAL FIX IS HERE *****
        serviceIntent.setAction(MusicPlayer.ACTION_PLAY); // Use the constant from MusicPlayer service
        // *************************************
        serviceIntent.putExtra(MusicPlayer.EXTRA_VOLUME, musicAudio);
        ContextCompat.startForegroundService(this, serviceIntent);
    }

    /**
     * SYSTEM FUNCTION — runs when Activity comes to foreground.
     * Command:
     * - Check if user is already signed in and marked as "remembered".
     * - If so, go directly to MainActivity.
     * - Else, set up click listeners.
     */
    @Override
    public void onStart() {
        super.onStart();
        startMusic();    // play background music
        FirebaseUser currentUser = mAuth.getCurrentUser();
        SharedPreferences prefs = getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE);

        // Check if there's a current user and if they are marked for "remember me"
        if (currentUser != null && prefs.getBoolean(Constants.KEY_REMEMBER_USER, false)) {
            // User is logged in, show a toast and navigate to MainActivity
            Toast.makeText(this, "User: " + currentUser.getEmail(), Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class));
            finish(); // Finish the login activity
        }

        setOnClickListeners(); // Set up UI event listeners (login/signup)
    }

    /**
     * FUNCTION: initViews()
     * PURPOSE: Binds UI elements and Firebase instances.
     * Input: none
     * Output: none
     */
    private void initViews() {
        // Bind UI elements from XML
        emailInput = findViewById(R.id.emailInput);
        passwordInput = findViewById(R.id.passwordInput);
        btnSignIn = findViewById(R.id.btn_signin);
        tvSignupLink = findViewById(R.id.signup_link);
        rememberMe = findViewById(R.id.remember);

        // Initialize Firebase Authentication instance
        mAuth = FirebaseAuth.getInstance();

        // Set up the toolbar for the activity
        toolbar = findViewById(R.id.toolbarLogin);
        setSupportActionBar(toolbar); // Set the toolbar as the action bar
    }

    /**
     * FUNCTION: setOnClickListeners()
     * PURPOSE: Sets up listeners for:
     * - Checkbox (remember me)
     * - Signup text click
     * - Signin button click
     * Input: none
     * Output: none
     */
    private void setOnClickListeners() {
        // SharedPreferences to store user preferences
        SharedPreferences prefs = getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE);
        prefs.edit().putBoolean(Constants.KEY_REMEMBER_USER, false).apply(); // Reset "remember me" on start

        // Set listener for the "remember me" checkbox
        rememberMe.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton cb, boolean isChecked) {
                // Save the preference to SharedPreferences when checkbox state changes
                prefs.edit().putBoolean(Constants.KEY_REMEMBER_USER, isChecked).apply();
            }
        });

        // Set listener for "Sign Up" link click
        tvSignupLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to the SignUpActivity when "Don't have an account?" is clicked
                startActivity(new Intent(LogInActivity.this, SignUpActivity.class));
            }
        });

        // Set listener for the "Sign In" button click
        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailInput.getText().toString().trim(); // Get email input
                String password = passwordInput.getText().toString();  // Get password input

                // Validate input data using the ValidationManager
                if (!ValidationManager.validateUserInfo(emailInput, passwordInput)) {
                    return; // Validation failed, errors are already displayed
                }

                // Proceed with signing in if validation passes
                signInWithEmailAndPassword(email, password);
            }
        });
    }

    /**
     * FUNCTION: signInWithEmailAndPassword()
     * PURPOSE: Starts loading fragment to handle Firebase login.
     * INPUT:
     * - String email
     * - String password
     * OUTPUT: none (UI is updated via Fragment)
     */
    private void signInWithEmailAndPassword(String email, String password) {
        // Bundle to pass email, password, and other flags to the LoadingFragment
        Bundle args = new Bundle();
        args.putString(Constants.KEY_EMAIL, email);
        args.putString(Constants.KEY_PASSWORD, password);
        args.putInt(Constants.KEY_WHICH_ACTIVITY_CALLED, 1); // 1 = LogInActivity

        // Create and show the loading fragment during the login process
        LoadingFragment loadingFragment = new LoadingFragment();
        loadingFragment.setArguments(args);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container_log_in, loadingFragment)
                .commit(); // No back stack. You don’t go back to login.
    }

    /**
     * SYSTEM FUNCTION — builds the top-right options menu.
     * Hides unnecessary buttons during login.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu from XML
        getMenuInflater().inflate(R.menu.menu, menu);

        // Hide unnecessary menu items when the user is on the login screen
        menu.findItem(R.id.menu_log_out).setVisible(false);
        menu.findItem(R.id.menu_home).setVisible(false);
        menu.findItem(R.id.menu_profile).setVisible(false);
        menu.findItem(R.id.menu_go_back).setVisible(false);

        return super.onCreateOptionsMenu(menu);
    }

    /**
     * SYSTEM FUNCTION — handles menu item clicks.
     * Command:
     * - If "Settings" is clicked, open SettingsActivity.
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Check if the Settings item was selected
        if (item.getItemId() == R.id.menu_settings) {
            // Open the SettingsActivity if clicked
            startActivity(new Intent(this, SettingsActivity.class));
            finish(); // Close LogInActivity
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * SYSTEM FUNCTION — called when Activity is destroyed.
     * Command:
     * - Remove pending callbacks to prevent memory leaks.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (enableButtonRunnable != null) {
            handler.removeCallbacks(enableButtonRunnable); // Clean up pending callback
        }
    }
}
