package com.example.myfinalproject.fragments;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.example.myfinalproject.R; // Ensure R.layout.item_audio_settings and view IDs exist
import com.example.myfinalproject.services.MusicPlayer;

public class AudioSettingsFragment extends Fragment {
    private static final String TAG = "AudioSettingsFragment";
    // SharedPreferences keys for storing settings
    private static final String PREF_NAME = "audio_settings_prefs";
    private static final String KEY_MUSIC_ON = "music_on_status";
    private static final String KEY_VOLUME = "music_volume_level";

    private SwitchCompat switchMusic;
    private SeekBar seekbarVolume;
    private boolean isProgrammaticChange = false; // Flag to avoid triggering listeners during UI setup

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        // Ensure 'item_audio_settings.xml' exists in 'res/layout/'
        // and contains SwitchCompat with id 'switch_music' and SeekBar with id 'seekbar_volume'.
        View view = inflater.inflate(R.layout.item_audio_settings, container, false);

        // Initialize UI elements
        switchMusic = view.findViewById(R.id.switch_music);
        seekbarVolume = view.findViewById(R.id.seekbar_volume);

        if (switchMusic == null || seekbarVolume == null) {
            Log.e(TAG, "Could not find one or more views. Check layout file and IDs.");
            // Handle error appropriately, maybe show a message to the user or disable functionality
            Toast.makeText(getContext(), "Error initializing audio settings UI.", Toast.LENGTH_LONG).show();
        }

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume called");
        // Load saved settings and apply them to the UI
        loadSettingsAndApplyUI();
        // Set up listeners for UI interactions
        setupListeners();
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG, "onPause called");
        // It's good practice to remove listeners if they might interact with a detached context,
        // though for SharedPreferences it's less critical than for, e.g., service broadcasts.
        // Here, simply not acting on changes when paused is usually sufficient.
    }

    private SharedPreferences getAudioPreferences() {
        return requireActivity().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    private boolean isMusicOn() {
        return getAudioPreferences().getBoolean(KEY_MUSIC_ON, false); // Default to off
    }

    private int getMusicVolume() {
        // SeekBar progress is 0-100, volume for MediaPlayer is 0.0f-1.0f
        return getAudioPreferences().getInt(KEY_VOLUME, 50); // Default to 50%
    }

    private void saveMusicOnState(boolean isOn) {
        getAudioPreferences().edit().putBoolean(KEY_MUSIC_ON, isOn).apply();
        Log.d(TAG, "Music on state saved: " + isOn);
    }

    private void saveMusicVolume(int volume) {
        getAudioPreferences().edit().putInt(KEY_VOLUME, volume).apply();
        Log.d(TAG, "Music volume saved: " + volume);
    }

    private void loadSettingsAndApplyUI() {
        if (switchMusic == null || seekbarVolume == null) {
            Log.w(TAG, "Views not initialized, cannot apply UI settings.");
            return;
        }

        isProgrammaticChange = true; // Prevent listeners from firing during setup

        boolean musicCurrentlyOn = isMusicOn();
        int currentVolume = getMusicVolume();

        Log.d(TAG, "Loading settings - Music On: " + musicCurrentlyOn + ", Volume: " + currentVolume);

        switchMusic.setChecked(musicCurrentlyOn);
        seekbarVolume.setProgress(currentVolume); // SeekBar progress is 0-100

        // Enable/disable seekbar based on music switch state
        seekbarVolume.setEnabled(musicCurrentlyOn);

        isProgrammaticChange = false;
    }

    private void setupListeners() {
        if (switchMusic == null || seekbarVolume == null) {
            Log.w(TAG, "Views not initialized, cannot set up listeners.");
            return;
        }

        switchMusic.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isProgrammaticChange) return; // Don't react to programmatic changes

            Log.d(TAG, "SwitchMusic toggled. IsChecked: " + isChecked);
            saveMusicOnState(isChecked);
            seekbarVolume.setEnabled(isChecked); // Enable/disable volume control

            Intent musicServiceIntent = new Intent(requireContext(), MusicPlayer.class);
            if (isChecked) {
                musicServiceIntent.setAction(MusicPlayer.ACTION_PLAY);
                // Convert SeekBar progress (0-100) to float volume (0.0-1.0)
                float volumeLevel = getMusicVolume() / 100f;
                musicServiceIntent.putExtra(MusicPlayer.EXTRA_VOLUME, volumeLevel);
                Toast.makeText(getContext(), "Music starting...", Toast.LENGTH_SHORT).show();
            } else {
                musicServiceIntent.setAction(MusicPlayer.ACTION_STOP);
                Toast.makeText(getContext(), "Music stopping...", Toast.LENGTH_SHORT).show();
            }
            // Start the service as a foreground service
            ContextCompat.startForegroundService(requireContext(), musicServiceIntent);
        });

        seekbarVolume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    if (isProgrammaticChange) return;

                    Log.d(TAG, "SeekBar progress changed by user to: " + progress);
                    // Save volume immediately as it changes
                    saveMusicVolume(progress);

                    // If music is currently on, send volume update to service
                    if (isMusicOn()) {
                        Intent volumeIntent = new Intent(requireContext(), MusicPlayer.class);
                        volumeIntent.setAction(MusicPlayer.ACTION_SET_VOLUME);
                        float volumeLevel = progress / 100f;
                        volumeIntent.putExtra(MusicPlayer.EXTRA_VOLUME, volumeLevel);
                        ContextCompat.startForegroundService(requireContext(), volumeIntent);
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Optional: Can be used for UI feedback, e.g., showing a Toast
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // The volume is already saved in onProgressChanged if fromUser is true.
                // You could show a confirmation Toast here if desired.
                int finalProgress = seekBar.getProgress();
                Log.d(TAG, "SeekBar tracking stopped. Final progress: " + finalProgress);
                // Toast.makeText(getContext(), "Volume set to " + finalProgress + "%", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
