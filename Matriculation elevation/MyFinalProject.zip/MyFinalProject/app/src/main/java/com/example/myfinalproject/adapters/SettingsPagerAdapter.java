package com.example.myfinalproject.adapters;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity; // Import FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.myfinalproject.fragments.AudioSettingsFragment; // Import fragment classes
import com.example.myfinalproject.fragments.FunSettingsFragment;
import com.example.myfinalproject.fragments.AdvancedOptionsFragment;


// Class: SettingsPagerAdapter
// Description: Adapter for a ViewPager2 that provides the correct Fragment for each page (tab)
// in the settings screen. It extends FragmentStateAdapter, which is suitable for a large
// number of fragments as it handles fragment state efficiently.
// Input: Requires a FragmentActivity to manage the fragments.
// Output: Provides Fragment instances based on position.
public class SettingsPagerAdapter extends FragmentStateAdapter {
    public SettingsPagerAdapter(@NonNull FragmentActivity fa) {
        super(fa);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0: return new AudioSettingsFragment();
            case 1: return new AdvancedOptionsFragment();
            case 2: return new FunSettingsFragment();
            default: return new Fragment();
        }
    }

    @Override
    public int getItemCount() {
        return 3;
    }
}