package com.example.myfinalproject.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myfinalproject.R;
import com.example.myfinalproject.java_classes.CourseClass;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Class: CoursesRecyclerViewAdapter
 * Description: Adapter for displaying a list of {@link CourseClass} objects in a RecyclerView.
 * Each course can be expanded to show its subtopics, which are displayed in a nested RecyclerView.
 * Input: Data is an ArrayList of CourseClass objects.
 * Output: Populates rows (course cards) in a RecyclerView, including nested subtopic lists.
 */
public class CoursesRecyclerViewAdapter extends RecyclerView.Adapter<CoursesRecyclerViewAdapter.CourseViewHolder> {

    // Variables
    private final Context context; // Context (final, cannot be reassigned)
    private ArrayList<CourseClass> courses; // List of CourseClass objects to display
    private final ArrayList<Boolean> courseSelectionState; // Tracks expanded/collapsed state for each course. true if expanded.


    /**
     * Function: Constructor
     * Description: Constructs a CoursesRecyclerViewAdapter.
     * Input: Context context - the context of the activity or fragment
     * Input: ArrayList<CourseClass> courses - the initial list of courses to display
     * Output: Initializes the adapter with context, data, and sets initial state (all collapsed).
     */
    public CoursesRecyclerViewAdapter(Context context, ArrayList<CourseClass> courses) {
        // Step 1: Assign the provided context to the class variable
        this.context = context;
        // Step 2: Assign the provided list of courses to the class variable
        this.courses = courses;
        // Step 3: Initialize the courseSelectionState list with the same size as the courses list
        // Step 4: Initialize all states to 'false' (collapsed) initially
        this.courseSelectionState = new ArrayList<>(Collections.nCopies(this.courses.size(), false));
    }

    /**
     * Function: setCourses
     * Description: Updates the list of courses and refreshes the RecyclerView.
     * Input: ArrayList<CourseClass> courses - The new list of courses to display.
     * Output: void (Updates the internal data and refreshes the UI, resetting expanded state).
     */
    public void setCourses(ArrayList<CourseClass> courses) {
        // Step 1: Assign the new list of courses to the class variable
        this.courses = courses;
        // Step 2: Clear the existing selection state list
        courseSelectionState.clear(); // Clear to make the list empty, in order to repopulate it
        // Step 3: Add 'false' states for each course in the new list (resets expansion state to collapsed)
        courseSelectionState.addAll(Collections.nCopies(courses.size(), false));
        // Step 4: Notify the RecyclerView that the entire data set has changed, prompting a full refresh
        notifyDataSetChanged();
    }

    // Function: onCreateViewHolder
    // Description: Called when RecyclerView needs a new ViewHolder of the given type to represent an item.
    // Input: ViewGroup parent - The ViewGroup into which the new View will be added after it is bound to an adapter position.
    // Input: int viewType - The view type of the new View.
    // Output: CourseViewHolder - A new ViewHolder that holds a View of the given view type.
    @NonNull
    @Override
    public CourseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Step 1: Inflate the layout for a single course item (course_card).
        View view = LayoutInflater.from(context).inflate(R.layout.item_course_card, parent, false);
        // Step 2: Create a new CourseViewHolder instance with the inflated view
        return new CourseViewHolder(view);
    }

    // Function: onBindViewHolder
    // Description: Called by RecyclerView to display the data at the specified position.
    // Input: CourseViewHolder holder - The ViewHolder which should be updated to represent the contents of the item at the given position.
    // Input: int position - The position of the item within the adapter's data set.
    // Output: void (Updates the contents of the ViewHolder's views based on the data at the position).
    @Override
    public void onBindViewHolder(@NonNull CourseViewHolder holder, int position) {
        // Step 1: Handle empty list scenario to prevent index out of bounds
        if (courses.isEmpty() || courseSelectionState.isEmpty()) {
            return;
        }
        // Step 2: Get the CourseClass object for the item at the current position
        CourseClass course = courses.get(position);

        // Step 3: Set the course title and description text in the ViewHolder's TextViews.
        holder.courseTitle.setText(course.getCourseName());
        holder.courseDescription.setText(course.getCourseDescription());

        // Step 4: Set a click listener on the entire item view to toggle expansion state
        holder.itemView.setOnClickListener(v -> {
            // Step 4.1: Get the adapter position of the clicked item (safe way)
            int adapterPosition = holder.getAdapterPosition();
            // Step 4.2: Check if the position is valid
            if (adapterPosition != RecyclerView.NO_POSITION) {
                // Step 4.3: Toggle the boolean state in the courseSelectionState list for the clicked position
                courseSelectionState.set(adapterPosition, !courseSelectionState.get(adapterPosition));
                // Step 4.4: Notify the adapter that *only* this specific item has changed, prompting re-binding
                notifyItemChanged(adapterPosition); // Efficiently update only the changed item.
            }
        });

        // Step 5: Show or hide the subtopics layout based on the expansion state from courseSelectionState list
        holder.subtopicsLayout.setVisibility(courseSelectionState.get(position) ? View.VISIBLE : View.GONE);

        // Step 6: Update the data in the nested RecyclerView's adapter (the SubtopicAdapter)
        // Step 6.1: Check if the course has subtopics and if the subtopics list is not empty
        if (course.getSubtopics() != null && !course.getSubtopics().isEmpty()) {
            // Step 6.2: Set the course's subtopics list to the nested adapter
            holder.subtopicAdapter.setSubtopics(course.getSubtopics());
        } else {
            // Step 6.3: If there are no subtopics, provide an empty list to the nested adapter
            holder.subtopicAdapter.setSubtopics(new ArrayList<>());
        }
    }

    // Function: getItemCount
    // Description: Returns the total number of items in the data set held by the adapter.
    // Input: none
    // Output: int - The total number of items (courses) in this adapter.
    @Override
    public int getItemCount() {
        // Step 1: Return the size of the courses list
        return courses.size(); // Return the number of courses.
    }

    /**
     * Class: CourseViewHolder
     * Description: ViewHolder for course items. Holds references to the views within each item,
     * including the nested RecyclerView for subtopics.
     * Input: View itemView - the inflated layout for a single item.
     * Output: Provides references to the TextViews, LinearLayout, and nested RecyclerView within the item layout.
     */
    public static class CourseViewHolder extends RecyclerView.ViewHolder {
        // View variables
        TextView courseTitle; // TextView for the course title
        TextView courseDescription; // TextView for the course description
        LinearLayout subtopicsLayout; // Layout containing the nested RecyclerView (shown/hidden)
        RecyclerView subtopicsRecyclerView; // The nested RecyclerView for subtopics
        SubtopicAdapter subtopicAdapter; // Adapter for the *nested* RecyclerView displaying subtopics

        // Function: Constructor
        // Input: View itemView - the root view of the item layout
        // Output: Initializes the ViewHolder and finds the necessary views, sets up the nested RecyclerView.
        public CourseViewHolder(@NonNull View itemView) {
            // Step 1: Call the superclass constructor
            super(itemView);
            // Step 2: Find the TextView for the course title
            courseTitle = itemView.findViewById(R.id.course_title);
            // Step 3: Find the TextView for the course description
            courseDescription = itemView.findViewById(R.id.course_description);
            // Step 4: Find the LinearLayout that wraps the subtopics RecyclerView
            subtopicsLayout = itemView.findViewById(R.id.subtopics_layout);
            // Step 5: Find the nested RecyclerView for subtopics
            subtopicsRecyclerView = itemView.findViewById(R.id.recyclerView_courses); // Correct ID - note: ID reuse

            // Step 6: Initialize and set up the nested RecyclerView:
            // Step 6.1: Set the LayoutManager for the nested RecyclerView (vertical list)
            subtopicsRecyclerView.setLayoutManager(new LinearLayoutManager(itemView.getContext()));
            // Step 6.2: Initialize the adapter for the nested RecyclerView with context and an empty list initially.
            subtopicAdapter = new SubtopicAdapter(itemView.getContext(), new ArrayList<>()); // Pass context and empty list initially.
            // Step 6.3: Set the adapter to the nested RecyclerView
            subtopicsRecyclerView.setAdapter(subtopicAdapter);
        }
    }
}
