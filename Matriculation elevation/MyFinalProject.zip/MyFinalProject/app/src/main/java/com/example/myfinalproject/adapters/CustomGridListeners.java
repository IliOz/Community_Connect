package com.example.myfinalproject.adapters;

import android.content.Context;
import android.util.Log;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import com.example.myfinalproject.java_classes.CourseClass; // Assuming CourseClass is used

import java.util.ArrayList;
import java.util.List;

// Class: CustomGridListeners
// Description: Provides custom OnItemClickListener instances for GridView widgets,
// specifically for handling icon selection and course selection with visual feedback.
// Input: Requires a Context during initialization.
// Output: Provides AdapterView.OnItemClickListener objects.
public class CustomGridListeners {

    // Constants
    private static final String TAG = "CustomGridListeners"; // Tag for logging

    // Variables
    private final Context context; // Context (final, cannot be reassigned)
    private boolean isExpanded = false; // Tracks if the icon grid is expanded
    private int selectedIconResId = -1; // Stores the resource ID of the currently selected icon
    private List<Integer> fullIconList = new ArrayList<>(); // Stores the full list of icon resource IDs

    // Function: Constructor
    // Description: Initializes the CustomGridListeners with the application context.
    // Input: Context context - The context to use for Toast messages and other context-dependent operations.
    // Output: Initializes the object.
    public CustomGridListeners(Context context) {
        // Step 1: Assign the provided context to the class variable
        this.context = context;
        // Step 2: Log that the listener object has been initialized
        Log.d(TAG, "CustomGridListeners initialized.");
    }

    // Function: setFullIconList
    // Description: Sets the complete list of available icon resource IDs. Resets selection state.
    // Input: List<Integer> fullIconList - The list of icon resource IDs.
    // Output: void (Updates the internal list and resets selection state).
    public void setFullIconList(List<Integer> fullIconList) {
        // Step 1: Check if the provided list is not null
        if (fullIconList != null) {
            // Step 1.1: Create a new ArrayList to store the provided list (defensive copy)
            this.fullIconList = new ArrayList<>(fullIconList);
            // Step 1.2: Log the size of the list that was set
            Log.d(TAG, "Full icon list set with " + this.fullIconList.size() + " items.");
        } else {
            // Step 2: If the provided list is null, initialize the internal list as empty
            this.fullIconList = new ArrayList<>();
            // Step 2.1: Log that the list was set as empty
            Log.d(TAG, "Full icon list set as empty.");
        }
        // Step 3: Reset the selected icon resource ID to -1 (no icon selected)
        this.selectedIconResId = -1;
        // Step 4: Reset the expanded state of the grid to false (collapsed)
        this.isExpanded = false;
        // Step 5: Log the reset of the selected icon ID
        Log.d("IconSelectDebug", TAG + ": selectedIconResId reset to -1 in setFullIconList.");
    }

    // Function: getIconClickListener
    // Description: Creates and returns an OnItemClickListener specifically for an icon selection GridView.
    // Manages expanding and collapsing the grid and tracking the selected icon.
    // Input: GridView iconGrid - The GridView displaying the icons.
    // Input: IconAdapter adapter - The adapter used by the iconGrid.
    // Output: AdapterView.OnItemClickListener - The listener for icon item clicks.
    public AdapterView.OnItemClickListener getIconClickListener(
            GridView iconGrid, // GridView displaying icons
            IconAdapter adapter // Adapter for the icon GridView
    ) {
        // Step 1: Log that the icon click listener is being created
        Log.d(TAG, "Icon Click Listener created.");
        // Step 2: Return a new OnItemClickListener implementation
        return (parent, view, position, id) -> {
            // Step 2.1: Log the position of the clicked item and the current expanded state
            Log.d(TAG, "Icon item clicked at position: " + position + ", isExpanded: " + isExpanded);

            // Step 2.2: Check if the full icon list is available and not empty
            if (this.fullIconList == null || this.fullIconList.isEmpty()) {
                // Step 2.2.1: Log an error and show a toast if the list is unavailable
                Log.e(TAG, "Full icon list not available in click listener!");
                Toast.makeText(context, "Icon list not available", Toast.LENGTH_SHORT).show();
                return; // Exit the listener
            }

            // Step 2.4: Check if the grid is currently collapsed
            if (!isExpanded) {
                // Step 2.4.1: If collapsed, the user wants to expand it
                Log.d(TAG, "Expanding grid.");
                // Step 2.4.2: Update the adapter with the full list of icons
                adapter.updateData(new ArrayList<>(this.fullIconList)); // Pass a copy
                // Step 2.4.3: Set the number of columns for the grid to 3 for expansion
                iconGrid.setNumColumns(3);
                // Step 2.4.4: Update the expanded state flag
                isExpanded = true;
            } else {
                // Step 2.5: If the grid is currently expanded, the user clicked to select an icon and collapse
                Log.d(TAG, "Collapsing grid. Position clicked: " + position);

                // Step 2.5.1: Validate the clicked position against the full list size
                if (position < 0 || position >= fullIconList.size()) {
                    // Step 2.5.1.1: Log an error and show a toast for an invalid position
                    Toast.makeText(context, "Invalid icon selected", Toast.LENGTH_SHORT).show();
                    return; // Exit the listener
                }

                // Step 2.5.2: Get the resource ID of the clicked icon from the full list
                int clickedIconId = fullIconList.get(position);
                // Step 2.5.3: Log the retrieved icon ID (for debugging)
                Log.d("IconSelectDebug", TAG + ": Clicked icon ID from fullIconList.get(" + position + "): " + clickedIconId);

                // Step 2.5.4: Set the clicked icon as the selected icon using the helper method
                setIcon(clickedIconId);

                // Step 2.5.6: Create a new list containing only the selected icon
                ArrayList<Integer> single = new ArrayList<>();
                single.add(this.selectedIconResId);
                // Step 2.5.7: Update the adapter with the list containing only the selected icon (to show just the selected one)
                adapter.updateData(single);
                // Step 2.5.8: Set the number of columns for the grid back to 1 for collapsing
                iconGrid.setNumColumns(1);
                // Step 2.5.9: Update the expanded state flag
                isExpanded = false;

                // Step 2.5.10: Show a success message to the user
                Toast.makeText(context, "Icon Selected", Toast.LENGTH_SHORT).show();
            }
        };
    }

    // Function: setIcon
    // Description: Sets the internally stored selected icon resource ID.
    // Input: int icon - The resource ID of the selected icon.
    // Output: void (Updates the internal state).
    private void setIcon(int icon) {
        // Step 1: Assign the provided icon resource ID to the selectedIconResId variable
        this.selectedIconResId = icon;
    }

    // Function: getSelectedIconResId
    // Description: Returns the resource ID of the currently selected icon.
    // Input: none
    // Output: int - The resource ID of the selected icon, or -1 if none is selected.
    public int getSelectedIconResId() {
        // Step 1: Log that the method is called and the value being returned (for debugging)
        Log.d("IconSelectDebug", TAG + ": getSelectedIconResId() called. Returning: " + selectedIconResId);
        // Step 2: Return the value of selectedIconResId
        return this.selectedIconResId;
    }

    // Function: getCourseClickListener
    // Description: Creates and returns an OnItemClickListener specifically for a GridView
    // displaying courses, allowing selection/deselection of courses.
    // Input: final ArrayList<CourseClass> selectedCourses - The list where selected courses are managed.
    // Output: AdapterView.OnItemClickListener - The listener for course item clicks.
    public AdapterView.OnItemClickListener getCourseClickListener(final ArrayList<CourseClass> selectedCourses) {
        // Step 1: Log that the course click listener is being created
        Log.d(TAG, "Course Click Listener created.");
        // Step 2: Return a new OnItemClickListener implementation
        return (parent, view, position, id) -> {
            // Step 2.1: Log the position of the clicked course item
            Log.d(TAG, "Course item clicked at position: " + position);
            // Step 2.2: Get the CourseClass object for the item at the clicked position
            CourseClass course = (CourseClass) parent.getItemAtPosition(position);
            // Step 2.3: Check if the clicked course is already in the selectedCourses list
            if (selectedCourses.contains(course)) {
                // Step 2.3.1: If it is, remove it from the selectedCourses list
                selectedCourses.remove(course);
                // Step 2.3.2: Remove the background color visual feedback (set to transparent/default)
                view.setBackgroundColor(0); // Setting color to 0 removes background color
                // Step 2.3.3: Log that the course was removed
                Log.d(TAG, "Course removed: " + course.getCourseName());
            } else {
                // Step 2.4: If the clicked course is not in the selectedCourses list, add it
                selectedCourses.add(course);
                // Step 2.4.1: Set a background color to provide visual feedback that the course is selected
                view.setBackgroundColor(0xFFFFDDDD); // Example light red background color
                // Step 2.4.2: Log that the course was added
                Log.d(TAG, "Course added: " + course.getCourseName());
            }
        };
    }
}
