package com.example.myfinalproject.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.example.myfinalproject.R; // Ensure R.raw.song1 and R.drawable.ic_music_note exist

public class MusicPlayer extends Service implements MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener {

    private static final String TAG = "MusicPlayerService";
    // Actions for controlling the player via Intents
    public static final String ACTION_PLAY = "com.example.myfinalproject.ACTION_PLAY";
    public static final String ACTION_STOP = "com.example.myfinalproject.ACTION_STOP";
    public static final String ACTION_SET_VOLUME = "com.example.myfinalproject.ACTION_SET_VOLUME";
    public static final String EXTRA_VOLUME = "extra_volume"; // Key for passing volume level

    private static final int NOTIFICATION_ID = 1; // Unique ID for the notification
    private static final String CHANNEL_ID = "music_player_channel"; // Notification channel ID
    private static final String CHANNEL_NAME = "Music Playback"; // Notification channel name

    private MediaPlayer mediaPlayer;
    private float currentVolume = 0.5f; // Default volume (0.0f to 1.0f)
    private boolean isMusicPlaying = false; // Tracks if music is actively playing

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Service onCreate");
        // It's generally better to initialize MediaPlayer when ACTION_PLAY is received,
        // to ensure a valid audio resource is specified at that time.
        // However, creating the notification channel here is appropriate.
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "Service onStartCommand with action: " + (intent != null ? intent.getAction() : "null intent"));

        // When the service starts, it MUST call startForeground immediately for Android 8+
        // if it's going to be a foreground service.
        Notification notification = buildNotification("Tap to open app", false); // Initial notification
        startForeground(NOTIFICATION_ID, notification);

        if (intent == null || intent.getAction() == null) {
            Log.w(TAG, "Intent or action is null. Service might be restarted by system.");
            // If restarted, you might want to restore previous state or stop.
            // For now, we'll just ensure the service stays in foreground or stops if no music.
            if (!isMusicPlaying) {
                Log.d(TAG, "No active playback, stopping service after restart.");
                stopSelfSafely();
            }
            return START_STICKY; // Or START_NOT_STICKY if you don't want it to restart without an explicit command.
        }

        String action = intent.getAction();
        switch (action) {
            case ACTION_PLAY:
                // Get volume from intent, or use current if not provided
                currentVolume = intent.getFloatExtra(EXTRA_VOLUME, currentVolume);
                Log.d(TAG, "ACTION_PLAY received. Volume: " + currentVolume);

                if (mediaPlayer == null) {
                    // Use a placeholder audio file. Replace R.raw.song1 with your actual audio file.
                    // Ensure 'song1.mp3' (or .wav, .ogg) is in your 'res/raw/' directory.
                    mediaPlayer = MediaPlayer.create(this, R.raw.song1);
                    if (mediaPlayer == null) {
                        Log.e(TAG, "Failed to create MediaPlayer. Ensure R.raw.song1 exists and is valid.");
                        Toast.makeText(this, "Error: Could not load music file.", Toast.LENGTH_LONG).show();
                        stopSelfSafely(); // Stop service if MediaPlayer can't be created
                        return START_NOT_STICKY;
                    }
                    mediaPlayer.setOnCompletionListener(this);
                    mediaPlayer.setOnErrorListener(this); // Set error listener
                    mediaPlayer.setLooping(true); // Example: Loop music
                    Log.d(TAG, "MediaPlayer created.");
                }

                if (!mediaPlayer.isPlaying()) {
                    try {
                        mediaPlayer.setVolume(currentVolume, currentVolume);
                        mediaPlayer.start();
                        isMusicPlaying = true;
                        Log.d(TAG, "Music started playing.");
                        updateNotification("Playing: Song Title", true); // Update notification
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "Error starting MediaPlayer: " + e.getMessage());
                        isMusicPlaying = false;
                        stopSelfSafely();
                    }
                } else {
                    // If already playing, perhaps just update volume
                    mediaPlayer.setVolume(currentVolume, currentVolume);
                    Log.d(TAG, "Music already playing, volume updated.");
                }
                break;

            case ACTION_STOP:
                Log.d(TAG, "ACTION_STOP received.");
                stopMusicAndService();
                break;

            case ACTION_SET_VOLUME:
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    currentVolume = intent.getFloatExtra(EXTRA_VOLUME, currentVolume);
                    mediaPlayer.setVolume(currentVolume, currentVolume);
                    Log.d(TAG, "Volume set to: " + currentVolume);
                } else if (mediaPlayer == null || !mediaPlayer.isPlaying()){
                    // If music is not playing, still update the currentVolume for next play
                    currentVolume = intent.getFloatExtra(EXTRA_VOLUME, currentVolume);
                    Log.d(TAG, "Volume updated to: " + currentVolume + " (music not playing)");
                }
                break;

            default:
                Log.w(TAG, "Unknown action received: " + action);
                break;
        }
        // START_STICKY: if the service is killed, it will be recreated and onStartCommand will be called with a null intent.
        // START_NOT_STICKY: if the service is killed, it will not be recreated unless an explicit start command is sent.
        // START_REDELIVER_INTENT: similar to START_STICKY, but the last intent is redelivered.
        return START_STICKY;
    }

    private void stopMusicAndService() {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
                Log.d(TAG, "MediaPlayer stopped.");
            }
            mediaPlayer.release(); // Release resources
            mediaPlayer = null;
            Log.d(TAG, "MediaPlayer released.");
        }
        isMusicPlaying = false;
        stopSelfSafely(); // Stops foreground and then the service
    }

    private void stopSelfSafely() {
        Log.d(TAG, "Stopping foreground service and self.");
        stopForeground(true); // True to remove the notification
        stopSelf(); // Stop the service
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Service onDestroy");
        // Ensure resources are released if service is destroyed unexpectedly
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            mediaPlayer.release();
            mediaPlayer = null;
        }
        isMusicPlaying = false;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        // This service does not support binding, so return null.
        return null;
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        Log.d(TAG, "Music playback completed.");
        isMusicPlaying = false;
        // If not looping, you would stop the service here.
        // Since setLooping(true) is used, this will only be called if looping is turned off
        // or an error occurs that stops playback but doesn't trigger onError.
        if (!mediaPlayer.isLooping()) {
            updateNotification("Playback finished", false);
            stopSelfSafely();
        }
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        Log.e(TAG, "MediaPlayer error - What: " + what + ", Extra: " + extra);
        isMusicPlaying = false;
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
        updateNotification("Error playing music", false);
        stopSelfSafely(); // Stop the service on error
        // Return true to indicate that the error has been handled
        return true;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_LOW // Use LOW to avoid sound/vibration for ongoing task
            );
            serviceChannel.setDescription("Channel for background music player");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(serviceChannel);
                Log.d(TAG, "Notification channel created.");
            } else {
                Log.e(TAG, "NotificationManager is null, cannot create channel.");
            }
        }
    }

    private Notification buildNotification(String contentText, boolean isPlaying) {
        // Intent to launch your app's main activity when notification is tapped
        // Replace YourMainActivity.class with your actual main activity
        // Intent notificationIntent = new Intent(this, YourMainActivity.class);
        // PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);

        // For simplicity, this notification won't launch an activity.
        // You should configure a PendingIntent to open your app or music controls.

        // Ensure you have 'ic_music_note.png' or similar in 'res/drawable-*' folders.
        // Or use a default system icon if needed, e.g., android.R.drawable.ic_media_play
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Background Music")
                .setContentText(contentText)
                .setSmallIcon(R.drawable.ic_launcher_foreground) // IMPORTANT: Replace with your actual notification icon
                // .setContentIntent(pendingIntent) // Uncomment to make notification clickable
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(isPlaying) // Makes the notification non-dismissible if playing
                .setSilent(true) // No sound for this notification updates
                .build();
    }

    private void updateNotification(String contentText, boolean isPlaying) {
        Notification notification = buildNotification(contentText, isPlaying);
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.notify(NOTIFICATION_ID, notification);
            Log.d(TAG, "Notification updated: " + contentText);
        } else {
            Log.e(TAG, "NotificationManager is null, cannot update notification.");
        }
    }
}
