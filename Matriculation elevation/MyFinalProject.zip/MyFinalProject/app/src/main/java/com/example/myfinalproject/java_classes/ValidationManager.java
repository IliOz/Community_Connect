package com.example.myfinalproject.java_classes;

import android.text.TextUtils;
import android.util.Patterns;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseUser;

public class ValidationManager {

    public static boolean validateUserInfo(UserInfoClass userInfoClass, EditText usernameInput,
                                           EditText passwordInput, EditText emailInput) {
        boolean isValid = true;

        isValid &= isUserNameValid(userInfoClass.getUsername(), usernameInput);
        isValid &= isPasswordValid(userInfoClass.getPassword(), passwordInput);
        isValid &= isEmailValid(userInfoClass.getEmail(), emailInput);

        return isValid;
    }

    public static boolean validateUserInfo(EditText emailInput, EditText passwordInput) {
        boolean isValid = true;

        isValid &= isEmailValid(emailInput.getText().toString(), emailInput); // Validate email from EditText
        isValid &= isPasswordValid(passwordInput.getText().toString(), passwordInput);

        return isValid;
    }

    private static boolean isEmailValid(String email, EditText emailInput) {
        if (TextUtils.isEmpty(email)) {
            if (emailInput!= null) emailInput.setError("Email is required");
            return false;
        }

        String trimmedEmail = email.trim().toLowerCase(); // Remove whitespace and convert to lowercase

        if (!Patterns.EMAIL_ADDRESS.matcher(trimmedEmail).matches()) {
            if (emailInput!= null) emailInput.setError("Invalid email format");
            return false;
        }

        if (!trimmedEmail.endsWith("@gmail.com")) {
            if (emailInput!= null) emailInput.setError("Email must be a Gmail address");
            return false;
        }

        return true;
    }

    public static boolean isUserNameValid(String username, EditText usernameInput) {
        if (TextUtils.isEmpty(username)) {
            if (usernameInput!= null) usernameInput.setError("Username is required");
            return false;
        }

        if (username.length() < 3) {
            if (usernameInput!= null) usernameInput.setError("Username must be at least 3 characters long");
            return false;
        }

        return true;
    }

    private static boolean isPasswordValid(String password, EditText passwordInput) {
        if (TextUtils.isEmpty(password)) {
            if (passwordInput!= null) passwordInput.setError("Password is required");
            return false;
        }

        if (password.length() < 8) {
            if (passwordInput!= null) passwordInput.setError("Password must be at least 8 characters long");
            return false;
        }

        final String ALLOWED_PASSWORD_CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$&()_+\\-{}:;',?/*`~\\^=<>.\\[\\]]";

        if (password.matches("^[" + ALLOWED_PASSWORD_CHARS + "]+$")) {
            if (passwordInput!= null) passwordInput.setError("Password contains invalid characters");
            return false;
        }

        return true;
    }

    private static FirebaseAuth mAuth;

    public static void authenticateUserInfo(String email, String password, AuthenticationCallback authenticationCallback) {
        mAuth = FirebaseAuth.getInstance();

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        authenticationCallback.onAuthenticationSuccess(user);
                    } else {
                        try {
                            throw task.getException();
                        } catch (FirebaseAuthInvalidUserException | FirebaseAuthInvalidCredentialsException e) {
                            authenticationCallback.onAuthenticationFailure(e.getMessage());
                        } catch (Exception e) {
                            authenticationCallback.onAuthenticationFailure("Authentication failed: " + e.getMessage());
                        }
                    }
                });
    }

    public interface AuthenticationCallback {
        void onAuthenticationSuccess(FirebaseUser user);

        void onAuthenticationFailure(String errorMessage);
    }
}