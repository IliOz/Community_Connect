package com.example.myfinalproject.java_classes;

import java.io.Serializable; // Import Serializable
import java.util.ArrayList; // Import ArrayList

// Class: CourseClass
// Description: Represents a single course, containing its name, description, icon,
// points associated with it, and a list of subtopics within the course. It is Serializable
// to allow passing between components (like Activities or Fragments) via Intents.
// Input: Data representing the various attributes of a course and its subtopics.
// Output: Provides access to the course's attributes and calculates overall progress.
public class CourseClass implements Serializable {
    // --- Basic Attributes ---
    private String courseName; // The name of the course
    private String courseDescription; // A brief description of the course
    private int points; // Points associated with completing this course or its subtopics

    // --- Subtopics ---
    private ArrayList<SubTopicClass> subtopics; // List of subtopics belonging to this course

    // Function: Constructor (No-argument)
    // Description: Default constructor required for Firebase Firestore object mapping.
    // Input: none
    // Output: Initializes an empty CourseClass object.
    public CourseClass(){
        // Default constructor
    }

    // Function: Constructor (Parameterized)
    // Description: Initializes a new CourseClass object with all its attributes.
    // Input:
    // String courseName - The name of the course.
    // String courseDescription - A brief description of the course.
    // int courseIconId - Resource ID for the course's icon.
    // int points - Points associated with the course.
    // ArrayList<SubTopicClass> subtopics - List of subtopics within the course.
    // Output: Initializes the object.
    public CourseClass(String courseName, String courseDescription,
                       int points, ArrayList<SubTopicClass> subtopics) {
        // Step 1: Assign the provided course name
        this.courseName = courseName;
        // Step 2: Assign the provided course description
        this.courseDescription = courseDescription;
        // Step 4: Assign the provided points
        this.points = points;
        // Step 5: Assign the provided list of subtopics
        this.subtopics = subtopics;
    }

    // --- Getters and Setters ---

    // Function: getCourseName
    // Description: Returns the name of the course.
    // Input: none
    // Output: String - The course name.
    public String getCourseName() {
        return courseName;
    }

    // Function: setCourseName
    // Description: Sets the name of the course.
    // Input: String courseName - The new name for the course.
    // Output: void (Updates the name).
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    // Function: getCourseDescription
    // Description: Returns the description of the course.
    // Input: none
    // Output: String - The course description.
    public String getCourseDescription() {
        return courseDescription;
    }

    // Function: getPoints
    // Description: Returns the points associated with the course.
    // Input: none
    // Output: int - The points value.
    public int getPoints() {
        return points;
    }


    // Function: getSubtopics
    // Description: Returns the list of subtopics within the course.
    // Input: none
    // Output: ArrayList<SubTopicClass> - The list of subtopics.
    public ArrayList<SubTopicClass> getSubtopics() {
        return subtopics;
    }

    // Function: setSubtopics
    // Description: Sets the list of subtopics for the course.
    // Input: ArrayList<SubTopicClass> subtopics - The new list of subtopics.
    // Output: void (Updates the subtopics list).
    public void setSubtopics(ArrayList<SubTopicClass> subtopics) {
        this.subtopics = subtopics;
    }

    // Function: getProgress
    // Description: Calculates the overall progress of the course based on the average progress of its subtopics.
    // Input: none
    // Output: int - The average progress percentage of the subtopics (0-100). Returns 0 if there are no subtopics.
    public int getProgress() {
        // Step 1: Check if the subtopics list is null or empty
        if (subtopics == null || subtopics.isEmpty()) {
            // Step 1.1: If no subtopics, return 0 progress
            return 0; // No subtopics, progress is 0
        }
        // Step 2: Initialize a variable to accumulate the total progress from all subtopics
        int totalProgress = 0;
        // Step 3: Iterate through each subtopic in the list
        for (SubTopicClass subtopic : subtopics) {
            // Step 3.1: Add the progress of the current subtopic to the total progress
            totalProgress += subtopic.getProgress();
        }
        // Step 4: Calculate the average progress by dividing the total progress by the number of subtopics
        // This assumes each subtopic's progress is out of 100, so the average represents the overall course percentage.
        return totalProgress / subtopics.size(); // Average progress
    }
}