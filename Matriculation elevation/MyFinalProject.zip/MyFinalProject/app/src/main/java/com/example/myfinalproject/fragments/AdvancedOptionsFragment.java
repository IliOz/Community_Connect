package com.example.myfinalproject.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent; // Import Intent
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat; // Import ContextCompat
import androidx.fragment.app.Fragment;

import com.example.myfinalproject.R;
import com.example.myfinalproject.services.MusicPlayer; // Import MusicPlayer
// import com.example.myfinalproject.java_classes.UserInfoClass; // Not used in this snippet
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
// import com.google.firebase.firestore.FirebaseFirestore; // Not used in this snippet

import java.util.Random;

public class AdvancedOptionsFragment extends Fragment {
    private Button resetButton, randomizeButton, panicButton;
    private FirebaseDatabase database;
    private DatabaseReference userRef;
    private String userId;
    private FirebaseAuth auth;
    private FirebaseUser user;

    // Use consistent SharedPreferences name and keys as in AudioSettingsFragment
    private static final String PREF_NAME = "audio_settings_prefs"; // Consistent name
    private static final String KEY_MUSIC_ON = "music_on_status";   // Consistent key
    private static final String KEY_VOLUME = "music_volume_level";  // Consistent key

    private static final String TAG = "AdvancedOptionsFragment";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.item_advanced_options, container, false);
        initViews(view);
        initFirebase();
        initListeners();
        return view;
    }

    private void initViews(View view) {
        resetButton = view.findViewById(R.id.button_reset_default);
        randomizeButton = view.findViewById(R.id.button_randomize_settings);
        panicButton = view.findViewById(R.id.button_panic_mode);
    }

    private void initFirebase() {
        database = FirebaseDatabase.getInstance();
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();

        if (user != null) {
            userId = user.getUid();
            userRef = database.getReference("users").child(userId);
            Log.d(TAG, "Firebase user initialized with UID: " + userId);
        } else {
            Log.w(TAG, "Firebase user is null. Disabling advanced options buttons.");
            Toast.makeText(getContext(), "Please log in to use advanced options.", Toast.LENGTH_LONG).show();
            if (resetButton != null) resetButton.setEnabled(false);
            if (randomizeButton != null) randomizeButton.setEnabled(false);
            if (panicButton != null) panicButton.setEnabled(false);
        }
    }

    private void initListeners() {
        resetButton.setOnClickListener(view -> {
            if (user != null) {
                resetDefaultSettings();
            } else {
                Toast.makeText(getContext(), "Please log in to reset settings.", Toast.LENGTH_SHORT).show();
            }
        });

        randomizeButton.setOnClickListener(view -> {
            if (user != null) {
                randomizeSettings();
            } else {
                Toast.makeText(getContext(), "Please log in to randomize settings.", Toast.LENGTH_SHORT).show();
            }
        });

        panicButton.setOnClickListener(view -> {
            if (user != null) {
                setPanicMode();
            } else {
                Toast.makeText(getContext(), "Please log in to activate panic mode.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void resetDefaultSettings() {
        Toast.makeText(getContext(), "Resetting to default audio settings...", Toast.LENGTH_SHORT).show();

        SharedPreferences sharedPreferences = requireContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // Default settings
        boolean defaultMusicOn = false; // Default: music off
        int defaultVolume = 50;      // Default: volume 50

        editor.putBoolean(KEY_MUSIC_ON, defaultMusicOn);
        editor.putInt(KEY_VOLUME, defaultVolume);
        editor.apply(); // IMPORTANT: Save the changes!

        Log.d(TAG, "Default settings applied: Music On=" + defaultMusicOn + ", Volume=" + defaultVolume);

        // Notify MusicPlayerService
        updateMusicService(defaultMusicOn, defaultVolume);
    }

    private void randomizeSettings() {
        Toast.makeText(getContext(), "Randomizing audio settings...", Toast.LENGTH_SHORT).show();
        Random random = new Random();
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        boolean randomMusicOn = random.nextBoolean();
        int randomVolume = random.nextInt(101); // 0-100

        editor.putBoolean(KEY_MUSIC_ON, randomMusicOn);
        editor.putInt(KEY_VOLUME, randomVolume);
        editor.apply(); // IMPORTANT: Save the changes!

        Log.d(TAG, "Random settings applied: Music On=" + randomMusicOn + ", Volume=" + randomVolume);

        // Notify MusicPlayerService
        updateMusicService(randomMusicOn, randomVolume);
    }

    /**
     * Sends an intent to MusicPlayerService to update its state based on new settings.
     * @param playMusic Whether music should be playing.
     * @param volumeLevel The volume level (0-100).
     */
    private void updateMusicService(boolean playMusic, int volumeLevel) {
        if (getContext() == null) return;

        Intent musicServiceIntent = new Intent(requireContext(), MusicPlayer.class);
        if (playMusic) {
            musicServiceIntent.setAction(MusicPlayer.ACTION_PLAY);
            float floatVolume = volumeLevel / 100f; // Convert to 0.0 - 1.0
            musicServiceIntent.putExtra(MusicPlayer.EXTRA_VOLUME, floatVolume);
            Log.d(TAG, "Sending ACTION_PLAY to service. Volume: " + floatVolume);
        } else {
            musicServiceIntent.setAction(MusicPlayer.ACTION_STOP);
            Log.d(TAG, "Sending ACTION_STOP to service.");
        }
        ContextCompat.startForegroundService(requireContext(), musicServiceIntent);
    }


    private void setPanicMode() {
        // ... (your existing panic mode code - looks fun!)
        // Note: Panic mode does not change SharedPreferences for music in your current code.
        // If it should (e.g., turn music off), you'd add that logic here and call updateMusicService().
        final Context context = getContext();
        if (context == null) return; // Avoid issues if fragment is detached
        final View rootView = ((Activity) context).getWindow().getDecorView().getRootView();

        // Blood-red overlay
        rootView.setBackgroundColor(Color.parseColor("#8B0000")); // Dark Red

        // Big text overlay for drama
        TextView warningText = new TextView(context);
        warningText.setText("SELF-DESTRUCT SEQUENCE INITIATED");
        warningText.setTextColor(Color.WHITE);
        warningText.setTextSize(24);
        warningText.setGravity(Gravity.CENTER);
        warningText.setTypeface(Typeface.DEFAULT_BOLD);
        warningText.setBackgroundColor(Color.TRANSPARENT);

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        );
        warningText.setLayoutParams(params);

        if (rootView instanceof FrameLayout) {
            FrameLayout rootLayout = (FrameLayout) rootView;
            rootLayout.addView(warningText);

            // Countdown + drama
            new CountDownTimer(5000, 1000) {
                int secondsLeft = 5;

                public void onTick(long millisUntilFinished) {
                    warningText.setText("SELF-DESTRUCT IN: " + secondsLeft--);
                }

                public void onFinish() {
                    warningText.setText("DELETING USER PROFILE…");

                    new Handler().postDelayed(() -> {
                        warningText.setText("WIPING MEMORY BANKS…");

                        new Handler().postDelayed(() -> {
                            warningText.setText("JUST KIDDING. CALM DOWN.");
                            rootView.setBackgroundColor(Color.BLACK); // Or original color
                            warningText.setTextColor(Color.GREEN);

                            new Handler().postDelayed(() -> {
                                // Clean up panic overlay
                                rootLayout.removeView(warningText);
                                // Restore original background color, e.g., white or from theme
                                // For simplicity, setting to white. You might want to store original color.
                                rootView.setBackgroundColor(Color.WHITE);
                                Toast.makeText(context, "Crisis averted. You okay?", Toast.LENGTH_LONG).show();
                            }, 3000);
                        }, 2000);
                    }, 2000);
                }
            }.start();
        } else {
            Log.e(TAG, "Root view is not a FrameLayout. Cannot add warning text for panic mode.");
            // Fallback or different panic effect if root is not FrameLayout
            Toast.makeText(context, "PANIC! (But couldn't show full effect)", Toast.LENGTH_LONG).show();
        }
    }
}