package com.example.myfinalproject.gamesActivities.ComputerScience;

import android.content.Intent; // Import Intent
import android.content.SharedPreferences; // Import SharedPreferences
import android.os.Bundle; // Import Bundle
import android.util.Log; // Import Log
import android.view.LayoutInflater; // Import LayoutInflater
import android.view.Menu; // Import Menu
import android.view.MenuInflater; // Import MenuInflater
import android.view.MenuItem; // Import MenuItem
import android.view.View; // Import View
import android.view.ViewGroup; // Import ViewGroup
import android.widget.Button; // Import Button
import android.widget.Toast; // Import Toast

import androidx.annotation.NonNull; // Import annotations
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity; // Import AppCompatActivity
import androidx.appcompat.widget.Toolbar; // Import Toolbar
import androidx.fragment.app.Fragment; // Import Fragment
import androidx.fragment.app.FragmentManager; // Import FragmentManager

import com.example.myfinalproject.R; // Import R
import com.example.myfinalproject.activities.LogInActivity; // Import activities
import com.example.myfinalproject.activities.MainActivity;
import com.example.myfinalproject.activities.ProfileActivity;
import com.example.myfinalproject.activities.SettingsActivity;
import com.example.myfinalproject.adapters.SubtopicAdapter; // Import SubtopicAdapter
import com.example.myfinalproject.java_classes.Constants; // Import Constants
import com.example.myfinalproject.java_classes.CourseClass; // Import data classes
import com.example.myfinalproject.java_classes.SubTopicClass;
import com.example.myfinalproject.java_classes.UserInfoClass;
import com.google.android.gms.tasks.OnFailureListener; // Import Firebase task listeners
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task; // Import Task
import com.google.firebase.auth.FirebaseAuth; // Import Firebase Auth
import com.google.firebase.auth.FirebaseUser; // Import FirebaseUser
import com.google.firebase.firestore.DocumentReference; // Import Firestore classes
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList; // Import ArrayList

// Class: CSIntroductionFragment
// Description: A Fragment displaying an introduction to Computer Science. It typically
// serves as a landing page for the CS course and provides a button to move to the next lesson.
// Clicking the button updates the user's progress for this subtopic in Firestore and navigates.
// Input: none (as it's a Fragment, interacts via UI and Firebase)
// Output: Displays introductory content, handles button click, updates Firestore, navigates.
public class CSIntroductionFragment extends Fragment {

    // UI Variables
    private Button startButton; // Button to proceed from the introduction

    // Firebase Variables
    private FirebaseAuth mAuth; // Firebase Authentication instance
    private FirebaseFirestore db; // Firestore database instance
    // User ID (might be redundant with mAuth.getCurrentUser().getUid() but used)
    private String userId; // User ID of the currently logged-in user

    // Function: onCreateView
    // Description: Called to create the view hierarchy for the fragment.
    // Inflates the layout, initializes views, listeners, Firebase, gets user ID,
    // and sets up the toolbar menu.
    // Input: LayoutInflater inflater - The LayoutInflater object that can be used to inflate any views in the fragment.
    // Input: ViewGroup container - If non-null, this is the parent view that the fragment's UI should be attached to.
    // Input: Bundle savedInstanceState - If non-null, this fragment is being re-constructed from a previous saved state.
    // Output: View - The root View of the fragment's layout.
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Step 1: Inflate the layout for this fragment from cs_intoduction.xml
        View view = inflater.inflate(R.layout.cs_intoduction, container, false);

        // Step 2: Initialize UI views found in the inflated layout
        initViews(view);
        // Step 3: Initialize event listeners for the UI elements
        initListeners();

        // Step 4: Initialize Firebase Authentication and Firestore instances
        mAuth = FirebaseAuth.getInstance(); // Get Auth instance
        db = FirebaseFirestore.getInstance(); // Get Firestore instance

        // Step 5: Get the current user's UID if they are logged in
        if (mAuth.getCurrentUser() != null) {
            userId = mAuth.getCurrentUser().getUid();
        }
        // Note: A check or handling for null user might be needed here if not guaranteed logged in.

        // Step 6: Indicate that this fragment has its own options menu
        setHasOptionsMenu(true); // Ensure menu options show up

        // Step 7: Get the main activity's Toolbar and set it as the action bar for the fragment
        Toolbar toolbar = requireActivity().findViewById(R.id.toolbarMain); // Find toolbar in the hosting activity
        ((AppCompatActivity) requireActivity()).setSupportActionBar(toolbar); // Set it as the action bar

        // Step 8: Return the root view of the fragment
        return view;
    }

    // Function: initViews
    // Description: Initializes UI elements by finding them in the layout.
    // Input: View view - The root view of the fragment's layout.
    // Output: void (Initializes UI views).
    private void initViews(View view) {
        // Step 1: Find and assign the start button
        startButton = view.findViewById(R.id.startButton);
    }

    // Function: initListeners
    // Description: Sets up click listeners for the Start button.
    // Input: none
    // Output: void (Sets up listeners).
    private void initListeners() {
        // Step 1: Set a click listener for the startButton
        startButton.setOnClickListener(new View.OnClickListener() {
            // Function: onClick
            // Description: Called when the Start button is clicked. Triggers updating subtopic progress and navigation.
            // Input: View view - The clicked view (the button).
            // Output: void (Calls updateSubtopicProgress helper method).
            @Override
            public void onClick(View view) {
                // Step 1.1: Call the helper method to update subtopic progress and navigate
                updateSubtopicProgress();
            }
        });
    }

    // Function: updateSubtopicProgress
    // Description: Updates the progress for the 'Introduction' CS subtopic in Firestore to 100%.
    // It retrieves the current user's courses, finds the specific subtopic, sets its progress,
    // saves the modified course list back to Firestore, and navigates to the next fragment ('Variables') on success.
    // Includes checks to ensure the fragment is attached to avoid issues with async operations.
    // Input: none
    // Output: void (Fetches user data, updates Firestore, navigates, shows feedback).
    private void updateSubtopicProgress() {
        // Step 1: Reset the global currently selected subtopic (optional, depends on app flow)
        SubtopicAdapter.currentlySelectedSubtopic = null;

        // Step 2: Get the currently logged-in Firebase user
        FirebaseUser currentUser = mAuth.getCurrentUser();
        // Step 3: Check if the user is logged in
        if (currentUser == null) {
            // Step 3.1: If not logged in, check if the fragment is attached before showing a toast
            if (isAdded()) {
                Toast.makeText(getContext(), "User not signed in", Toast.LENGTH_SHORT).show();
            }
            return; // Exit the method
        }

        // Step 4: Get the current user's UID
        String userId = currentUser.getUid();
        // Step 5: Get a document reference to the user's data in Firestore
        DocumentReference userRef = db.collection("users").document(userId);

        // Step 6: Retrieve current user data from Firestore asynchronously
        userRef.get().addOnCompleteListener(task -> {
            // Function: onComplete (OnCompleteListener for Firestore get)
            // Description: Called when the task to get user data completes.
            // Input: Task<DocumentSnapshot> task - The completed task.
            // Output: void (Processes user data, updates subtopic, saves to Firestore, navigates).
            // Step 6.1: Check if the fragment is still attached before processing the result
            if (!isAdded()) return; // Ensure fragment is attached

            // Step 6.2: Check if the task was successful
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                // Step 6.3: Check if the document exists and is not null
                if (document != null && document.exists()) {
                    // Step 6.4: Convert the document to a UserInfoClass object
                    UserInfoClass userInfo = document.toObject(UserInfoClass.class);
                    // Step 6.5: Check if UserInfo object and its classes list are valid
                    if (userInfo != null && userInfo.getClasses() != null) {
                        // Step 6.6: Get the list of existing courses
                        ArrayList<CourseClass> courses = userInfo.getClasses(); // Existing courses list
                        boolean updated = false; // Flag to track if progress was updated

                        // Step 6.7: Iterate through courses and subtopics to find the target subtopic
                        for (CourseClass course : courses) {
                            if (course.getSubtopics() != null) {
                                for (SubTopicClass subTopic : course.getSubtopics()) {
                                    // Step 6.7.1: Check if the current subtopic matches the target subtopic ('Introduction')
                                    if (subTopic.getName().equals(Constants.KEY_CS_INTRODUCTION)) {
                                        // Step 6.7.2: Update the progress for this specific subtopic to 100%
                                        subTopic.setProgress(100); // Mark as completed
                                        updated = true; // Set the flag to true
                                        break; // Exit the inner subtopic loop once found
                                    }
                                }
                            }
                            // Step 6.7.3: If the subtopic was updated, exit the outer course loop as well
                            if (updated)
                                break;
                        }

                        // Step 6.8: Update the 'classes' field in the user's Firestore document with the modified courses list
                        userRef.update("classes", courses)
                                .addOnSuccessListener(aVoid -> {
                                    // Function: onSuccess (OnSuccessListener for Firestore update)
                                    // Description: Called when the Firestore update succeeds.
                                    // Input: Void aVoid - Placeholder.
                                    // Output: void (Shows success toast and navigates to the next fragment).
                                    // Step 6.8.1.1: Check if the fragment is attached before updating UI
                                    if (!isAdded()) return; // Check again before updating UI
                                    // Step 6.8.1.2: Show a toast message indicating progress update success
                                    Toast.makeText(getContext(), "Subtopic progress updated!", Toast.LENGTH_SHORT).show();
                                    // Step 6.8.1.3: Navigate to the next fragment (CodeWithVariablesFragment) after successful update
                                    requireActivity().getSupportFragmentManager().beginTransaction()
                                            .replace(R.id.fragment_container_main, new CodeWithVariablesFragment()) // Replace current fragment
                                            .addToBackStack(null) // Add to back stack for navigation
                                            .commit(); // Commit the transaction
                                })
                                .addOnFailureListener(e -> {
                                    // Function: onFailure (OnFailureListener for Firestore update)
                                    // Description: Called when the Firestore update fails.
                                    // Input: Exception e - The exception detailing the failure.
                                    // Output: void (Shows error toast and logs error).
                                    // Step 6.8.2.1: Check if the fragment is attached before showing UI
                                    if (!isAdded()) return;
                                    // Step 6.8.2.2: Show a toast message with the error details
                                    Toast.makeText(getContext(), "Error updating Firestore: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                    // Step 6.8.2.3: Log the error
                                    Log.e("Firestore", "Error updating subtopic progress", e);
                                    // Note: Navigation might not happen on failure, keeping the user on the current fragment.
                                });
                    } else {
                        // Step 6.9: Check if the fragment is attached before showing UI
                        if (isAdded()) {
                            // Step 6.9.1: Show a toast if user data or course list is unexpectedly null
                            Toast.makeText(requireContext(), "User data or course list is null.", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    // Step 6.10: Check if the fragment is attached before showing UI
                    if (isAdded()) {
                        // Step 6.10.1: Show a toast if the user document is not found in Firestore
                        Toast.makeText(requireContext(), "User document not found.", Toast.LENGTH_SHORT).show();
                    }
                }
            } else {
                // Step 6.11: Check if the fragment is attached before showing UI
                if (isAdded()) {
                    // Step 6.11.1: Show a toast and log if fetching user data from Firestore failed
                    Toast.makeText(requireContext(), "Error getting user data: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    Log.e("Firestore", "Error getting user data", task.getException());
                }
            }
        });
    }

    // Function: onCreateOptionsMenu
    // Description: Initializes the options menu for the fragment's toolbar.
    // Input: Menu menu - The options menu.
    // Input: MenuInflater inflater - The inflater to inflate the menu layout.
    // Output: void (Inflates menu).
    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        // Step 1: Call the superclass method
        super.onCreateOptionsMenu(menu, inflater);
        // Step 2: Clear any existing menu items (important for fragments sharing a toolbar)
        menu.clear();
        // Step 3: Inflate the menu layout (R.menu.menu) into the provided Menu object
        inflater.inflate(R.menu.menu, menu); // Ensure menu is inflated
    }

    // Function: onOptionsItemSelected
    // Description: Called when an item in the options menu is selected. Handles navigation/actions based on the selected item.
    // Input: MenuItem item - The menu item that was selected.
    // Output: boolean - True if the event was consumed, false otherwise.
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Step 1: Get the ID of the selected menu item
        int id = item.getItemId();
        // Step 2: Check the ID and perform the corresponding action
        if (id == R.id.menu_log_out) {
            // Step 2.1: If Log Out is selected, call the logoutUser helper method
            logoutUser();
        } else if (id == R.id.menu_go_back) {
            // Step 2.2: If Go Back is selected, get the FragmentManager from the hosting activity
            FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();

            // Step 2.2.1: Check if there are fragments in the back stack managed by this FragmentManager
            if (fragmentManager.getBackStackEntryCount() > 0) {
                // Step 2.2.1.1: If yes, pop the back stack to go to the previous fragment
                fragmentManager.popBackStack(); // Go back to the previous fragment
            } else {
                // Step 2.2.1.2: If no fragments left in this manager's back stack, navigate back to MainActivity
                Intent intent = new Intent(requireActivity(), MainActivity.class);
                startActivity(intent);
                requireActivity().finish(); // Close current activity (hosting MainActivity)
            }
        } else if (id == R.id.menu_settings) {
            // Step 2.3: If Settings is selected, start the SettingsActivity
            startActivity(new Intent(requireActivity(), SettingsActivity.class));
        } else if (id == R.id.menu_profile) {
            // Step 2.4: If Profile is selected, start the ProfileActivity
            startActivity(new Intent(requireActivity(), ProfileActivity.class));
        } else if (id == R.id.menu_home) {
            // Step 2.5: If Home is selected, navigate back to MainActivity
            Intent intent = new Intent(requireActivity(), MainActivity.class);
            // Step 2.5.1: Clear the global currently selected subtopic (important when going home)
            SubtopicAdapter.currentlySelectedSubtopic = null;
            startActivity(intent);
            // Note: Finishing the activity here might be desired depending on navigation flow, but is not present in original.
        }
        // Step 3: Return true to indicate that the event was consumed
        return true;
    }

    // Function: logoutUser
    // Description: Logs out the currently authenticated user from Firebase, updates shared preferences,
    // clears the global selected subtopic, and navigates back to the LogInActivity.
    // Input: none
    // Output: void (Logs out user, updates state, navigates).
    private void logoutUser() {
        // Step 1: Get SharedPreferences for remembering user login status
        SharedPreferences sharedPreferences = requireActivity()
                .getSharedPreferences(Constants.KEY_REMEMBER_USER, requireActivity().MODE_PRIVATE);
        // Step 2: Get an editor for SharedPreferences
        SharedPreferences.Editor editor = sharedPreferences.edit();
        // Step 3: Set the "Remember User" flag to false
        editor.putBoolean(Constants.KEY_REMEMBER_USER, false);
        // Step 4: Apply the changes to SharedPreferences
        editor.apply();

        // Step 5: Clear the global currently selected subtopic
        SubtopicAdapter.currentlySelectedSubtopic = null;
        // Step 6: Sign out the user from Firebase Authentication
        mAuth.signOut();

        // Step 7: Create an Intent to navigate to the LogInActivity
        Intent intent = new Intent(requireActivity(), LogInActivity.class);
        // Step 8: Start the LogInActivity
        startActivity(intent);
        // Step 9: Finish the current hosting activity (which is MainActivity) to prevent going back
        requireActivity().finish();
    }
}