package com.example.myfinalproject.activities;

import android.content.DialogInterface; // Import DialogInterface
import android.content.Intent; // Import Intent
import android.content.SharedPreferences; // Import SharedPreferences
import android.os.Bundle; // Import Bundle
import android.text.TextUtils; // Import TextUtils for checking empty strings
import android.util.Log; // Import Log for logging
import android.view.Menu; // Import Menu for options menu
import android.view.MenuItem; // Import MenuItem for options menu items
import android.view.View; // Import View
import android.widget.Button; // Import Button
import android.widget.EditText; // Import EditText
import android.widget.ImageView; // Import ImageView
import android.widget.TextView; // Import TextView
import android.widget.Toast; // Import Toast

import androidx.annotation.NonNull; // Import annotations
import androidx.appcompat.app.AlertDialog; // Import AlertDialog
import androidx.appcompat.app.AppCompatActivity; // Import AppCompatActivity
import androidx.appcompat.widget.Toolbar; // Import Toolbar
import androidx.recyclerview.widget.LinearLayoutManager; // Import LinearLayoutManager for RecyclerView
import androidx.recyclerview.widget.RecyclerView; // Import RecyclerView

import com.example.myfinalproject.R; // Import R (resource file)
import com.example.myfinalproject.adapters.CourseProgressAdapter; // Import CourseProgressAdapter
import com.example.myfinalproject.java_classes.Constants; // Import Constants
import com.example.myfinalproject.java_classes.CourseClass; // Import data classes
import com.example.myfinalproject.services.MusicPlayer; // Import MusicPlayer service
import com.example.myfinalproject.java_classes.SubTopicClass; // Import data classes
import com.example.myfinalproject.java_classes.UserInfoClass; // Import data classes
import com.example.myfinalproject.java_classes.ValidationManager; // Import ValidationManager
import com.google.android.gms.tasks.OnCompleteListener; // Import task listeners
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task; // Import Task
import com.google.firebase.auth.FirebaseAuth; // Import Firebase Auth
import com.google.firebase.auth.FirebaseUser; // Import FirebaseUser
import com.google.firebase.firestore.DocumentReference; // Import Firestore classes
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList; // Import ArrayList

// Class: ProfileActivity
// Description: Activity to display user profile information, including username, email, profile icon, and course progress.
// Allows users to change their username and reset their course progress.
public class ProfileActivity extends AppCompatActivity {

    // --- UI Variables ---
    private Toolbar toolbar; // Toolbar for the activity
    private TextView username; // TextView to display username
    private TextView email; // TextView to display email
    private ImageView iconImage; // ImageView for the profile icon
    private Button resetUserNameButton; // Button to trigger username change dialog
    private Button resetCoursesButton; // Button to reset user's course progress

    // --- Firebase Variables ---
    private FirebaseFirestore db; // Firestore database instance
    private FirebaseUser user; // Currently authenticated Firebase user
    private FirebaseAuth mAuth; // Firebase Authentication instance

    // --- RecyclerView and Adapter ---
    private CourseProgressAdapter adapter; // Adapter for the RecyclerView displaying course progress
    private RecyclerView recyclerView; // RecyclerView to display course progress list

    // Function: onCreate
    // Description: Called when the activity is first created. Initializes the activity's layout,
    // UI views, loads user data, sets up listeners, and starts the music service.
    // Input: Bundle savedInstanceState - Contains data from a previous instance if available.
    // Output: void (initializes the activity).
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Step 1: Call the superclass onCreate method
        super.onCreate(savedInstanceState);
        // Step 2: Set the activity layout from the XML file (activity_profile.xml)
        setContentView(R.layout.activity_profile);
        // Step 3: Initialize UI views and Firebase instances
        initViews();
        // Step 4: Load user data from Firestore and populate the UI
        loadUserData();
        // Step 5: Initialize button click listeners
        initListeners();
        // Step 6: Start background music service
        startMusic();
    }

    // Function: initViews
    // Description: Initializes UI elements by finding them in the layout and initializes Firebase instances.
    // Sets the toolbar as the activity's action bar.
    // Input: none
    // Output: void (initializes UI elements and Firebase).
    private void initViews() {
        // Step 1: Initialize Toolbar and set it as the activity's action bar
        toolbar = findViewById(R.id.toolbar); // Find toolbar by ID in the layout
        setSupportActionBar(toolbar); // Set the toolbar as the support action bar

        // Step 2: Initialize TextViews for username and email by finding their IDs
        username = findViewById(R.id.username_text_view); // Find username TextView
        email = findViewById(R.id.email_text_view); // Find email TextView
        // Step 3: Initialize ImageView for the profile icon by finding its ID
        iconImage = findViewById(R.id.profile_image); // Find profile icon ImageView

        // Step 4: Initialize Buttons for user actions by finding their IDs
        resetUserNameButton = findViewById(R.id.edit_profile_name_button); // Find edit username button
        resetCoursesButton = findViewById(R.id.reset_courses_button); // Find reset courses button

        // Step 5: Initialize Firebase instances
        mAuth = FirebaseAuth.getInstance(); // Get FirebaseAuth instance
        db = FirebaseFirestore.getInstance(); // Get FirebaseFirestore instance
        user = mAuth.getCurrentUser(); // Get current logged-in Firebase user

        // Step 6: Initialize RecyclerView for course progress by finding its ID
        recyclerView = findViewById(R.id.recyclerView_courses); // Find RecyclerView
    }

    // Function: startMusic
    // Description: Creates an Intent to start the MusicPlayer service with a "PLAY" action
    // and starts the service.
    // Input: none
    // Output: void (starts the background music service).
    private void startMusic() {
        // Step 1: Create an intent targeting the MusicPlayer service
        Intent serviceIntent = new Intent(this, MusicPlayer.class);
        // Step 2: Add an action to the intent to instruct the service to start playback
        serviceIntent.putExtra("Action", "PLAY"); // Pass "PLAY" action
        // Step 3: Start the music service using the intent
        startService(serviceIntent); // or ContextCompat.startForegroundService(this, serviceIntent) if Android 8+ for foreground service
    }

    // Function: loadUserData
    // Description: Fetches the current user's data from Firestore using their UID.
    // On success, it populates the UI elements with the retrieved username, email,
    // profile icon, and course progress list. Handles cases where user is not logged in
    // or data fetching fails.
    // Input: none
    // Output: void (fetches and displays user data).
    private void loadUserData() {
        // Step 1: Check if a Firebase user is currently logged in
        if (user != null) {
            // Step 2: Get a reference to the user's document in Firestore within the "users" collection, using the user's UID
            DocumentReference userRef = db.collection("users").document(user.getUid());
            // Step 3: Fetch the user document data asynchronously
            userRef.get().addOnSuccessListener(documentSnapshot -> {
                // Function: onSuccess (OnSuccessListener for Firestore get)
                // Description: Called when fetching the user document is successful.
                // Input: DocumentSnapshot documentSnapshot - The document containing user data.
                // Output: void (Populates UI or shows messages).
                // Step 4: Check if the document exists
                if (documentSnapshot.exists()) {
                    // Step 5: Retrieve username and email strings from the document using getString()
                    String usernameText = documentSnapshot.getString("username");
                    String emailText = documentSnapshot.getString("email");

                    // Step 6: Retrieve iconId (stored as Long in Firestore)
                    int iconIdToDisplay = R.drawable.user_icon1; // Default icon resource ID
                    Long iconIdLong = documentSnapshot.getLong("iconId"); // Get the Long value from Firestore

                    // Step 7: Check if iconId exists (is not null) and convert it to an int
                    if (iconIdLong != null) {
                        iconIdToDisplay = iconIdLong.intValue(); // Convert Long to int
                        // Basic check for a potentially invalid resource ID (e.g., 0 or a value that might indicate an error)
                        if (iconIdToDisplay == 0) { // Check against a known problematic value, adjust if needed
                            iconIdToDisplay = R.drawable.user_icon1; // Use default if the value is 0
                        }
                    } else {
                        // Step 7.1: Log a warning if the iconId field is missing or null in Firestore
                        Log.w("ProfileActivity", "Icon ID field not found in Firestore or is null. Using default.");
                        // Step 7.2: Show a short toast message to the user about the missing icon ID
                        Toast.makeText(ProfileActivity.this, "Icon ID not found in Firestore or is null. Using default.", Toast.LENGTH_SHORT).show();
                    }

                    // Step 8: Log the determined icon ID being used (for debugging purposes)
                    Log.d("ProfileActivity", "Loading and setting icon ID from Firestore: " + iconIdToDisplay);

                    // Step 9: Convert the entire Firestore document to a UserInfoClass object
                    UserInfoClass userInfo = documentSnapshot.toObject(UserInfoClass.class);

                    // Step 10: Initialize and set up the adapter for the RecyclerView with course data
                    // Ensure the UserInfo object and its classes list are not null before using them
                    if (userInfo != null && userInfo.getClasses() != null) {
                        // Step 10.1: Create a new CourseProgressAdapter with the current activity context and the user's course list
                        adapter = new CourseProgressAdapter(ProfileActivity.this, userInfo.getClasses());
                        // Step 10.2: Set a LinearLayoutManager for the RecyclerView
                        recyclerView.setLayoutManager(new LinearLayoutManager(ProfileActivity.this));
                        // Step 10.3: Set the created adapter on the RecyclerView
                        recyclerView.setAdapter(adapter);
                    } else {
                        // Step 10.4: Log a warning if course data is missing for the adapter
                        Log.w("ProfileActivity", "UserInfo or classes list is null. Cannot populate RecyclerView.");
                        // Optionally show an empty state message or handle the missing data case appropriately
                        // For example, you might set an empty adapter or show a message TextView.
                    }

                    // Step 11: Set the profile image resource using the retrieved iconId
                    iconImage.setImageResource(iconIdToDisplay);

                    // Step 12: Set the username and email text in the UI, using default "N/A" if strings are null
                    username.setText("Username: " + (usernameText != null ? usernameText : "N/A")); // Display username
                    email.setText("Email:  " + (emailText != null ? emailText : "N/A")); // Display email

                } else {
                    // Step 13: Log a warning if the user data document was not found for the logged-in user's UID
                    Log.w("ProfileActivity", "User data document not found for UID: " + (user != null ? user.getUid() : "null"));
                    // Step 14: Show a toast message to the user indicating the data document was not found
                    Toast.makeText(ProfileActivity.this, "User data document not found.", Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(e -> {
                // Function: onFailure (OnFailureListener for Firestore get)
                // Description: Called when fetching the user document fails.
                // Input: Exception e - The exception indicating the failure.
                // Output: void (Logs and displays error message).
                // Step 15: Log the error when fetching data fails
                Log.e("ProfileActivity", "Error loading user data", e);
                // Step 16: Show a toast message to the user with the error details
                Toast.makeText(ProfileActivity.this, "Error loading user data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            });
        } else {
            // Step 17: Log a warning if the Firebase user object is null (user not logged in)
            Log.w("ProfileActivity", "Firebase user is null. Cannot load data.");
            // Step 18: Show a toast message indicating that the user is not logged in
            Toast.makeText(ProfileActivity.this, "User not logged in.", Toast.LENGTH_SHORT).show();
            // Optionally redirect the user to the login screen here.
        }
    }

    // Function: initListeners
    // Description: Sets up click listeners for the Reset Username and Reset Courses buttons.
    // Input: none
    // Output: void (sets up click listeners).
    private void initListeners() {
        // Step 1: Set click listener for the Reset Username button
        resetUserNameButton.setOnClickListener(new View.OnClickListener() {
            // Function: onClick (OnClickListener for Reset Username Button)
            // Description: Called when the Reset Username button is clicked. Checks user login,
            // fetches user data, and if successful, shows an AlertDialog to change the username.
            // Input: View view - The clicked view.
            // Output: void (Performs checks, fetches data, shows dialog, or shows toast).
            @Override
            public void onClick(View view) {
                // Step 1.1: Check if user is logged in
                if (user == null) {
                    Toast.makeText(ProfileActivity.this, "User not logged in.", Toast.LENGTH_SHORT).show();
                    return; // Exit if not logged in
                }
                // Step 1.2: Fetch user data again to ensure the document exists before showing the dialog

                db.collection("users").document(user.getUid()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (!documentSnapshot.exists()) {
                            Toast.makeText(ProfileActivity.this, "User data not found.", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        AlertDialog.Builder builder = new AlertDialog.Builder(ProfileActivity.this);
                        builder.setCancelable(true);
                        builder.setTitle("Change Username");

                        EditText editUsername = new EditText(ProfileActivity.this);
                        editUsername.setHint("New username...");
                        builder.setView(editUsername);

                        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        });

                        builder.setPositiveButton("Confirm", null);

                        AlertDialog dialog = builder.create();

                        // Show dialog BEFORE setting custom positive button logic
                        dialog.setOnShowListener(dialogInterface -> {
                            Button confirmButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                            confirmButton.setOnClickListener(view -> {
                                String newUsername = editUsername.getText().toString().trim();

                                if (ValidationManager.isUserNameValid(newUsername, editUsername)) {
                                    db.collection("users").document(user.getUid())
                                            .update("username", newUsername)
                                            .addOnSuccessListener(aVoid -> {
                                                username.setText("Username: " + newUsername);
                                                Toast.makeText(ProfileActivity.this, "Username updated successfully", Toast.LENGTH_SHORT).show();
                                                Log.d("ProfileActivity", "Username updated to: " + newUsername);
                                                dialog.dismiss();
                                            })
                                            .addOnFailureListener(e -> {
                                                Log.e("ProfileActivity", "Failed to update username", e);
                                                Toast.makeText(ProfileActivity.this, "Failed to update username", Toast.LENGTH_SHORT).show();
                                            });
                                }
                                // If invalid, ValidationManager handles the error. Dialog stays open.
                            });
                        });

                        dialog.show();
                    }
                });

            }
        });

        // Step 2: Set click listener for the Reset Courses button
        resetCoursesButton.setOnClickListener(new View.OnClickListener() {
            // Function: onClick (OnClickListener for Reset Courses Button)
            // Description: Called when the Reset Courses button is clicked. Checks user login,
            // fetches user data, resets the progress of all subtopics locally, updates the
            // UI, and updates the user's document in Firestore with the reset data.
            // Input: View view - The clicked view.
            // Output: void (Performs checks, fetches data, resets courses, updates UI/Firestore, shows toast).
            @Override
            public void onClick(View view) {
                // Step 2.1: Check if user is logged in
                if (user == null) {
                    Toast.makeText(ProfileActivity.this, "User not logged in.", Toast.LENGTH_SHORT).show();
                    return; // Exit if not logged in
                }
                // Step 2.2: Fetch user data again to get the current courses list for resetting
                db.collection("users").document(user.getUid()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    // Function: onComplete (OnCompleteListener for fetching user document for course reset)
                    // Description: Called when fetching the user document for course reset is complete.
                    // Resets course progress, updates UI, and updates Firestore.
                    // Input: Task<DocumentSnapshot> task - The completed task.
                    // Output: void (Resets courses, updates UI/Firestore, shows toast).
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        // Step 2.2.1: Check if the task was successful
                        if (task.isSuccessful()) {
                            DocumentSnapshot documentSnapshot = task.getResult();

                            // Step 2.2.2: Check if the document exists
                            if (documentSnapshot.exists()) {
                                // Step 2.2.3: Convert the document to a UserInfoClass object
                                UserInfoClass userInfo = documentSnapshot.toObject(UserInfoClass.class);
                                // Step 2.2.4: Check if userInfo and its classes list are valid
                                if (userInfo != null && userInfo.getClasses() != null) {
                                    ArrayList<CourseClass> courseClasses = userInfo.getClasses(); // Get the list of courses

                                    // Step 2.2.5: Iterate through each course and each subtopic to reset progress and selected status
                                    for (int i = 0; i < courseClasses.size(); i++) {
                                        // Step 2.2.5.1: Ensure the current course and its subtopics list are not null
                                        if (courseClasses.get(i) != null && courseClasses.get(i).getSubtopics() != null) {
                                            // Iterate through the subtopics of the current course
                                            for (SubTopicClass sub : courseClasses.get(i).getSubtopics()) {
                                                // Step 2.2.5.2: Ensure the current subtopic is not null
                                                if (sub != null) {
                                                    // Step 2.2.5.3: Set the selected status to false
                                                    sub.setSelected(false);
                                                    // Step 2.2.5.4: Set the progress to 0
                                                    sub.setProgress(0);
                                                }
                                            }
                                        }
                                    }

                                    // Step 2.2.6: Update the adapter's data with the modified (reset) courses list
                                    if (adapter != null) {
                                        adapter.setCoursesList(courseClasses); // Update the data in the RecyclerView adapter
                                    } else {
                                        // Log a warning if the adapter is null (should ideally not happen after initViews/loadUserData)
                                        Log.w("ProfileActivity", "CourseProgressAdapter is null when trying to reset courses.");
                                    }

                                    // Step 2.2.7: Update the "classes" field in the user's Firestore document with the reset courses data
                                    db.collection("users").document(user.getUid()).update("classes", courseClasses)
                                            .addOnSuccessListener(aVoid -> Log.d("ProfileActivity", "Courses reset successfully in Firestore.")) // Log success
                                            .addOnFailureListener(e -> Log.e("ProfileActivity", "Failed to reset courses in Firestore", e)); // Log failure

                                    // TODO: Add Loading screen (This was in the original code, consider adding a loading indicator)

                                    // Step 2.2.8: Show a success message to the user
                                    Toast.makeText(ProfileActivity.this, "Courses reset successfully", Toast.LENGTH_SHORT).show();
                                } else {
                                    // Step 2.2.9: Log a warning if user data or course list is null when attempting reset
                                    Log.w("ProfileActivity", "UserInfo or classes list is null when trying to reset courses.");
                                    // Step 2.2.10: Show a toast indicating no courses were found to reset
                                    Toast.makeText(ProfileActivity.this, "No courses to reset.", Toast.LENGTH_SHORT).show();
                                }

                            } else {
                                // Step 2.2.11: Log a warning if the user data document was not found when attempting reset
                                Log.w("ProfileActivity", "User data document not found for reset courses.");
                                // Step 2.2.12: Show a toast indicating a general error due to data not found
                                Toast.makeText(ProfileActivity.this, "An error occured (user data not found).", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            // Step 2.2.13: Log the exception if the task to get data fails
                            Log.e("ProfileActivity", "Task failed to get user data for reset courses", task.getException());
                            // Step 2.2.14: Show a toast indicating a general error due to task failure
                            Toast.makeText(ProfileActivity.this, "An error occured (task failed).", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }

    // Removed the duplicate isUserNameValid method that was copied here.
    // The validation logic is now handled by ValidationManager.isUserNameValid.


    // Function: onCreateOptionsMenu
    // Description: Initializes the options menu for the activity's toolbar.
    // Inflates the menu layout and hides the Profile menu item as the user is already on the profile page.
    // Input: Menu menu - The options menu in which you place your items.
    // Output: boolean - You must return true for the menu to be displayed; if you return false it will not be shown.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Step 1: Inflate the menu layout (menu.xml). This adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);

        // Step 2: Find the Profile menu item by its ID
        MenuItem profile = menu.findItem(R.id.menu_profile);
        // Step 3: Hide the profile menu item since the user is currently on the profile page
        profile.setVisible(false);

        // Step 4: Return true to indicate that the menu should be displayed
        return super.onCreateOptionsMenu(menu); // Call superclass method and return its result (which should be true)
    }

    // Function: onOptionsItemSelected
    // Description: Called when an item in the options menu is selected. Handles navigation/actions based on the selected item.
    // Includes actions for Log Out, Settings, Go Back, and Home.
    // Input: MenuItem item - The menu item that was selected.
    // Output: boolean - Return false to allow normal menu processing to proceed, true to consume it here.
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Step 1: Get the ID of the selected menu item
        int id = item.getItemId();

        // Step 2: Check which menu item was selected by comparing its ID
        if (id == R.id.menu_log_out) {
            // Step 2.1: If Log Out is selected, call the logout function
            logout(); // Perform logout logic
            // Step 2.2: Consume the event (return true)
            return true;

        } else if (id == R.id.menu_settings) {
            // Step 2.3: If Settings is selected, create an Intent to navigate to SettingsActivity
            Intent intent = new Intent(ProfileActivity.this, SettingsActivity.class);
            // Step 2.4: Start the SettingsActivity
            startActivity(intent);
            // Step 2.5: Consume the event
            return true;
        } else if (id == R.id.menu_go_back) {
            // Step 2.6: If Go Back is selected, handle navigation back
            // Step 2.6.1: Check if the activity was explicitly started for a result by looking at an intent extra
            boolean fromActivity = getIntent().getBooleanExtra("fromActivity", false);

            // Step 2.6.2: If started from another activity expecting a result, finish this activity
            if (fromActivity) {
                finish(); // Close the current activity, returning to the calling activity
            } else {
                // Step 2.6.3: Otherwise, use standard back navigation (simulating pressing the back button)
                onBackPressed(); // Navigate back using the activity stack
            }
            // Step 2.6.4: Consume the event
            return true;
        } else if (id == R.id.menu_home) {
            // Step 2.7: If Home is selected, navigate back to the main activity (MainActivity)
            Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
            // Step 2.7.1: Add flags to clear the activity stack and make MainActivity the new root task
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            // Step 2.7.2: Start MainActivity
            startActivity(intent);
            // Step 2.7.3: Finish the current activity (ProfileActivity) to remove it from the stack
            finish();
            // Step 2.7.4: Consume the event
            return true;
        }

        // Step 3: If the item ID doesn't match any of the handled actions, call the superclass method for default handling
        return super.onOptionsItemSelected(item);
    }

    // Function: logout
    // Description: Performs the user logout process. Signs the user out from Firebase,
    // clears the "Remember User" SharedPreferences flag, and navigates to the LogInActivity,
    // clearing the activity stack.
    // Input: none
    // Output: void (logs out user and navigates).
    public void logout() {
        // Step 1: Sign out the user from Firebase Authentication
        mAuth.signOut(); // Sign out the current user

        // Step 2: Create an Intent to navigate to the LogInActivity
        Intent intent = new Intent(ProfileActivity.this, LogInActivity.class);
        // Step 3: Add flags to clear the activity stack. This prevents the user from navigating back to previous activities after logging out.
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);

        // Step 4: Get SharedPreferences for app settings (using Constants.PREF_NAME) and modify the "Remember User" flag
        SharedPreferences sharedPreferences = getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE);
        sharedPreferences.edit().putBoolean(Constants.KEY_REMEMBER_USER, false).apply(); // Set remember user flag to false and apply changes

        // Step 5: Start the LogInActivity
        startActivity(intent);
        // Step 6: Finish the current activity (ProfileActivity) to remove it from the stack
        finish();
    }
}