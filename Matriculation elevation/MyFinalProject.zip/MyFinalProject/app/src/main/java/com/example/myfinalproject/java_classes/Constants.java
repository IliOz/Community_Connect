package com.example.myfinalproject.java_classes;

// Class: Constants
// Description: Holds various static final constants used throughout the application.
// This includes keys for SharedPreferences, Intents, Firebase Firestore fields,
// and identifiers for courses and subtopics.
public class Constants {
    // Music keys and related constants
    public static final int SONG_COUNT = 3; // Total number of default songs
    public static final String USER_SELECTED_COURSES_INTENT = "selectedCourses"; // Intent extra key for selected courses
    public static final String USER_SELECTED_ICON_INTENT = "selectedIcon"; // Intent extra key for selected icon
    public static final String PREF_NAME = "AppSettings"; // Name for SharedPreferences file
    public static final String KEY_VOLUME = "volume"; // SharedPreferences key for volume
    public static final String KEY_MUTED = "muted"; // SharedPreferences key for mute status
    public static final String KEY_CURRENT_SONG = "current_song"; // SharedPreferences key for current song index/ID
    public static final String KEY_SHUFFLE_ENABLED = "shuffle_enabled"; // SharedPreferences key for shuffle status
    public static final String KEY_THEME = "theme"; // SharedPreferences key for app theme
    public static final String KEY_EQUALIZER_ENABLED = "equalizer_enabled"; // SharedPreferences key for equalizer status
    public static final String KEY_REPEAT_MODE = "repeat_mode"; // SharedPreferences key for repeat mode
    public static final String KEY_OPTIONAL_SONGS = "optional_songs"; // SharedPreferences key for a set of optional songs
    public static final int STORAGE_PERMISSION_REQUEST_CODE = 123; // Request code for storage permission
    public static final String KEY_REMEMBER_USER = "rememberUser"; // SharedPreferences key for remember user login status

    // === User Timer & Audio Settings ===
    public static final String KEY_FOCUS_SESSION_LENGTH = "focusSessionLength"; // Duration in minutes per session
    public static final String KEY_BREAK_LENGTH = "breakLength"; // Break duration in minutes
    public static final String KEY_TIMER_VIBRATION_ENABLED = "timerVibrationEnabled"; // Vibration setting for timer

    public static final String KEY_IS_MUSIC_ON = "isMusicOn"; // Whether music is enabled
    public static final String KEY_MUSIC_VOLUME = "musicVolume"; // Music volume (0-100)
    public static final String KEY_IS_SHUFFLE_ON = "isShuffleOn"; // Whether shuffle is enabled
    public static final String KEY_SELECTED_SONG = "selectedSong"; // Name/ID of selected song

    // === User App Misc Settings ===
    public static final String KEY_NOTIFICATIONS_ENABLED = "notificationsEnabled"; // Reminder notifications toggle
    public static final String KEY_FIRST_TIME_USER = "firstTimeUser"; // First-time setup complete flag


    // User Key FROM SETTINGS.ACTIVITY
    public static final String KEY_ANNOY_SWITCH = "annoyButton"; // Key for annoying button";
    public static final String KEY_MOTIVATION_QUOTES_SWITCH = "motivationQuotes";
    public static final String KEY_REMIND_USER_SWITCH = "remainUser";



    // User keys (for Intent extras, Firebase fields, etc.)
    public static final String KEY_USERNAME = "username"; // Key for username
    public static final String KEY_PASSWORD = "password"; // Key for password
    public static final String KEY_EMAIL = "email"; // Key for email
    public static final String KEY_WHICH_ACTIVITY_CALLED = "ActivityNumber"; // Key indicating caller (e.g., 0 for signup, 1 for login, 2 for physics sandbox flow)
    public static final String KEY_ICON = "icon"; // Key for user icon ID
    public static final String KEY_COURSE_LIST = "courseList"; // Key for a list of courses
    public static final String KEY_DAILY_GOAL = "dailyGoal"; // Key for daily goal
    public static final String KEY_WEEKLY_GOAL = "weeklyGoal"; // Key for weekly goal
    public static final String KEY_TIME_SPENT = "timeSpent"; // Key for time spent

    public static final String ACTION_PLAY = "PLAY";

    // Course keys (for Intent extras, Firebase fields, etc.)
    public static final String KEY_COURSE = "selectedCourse"; // Key for a selected course
    public static final String KEY_COURSE_NAME = "courseName"; // Key for course name
    public static final String KEY_COURSE_DESCRIPTION = "courseDescription"; // Key for course description
    public static final String KEY_COURSE_ICON = "courseIcon"; // Key for course icon ID
    public static final String KEY_COURSE_POINTS = "coursePoints"; // Key for course points
    public static final String KEY_COURSE_SUBTOPICS = "courseSubtopics"; // Key for a list of course subtopics
    public static final String KEY_COURSE_ALL_SUBTOPICS = "courseAllSubtopics"; // Key for all subtopics in a course
    public static final String KEY_COURSE_SELECTED = "courseSelected"; // Key for a selected course object

    // Course and Subtopic Identifiers (specific names used in logic/data)
    // Physics course and subtopics
    public static final String KEY_PHYSICS = "Physics Mastery"; // Identifier for Physics course
    public static final String KEY_PHYSICS_NEWTONS_LAWS = "Newtons laws"; // Identifier for Newton's Laws subtopic
    public static final String KEY_PHYSICS_KINEMATIC_EQUATIONS = "Kinematics equations"; // Identifier for Kinematic Equations subtopic
    public static final String KEY_PHYSICS_MASTERING_FRICTION = "Friction"; // Identifier for Friction subtopic
    public static final String KEY_PHYSICS_SANDBOX = "Sandbox"; // Identifier for Physics Sandbox subtopic

    // Computer Science (CS) course and subtopics
    public static final String KEY_CS = "Computer science"; // Identifier for Computer Science course
    public static final String KEY_CS_INTRODUCTION = "Introduction"; // Identifier for CS Introduction subtopic
    public static final String KEY_CS_VARIABLES = "Variables"; // Identifier for CS Variables subtopic
    public static final String KEY_CS_VARIABLES_QUIZ = "Variables quiz"; // Identifier for CS Variables Quiz subtopic
    public static final String KEY_CS_CONDITIONALS = "Conditionals"; // Identifier for CS Conditionals subtopic

    // Other Course subtopic names (examples or unused)
    public static final String KEY_KINEMATICS = "Kinematics"; // Identifier for Kinematics (overlaps with Kinematics equations?)
    public static final String KEY_DYNAMICS = "Dynamics"; // Identifier for Dynamics
    public static final String KEY_OPTICS = "Optics"; // Identifier for Optics
    public static final String KEY_ELECTRO_MAGNETISM = "Electromagnetism"; // Identifier for Electromagnetism
}