package com.example.myfinalproject.adapters;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.util.TypedValue; // Import TypedValue
import java.util.ArrayList;

// Class: IconAdapter
// Description: Custom BaseAdapter for displaying a list of icon resource IDs in a GridView.
// It handles updating the displayed icons and setting their size.
// Input: Requires a Context and an ArrayList of icon resource IDs.
// Output: Provides Views for individual items in a GridView.
public class IconAdapter extends BaseAdapter {
    // Variables
    private Context context; // Context to create views
    private ArrayList<Integer> iconList; // List of icon resource IDs to display

    // Function: Constructor
    // Description: Initializes the IconAdapter with the context and the initial list of icons.
    // Input: Context context - The context of the activity or fragment.
    // Input: ArrayList<Integer> iconList - The initial list of icon resource IDs.
    // Output: Initializes the adapter with context and data.
    public IconAdapter(Context context, ArrayList<Integer> iconList) {
        // Step 1: Assign the provided context to the class variable
        this.context = context;
        // Step 2: Create a new ArrayList and copy the provided icon list into it (defensive copy)
        this.iconList = new ArrayList<>(iconList);
    }

    /**
     * Function: updateData
     * Description: Updates the adapter's icon list data and notifies the GridView to refresh its views.
     * Input: ArrayList<Integer> newIconList - The new list of icon resource IDs. Can be null.
     * Output: void (Updates the internal data and refreshes the GridView).
     */
    public void updateData(ArrayList<Integer> newIconList) {
        // Step 1: Clear the existing icon list
        iconList.clear();
        // Step 2: Check if the new list is not null
        if (newIconList != null) {
            // Step 3: Add all items from the new list to the internal icon list
            iconList.addAll(newIconList);
        }
        // Step 4: Notify the GridView that the data set has changed, prompting it to refresh
        notifyDataSetChanged();
    }

    // Function: getCount
    // Description: Returns the total number of items in the data set held by the adapter.
    // Input: none
    // Output: int - The total number of icons in the list.
    @Override
    public int getCount() {
        // Step 1: Return the size of the icon list
        return iconList.size();
    }

    // Function: getItem
    // Description: Gets the data item associated with the specified position in the data set.
    // Input: int i - The position of the item whose data we want within the adapter's data set.
    // Output: Object - The data at the specified position. (Returns null in this implementation)
    @Override
    public Object getItem(int i) {
        // Step 1: This adapter doesn't typically return the data object itself, so return null.
        return null;
    }

    // Function: getItemId
    // Description: Gets the row id associated with the specified position in the list.
    // Input: int position - The position of the item within the adapter's data set whose row id we want.
    // Output: long - The id of the item at the specified position.
    @Override
    public long getItemId(int position) {
        // Step 1: Return the position as the item ID (common practice when IDs are not distinct)
        return position;
    }

    // Function: getView
    // Description: Get a View that displays the data at the specified position in the data set.
    // Input: int position - The position of the item within the adapter's data set whose view we want.
    // Input: View convertView - The old view to reuse, if possible.
    // Input: ViewGroup parent - The parent that this view will eventually be attached to.
    // Output: View - A View corresponding to the data at the specified position.
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Variables
        ImageView imageView; // The ImageView to display the icon
        int sizeInDp = 80; // Desired size of the ImageView in density-independent pixels

        // Step 1: Calculate the desired size in pixels based on the DP value and screen density
        int sizeInPx = (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, sizeInDp, context.getResources().getDisplayMetrics());

        // Step 2: Check if an old view (convertView) is being reused
        if (convertView == null) {
            // Step 2.1: If there's no view to reuse, create a new ImageView
            imageView = new ImageView(context);
            // Step 2.2: Set the layout parameters for the ImageView (size)
            imageView.setLayoutParams(new GridView.LayoutParams(sizeInPx, sizeInPx));
            // Step 2.3: Set the scale type to fit the center of the ImageView
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        } else {
            // Step 3: If a view is being reused, cast it to an ImageView
            imageView = (ImageView) convertView;
        }

        // Step 4: Set the image resource based on the position and the icon list
        // Step 4.1: Check if the position is valid within the current icon list bounds
        if (position >= 0 && position < iconList.size()) {
            // Step 4.2: If valid, set the image resource using the resource ID from the list
            imageView.setImageResource(iconList.get(position));
        } else {
            // Step 4.3: If position is invalid (shouldn't happen if count is correct, but defensive), set no image
            imageView.setImageDrawable(null);
        }

        // Step 5: Return the configured ImageView
        return imageView;
    }
}