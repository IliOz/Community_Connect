package com.example.myfinalproject.fragments;

import android.content.Intent; // Import Intent
import android.os.Bundle; // Import Bundle
import android.os.Handler; // Import Handler
import android.os.Looper; // Import Looper
import android.util.Log; // Import Log
import android.view.LayoutInflater; // Import LayoutInflater
import android.view.View; // Import View
import android.view.ViewGroup; // Import ViewGroup
import android.view.animation.Animation; // Import Animation
import android.view.animation.AnimationUtils; // Import AnimationUtils
import android.widget.ImageView; // Import ImageView
import android.widget.Toast; // Import Toast

import androidx.annotation.NonNull; // Import annotations
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment; // Import Fragment

import com.example.myfinalproject.R; // Import R
import com.example.myfinalproject.activities.LogInActivity; // Import LogInActivity
import com.example.myfinalproject.activities.MainActivity; // Import MainActivity
import com.example.myfinalproject.java_classes.Constants; // Import Constants
import com.example.myfinalproject.java_classes.CourseClass; // Import CourseClass
import com.example.myfinalproject.java_classes.UserInfoClass; // Import UserInfoClass
import com.google.android.gms.tasks.OnCompleteListener; // Import OnCompleteListener
import com.google.android.gms.tasks.Task; // Import Task
import com.google.firebase.auth.AuthResult; // Import AuthResult
import com.google.firebase.auth.FirebaseAuth; // Import FirebaseAuth
import com.google.firebase.auth.FirebaseUser; // Import FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore; // Import FirebaseFirestore

import java.util.ArrayList; // Import ArrayList
import java.util.Objects; // Import Objects

// Class: LoadingFragment
// Description: A Fragment displayed during loading processes, such as user sign-in, sign-up,
// or initial app startup. It shows an animation and handles authentication/navigation logic
// based on arguments passed to it.
// Input: Requires arguments Bundle containing email, password, activity type, username,
// selected icon ID, and selected courses.
// Output: Handles authentication, saves user data to Firestore, and navigates to the next activity.
public class LoadingFragment extends Fragment {

    // UI Variables
    private ImageView loadingImage; // ImageView for the loading animation

    // Firebase Variables
    private FirebaseAuth mAuth; // Firebase Authentication instance

    // Data Variables (received via arguments)
    private String email; // User email
    private String password; // User password
    private String username; // Username (for sign-up)
    private ArrayList<CourseClass> selectedCourseObjects; // List of courses selected (for sign-up)
    private int selectedIconId; // User's selected icon resource ID (for sign-up)
    // Indicates which activity initiated this fragment (0 for Sign-up, 1 for Login, 2 for initial load?)
    private int whichActivityCalled;

    // Function: onCreateView
    // Description: Called to create the view hierarchy for the fragment. Inflates the layout,
    // initializes views, retrieves arguments, starts the loading animation, and initiates the
    // authentication/process flow based on 'whichActivityCalled'.
    // Input: LayoutInflater inflater - The LayoutInflater object that can be used to inflate any views in the fragment.
    // Input: ViewGroup container - If non-null, this is the parent view that the fragment's UI should be attached to.
    // Input: Bundle savedInstanceState - If non-null, this fragment is being re-constructed from a previous saved state.
    // Output: View - The root View of the fragment's layout.
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Step 1: Inflate the layout for this fragment from activity_loading.xml
        View view = inflater.inflate(R.layout.activity_loading, container, false);

        // Step 2: Find and assign the loading image view
        loadingImage = view.findViewById(R.id.loading_image);
        // Step 3: Get Firebase Auth instance
        mAuth = FirebaseAuth.getInstance();

        // Step 4: Retrieve arguments passed to the fragment
        if (getArguments() != null) {
            // Step 4.1: Get email string, default to empty
            email = getArguments().getString(Constants.KEY_EMAIL, "");
            // Step 4.2: Get password string, default to empty
            password = getArguments().getString(Constants.KEY_PASSWORD, "");
            // Step 4.3: Get the calling activity indicator int, default to 0
            whichActivityCalled = getArguments().getInt(Constants.KEY_WHICH_ACTIVITY_CALLED, 0);
            // Step 4.4: Get username string, default to empty
            username = getArguments().getString(Constants.KEY_USERNAME, "");
            // Step 4.5: Get selected icon ID int, default value is set by getInt
            selectedIconId = getArguments().getInt(Constants.KEY_ICON);
            // Step 4.6: Get selected course objects list (assuming Serializable), cast to ArrayList<CourseClass>
            selectedCourseObjects = (ArrayList<CourseClass>) getArguments().getSerializable(Constants.KEY_COURSE_SELECTED);
        }

        // Step 5: Load the rotation animation from resources
        Animation rotateAnimation = AnimationUtils.loadAnimation(requireContext(), R.anim.rotate_animation);
        // Step 6: Start the animation on the loading image
        loadingImage.startAnimation(rotateAnimation);

        // Step 7: Begin the authentication or navigation flow based on 'whichActivityCalled'
        if (whichActivityCalled == 1) {
            // Step 7.1: If called for Login (1), initiate the sign-in process
            signInWithEmailAndPassword(email, password);
        } else if (whichActivityCalled == 0) {
            // Step 7.2: If called for Sign-up (0), initiate the create user process
            createUserWithEmailAndPassword(email, password, username, selectedIconId ,selectedCourseObjects);
        } else if (whichActivityCalled == 2) {
            // Step 7.3: If called for initial load/check (2), just wait and proceed to MainActivity
            waitAndProceed(new Intent(getActivity(), MainActivity.class));
        }
        // Step 8: Return the root view
        return view;
    }

    // Function: waitAndProceed
    // Description: Waits for a specified delay, then starts the given Intent and finishes the hosting activity.
    // Includes a check to ensure the fragment is still attached before proceeding.
    // Input: final Intent intent - The intent to start after the delay.
    // Output: void (Starts the intent and finishes activity after delay).
    private void waitAndProceed(final Intent intent) {
        // Step 1: Create a new Handler associated with the main Looper
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            // Function: run (Runnable)
            // Description: This code runs after the postDelayed timer expires.
            // Input: none
            // Output: void (Starts the intent or logs an error if fragment is detached).
            @Override
            public void run() {
                // Step 1.1: Check if the fragment is still added to an activity and if the activity is not null
                if (isAdded() && getActivity() != null) {
                    // Step 1.1.1: Log that the delay is finished and where it's proceeding
                    Log.d("LoadingFragment", "Delay finished, proceeding to " + intent.getComponent());
                    // Step 1.1.2: Start the specified intent
                    startActivity(intent); // <--- This line starts the activity contained in the 'intent' object.
                    // Step 1.1.3: Finish the activity hosting this fragment
                    getActivity().finish();
                } else {
                    // Step 1.2: If the fragment is detached, log an error
                    Log.e("LoadingFragment", "Fragment not attached, cannot proceed");
                }
            }
        }, 3000); // Step 2: Set the delay time in milliseconds (3000 = 3 seconds)
    }

    // Function: signInWithEmailAndPassword
    // Description: Attempts to sign in a user with the provided email and password using Firebase Auth.
    // Navigates to MainActivity on success or LogInActivity on failure after a delay.
    // Input: String email - The user's email.
    // Input: String password - The user's password.
    // Output: void (Initiates Firebase sign-in and handles the result).
    private void signInWithEmailAndPassword(String email, String password) {
        // Step 1: Call the Firebase Auth sign-in method
        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            // Function: onComplete (OnCompleteListener)
            // Description: Called when the sign-in task completes.
            // Input: Task<AuthResult> task - The completed authentication task.
            // Output: void (Handles task success/failure, shows toast, and calls waitAndProceed).
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                // Step 1.1: Check if fragment is detached before proceeding to avoid crashes
                if (!isAdded() || getActivity() == null) return;

                // Step 1.2: Declare an Intent variable
                Intent intent;
                // Step 1.3: Check if the authentication task was successful
                if (task.isSuccessful()) {
                    // Step 1.3.1: If successful, create an intent to go to MainActivity
                    intent = new Intent(getActivity(), MainActivity.class);
                } else {
                    // Step 1.3.2: If failed, create an intent to go back to LogInActivity
                    intent = new Intent(getActivity(), LogInActivity.class);
                    // Step 1.3.3: Check if context is available and show a toast with the error message
                    if (getContext() != null) {
                        // So it wont consider the user as entered to the system
                        mAuth.signOut();
                        // Use Objects.requireNonNull to safely get the exception message if task is not successful
//                        Toast.makeText(getContext(), "Logging failed: " + Objects.requireNonNull(task.getException()).getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                        Toast.makeText(getContext(), "Wrong credentials", Toast.LENGTH_SHORT).show();
                    }
                }
                // Step 1.4: Call waitAndProceed with the determined intent to navigate after a delay
                waitAndProceed(intent);
            }
        });
    }

    // Function: createUserWithEmailAndPassword
    // Description: Attempts to create a new user with the provided email and password using Firebase Auth.
    // On success, saves additional user info (username, icon, courses) to Firestore and navigates to MainActivity.
    // On failure (Auth or Firestore), shows a toast message.
    // Input: String email - The new user's email.
    // Input: String password - The new user's password.
    // Input: String username - The new user's username.
    // Input: int icon - The resource ID of the new user's icon.
    // Input: ArrayList<CourseClass> selectedCourseObjects - The list of courses selected by the new user.
    // Output: void (Initiates Firebase user creation and subsequent data saving/navigation).
    public void createUserWithEmailAndPassword(String email, String password, String username, int icon, ArrayList<CourseClass> selectedCourseObjects) {
        // Step 1: Call the Firebase Auth create user method
        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            // Function: onComplete (OnCompleteListener)
            // Description: Called when the user creation task completes.
            // Input: Task<AuthResult> task - The completed authentication task.
            // Output: void (Handles task success/failure, saves data to Firestore on success, shows feedback).
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                // Step 1.1: Check if the user creation task was successful
                if (task.isSuccessful()) {
                    // Step 1.1.1: Get the newly created Firebase user
                    FirebaseUser firebaseUser = mAuth.getCurrentUser();
                    // Step 1.1.2: Check if the user object is not null
                    if (firebaseUser != null) {
                        // Step 1.1.2.1: Get the new user's UID
                        String userId = firebaseUser.getUid();

                        // Step 1.1.2.2: Create a UserInfoClass object with the provided details
                        UserInfoClass userInfo = new UserInfoClass(username, password, email, selectedCourseObjects, icon);

                        // Step 1.1.2.3: Get a Firestore instance
                        FirebaseFirestore firestore = FirebaseFirestore.getInstance();

                        // Step 1.1.2.4: Save the user data (UserInfoClass object) in Firestore
                        // Set the document ID to the user's UID
                        firestore.collection("users").document(userId)
                                .set(userInfo) // Set the data
                                .addOnSuccessListener(aVoid -> {
                                    // Function: onSuccess (OnSuccessListener for Firestore set)
                                    // Description: Called when the user data is successfully saved to Firestore.
                                    // Input: Void aVoid - Placeholder.
                                    // Output: void (Logs success and navigates to MainActivity).
                                    // Step 1.1.2.4.1.1: Log successful data addition
                                    Log.d("Firestore", "User data added successfully");
                                    // Step 1.1.2.4.1.2: Create an intent to navigate to MainActivity
                                    Intent intent = new Intent(getContext(), MainActivity.class);
                                    // Step 1.1.2.4.1.3: Start MainActivity (implicitly finishing Login/Signup flow)
                                    startActivity(intent);
                                })
                                .addOnFailureListener(e -> {
                                    // Function: onFailure (OnFailureListener for Firestore set)
                                    // Description: Called when saving user data to Firestore fails.
                                    // Input: Exception e - The exception detailing the failure.
                                    // Output: void (Logs error and shows error toast).
                                    // Step 1.1.2.4.2.1: Log the error during data addition
                                    Log.e("Firestore", "Error adding user data", e);
                                    // Step 1.1.2.4.2.2: Show a toast message with the error details
                                    Toast.makeText(getContext(), "Error adding user data: " + (e.getLocalizedMessage() != null ? e.getLocalizedMessage() : "Unknown error"), Toast.LENGTH_SHORT).show();
                                    // Note: Ideally, should also handle navigating back to signup or showing a retry option.
                                });
                    } else {
                        // Step 1.1.3: If user is null after successful creation (unlikely), log an error and show a toast
                        Log.e("Signup", "User is null after successful creation.");
                        Toast.makeText(getContext(), "Signup failed (null user)", Toast.LENGTH_SHORT).show();
                        // Note: Should navigate back to signup activity here.
                    }
                } else {
                    // Step 1.2: If user creation task failed (Firebase Auth error)
                    // Step 1.2.1: Log the Firebase Auth error
                    Log.e("Firebase", "Error checking email existence", task.getException());
                    // Step 1.2.2: Show a toast message with the Firebase Auth error message
                    Toast.makeText(getContext(), "Signup failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    // Note: Should navigate back to signup activity here. Can also add specific checks for
                    // FirebaseAuthWeakPasswordException, FirebaseAuthInvalidCredentialsException, FirebaseAuthUserCollisionException etc.
                }
            }
        });
    }
}