package com.example.myfinalproject.gamesActivities.Physics;

import android.animation.AnimatorSet; // Import animation classes
import android.animation.ObjectAnimator;
import android.content.Intent; // Import Intent
import android.content.SharedPreferences; // Import SharedPreferences
import android.os.Bundle; // Import Bundle
import android.util.DisplayMetrics; // Import DisplayMetrics
import android.util.Log; // Import Log
import android.view.LayoutInflater; // Import LayoutInflater
import android.view.Menu; // Import Menu
import android.view.MenuInflater; // Import MenuInflater
import android.view.MenuItem; // Import MenuItem
import android.view.View; // Import View
import android.view.ViewGroup; // Import ViewGroup
import android.widget.Button; // Import Button
import android.widget.ImageView; // Import ImageView
import android.widget.SeekBar; // Import SeekBar
import android.widget.TextView; // Import TextView
import android.widget.Toast; // Import Toast

import androidx.annotation.NonNull; // Import annotations
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity; // Import AppCompatActivity
import androidx.appcompat.widget.Toolbar; // Import Toolbar
import androidx.fragment.app.Fragment; // Import Fragment
import androidx.fragment.app.FragmentManager; // Import FragmentManager

import com.example.myfinalproject.R; // Import R
import com.example.myfinalproject.activities.LogInActivity; // Import activities
import com.example.myfinalproject.activities.MainActivity;
import com.example.myfinalproject.activities.ProfileActivity;
import com.example.myfinalproject.activities.SettingsActivity;
import com.example.myfinalproject.adapters.SubtopicAdapter; // Import SubtopicAdapter
import com.example.myfinalproject.java_classes.Constants; // Import Constants
import com.example.myfinalproject.java_classes.CourseClass; // Import data classes
import com.example.myfinalproject.java_classes.SubTopicClass;
import com.example.myfinalproject.java_classes.UserInfoClass;
import com.google.android.gms.tasks.OnFailureListener; // Import Firebase task listeners
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth; // Import Firebase Auth
import com.google.firebase.auth.FirebaseUser; // Import FirebaseUser
import com.google.firebase.firestore.DocumentReference; // Import Firestore classes
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList; // Import ArrayList

// Class: MasteringFrictionFragment
// Description: A Fragment representing an interactive exercise on friction physics.
// Users adjust force, mass, and friction coefficient using SeekBars, and the fragment
// animates a ball's motion based on calculated physics. It includes logic to update
// user progress in Firestore.
// Input: none (as it's a Fragment, interacts via UI and Firebase)
// Output: Displays UI, handles user input, performs physics calculations, animates ball,
// updates Firestore, navigates.
public class MasteringFrictionFragment extends Fragment {
    // --- UI Variables ---
    private Button continueButton; // Button to proceed to the next subtopic
    private Button startButton; // Button to start the simulation/animation

    private SeekBar frictionSeekBar; // SeekBar for friction coefficient input
    private SeekBar forceSeekBar; // SeekBar for applied force input
    private SeekBar massSeekBar; // SeekBar for mass input

    private TextView coefficient; // TextView to display friction coefficient value
    private TextView force; // TextView to display applied force value
    private TextView mass; // TextView to display mass value

    private ImageView ball; // ImageView representing the animated ball

    // --- Firebase Variables ---
    // currentUser variable declared but not directly used in the provided methods
    private FirebaseFirestore firestore; // Firestore database instance
    private FirebaseAuth mAuth; // Firebase Authentication instance

    // --- State Variable ---
    private boolean isTaskComplete = false; // Flag indicating if the main task (starting animation) has been completed

    // Function: onCreateView
    // Description: Called to create the view hierarchy for the fragment.
    // Inflates the layout, initializes views, listeners, Firebase, sets up SeekBars,
    // and sets up the toolbar menu.
    // Input: LayoutInflater inflater - The LayoutInflater object that can be used to inflate any views in the fragment.
    // Input: ViewGroup container - If non-null, this is the parent view that the fragment's UI should be attached to.
    // Input: Bundle savedInstanceState - If non-null, this fragment is being re-constructed from a previous saved state.
    // Output: View - The root View of the fragment's layout.
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Step 1: Inflate the layout for this fragment from activity_mastering_friction.xml
        View view = inflater.inflate(R.layout.activity_mastering_friction, container, false);

        // Step 2: Initialize UI views
        initializeUI(view);
        // Step 3: Initialize event listeners for buttons
        initListeners();
        // Step 4: Set up listeners for SeekBars to update text views
        seekBarsUpdate();
        // Step 5: Indicate that this fragment has its own options menu
        setHasOptionsMenu(true); // IMPORTANT: Enables menu callbacks

        // Step 6: Get the main activity's Toolbar and set it as the action bar for the fragment
        Toolbar toolbar = requireActivity().findViewById(R.id.toolbarMain); // Find toolbar in the hosting activity
        ((AppCompatActivity) requireActivity()).setSupportActionBar(toolbar); // Set it as the action bar

        // Step 7: Return the root view of the fragment
        return view;
    }

    // Function: initListeners
    // Description: Sets up click listeners for the Continue and Start buttons.
    // The Continue button updates progress and navigates. The Start button calculates
    // motion based on SeekBar values and animates the ball.
    // Input: none
    // Output: void (Sets up listeners).
    private void initListeners() {
        // Step 1: Set a click listener for the Continue button
        continueButton.setOnClickListener(new View.OnClickListener() {
            // Function: onClick
            // Description: Called when the Continue button is clicked. Updates subtopic progress and navigates to the next fragment.
            // Input: View view - The clicked view (the button).
            // Output: void (Updates progress and navigates).
            @Override
            public void onClick(View view) {
                // Step 1.1: Update the subtopic progress in Firestore based on task completion state
                updateSubtopicProgress();
                // Step 1.2: Use getParentFragmentManager to replace the current fragment with the next one (PhysicSandBoxFragment)
                getParentFragmentManager().beginTransaction() // Use the parent fragment manager
                        .replace(R.id.fragment_container_main, new PhysicSandBoxFragment()) // Replace current fragment with the new one
                        .addToBackStack(null) // Optional: Add the current fragment to the back stack so user can navigate back
                        .commit(); // Commit the transaction
            }
        });

        // Step 2: Set a click listener for the Start button
        startButton.setOnClickListener(new View.OnClickListener() {
            // Function: onClick
            // Description: Called when the Start button is clicked. Retrieves SeekBar values,
            // calculates physics, determines animation parameters, and runs the ball animation.
            // Input: View view - The clicked view (the button).
            // Output: void (Calculates motion, animates ball, sets isTaskComplete flag).
            @Override
            public void onClick(View view) {
                // Step 2.1: Position the ball at the left edge before animation
                ball.setX(0);

                // Step 2.2: Measure the ball's width. Use requireView() to refer to the fragment's root view.
                ball.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
                int ballWidth = ball.getMeasuredWidth();

                // Step 2.3: Get screen width using requireActivity()
                DisplayMetrics displayMetrics = new DisplayMetrics();
                requireActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
                int screenWidth = displayMetrics.widthPixels;

                // Step 2.4: Define the maximum allowed distance the ball can travel (screen width minus a margin)
                int maxAllowedDistance = screenWidth - 250; // Adjusted value (e.g., subtracting 250); change as needed.

                // Step 2.5: Retrieve physics parameters from SeekBars
                int force = forceSeekBar.getProgress();       // Expected max: 100 N (from SeekBar max)
                int mass = massSeekBar.getProgress();           // Expected min: 1 kg (assuming SeekBar min is 1)
                // Calculate friction coefficient (assuming SeekBar max is 100 for 0.0-1.0 range)
                double frictionCoefficient = (double) frictionSeekBar.getProgress() / frictionSeekBar.getMax(); // Result 0.0–1.0
                // Step 2.5.1: Calculate the friction force (assuming friction = coefficient * normal_force, normal_force = mass * g, g ~ 10)
                double friction = frictionCoefficient * 10 * mass; // Simplified friction model

                // Step 2.5.2: Calculate acceleration using Newton's Second Law: a = (Net Force) / mass, where Net Force = Applied Force - Friction
                double acceleration = (force - friction) / (double) mass;
                // Step 2.5.3: Ensure acceleration is not negative (object won't accelerate backward unless force < friction)
                if (acceleration < 0) acceleration = 0; // Object stops if friction >= applied force

                // Step 2.6: Define simulation time (in seconds)
                float time = 5f;

                // Step 2.7: Calculate the distance the ball travels using the kinematic equation: d = v_0*t + 0.5*a*t²
                // Assuming initial velocity v_0 = 0
                float physicsDistance = 0 * time + 0.5f * (float) acceleration * time * time; // Simplified: d = 0.5 * a * t^2

                // Step 2.8: Compute a scaling factor to map calculated physics distance to screen pixels
                // The scaling factor ensures that the maximum expected physics distance maps to the maximum allowed screen distance.
                float maxPhysicsDistance = 0.5f * 100 * time * time; // Calculate max possible physics distance with max acceleration (assuming max_net_force / min_mass)
                float scalingFactor = (float) maxAllowedDistance / maxPhysicsDistance; // Scale max allowed screen distance by max physics distance

                // Step 2.9: Determine the final travel distance in pixels by scaling the calculated physics distance
                float finalDistance = physicsDistance * scalingFactor;
                // Step 2.10: Clamp the final distance to ensure it doesn't exceed the maximum allowed screen distance
                if (finalDistance > maxAllowedDistance) {
                    // Show a toast if the calculated distance is clamped (optional feedback)
                    Toast.makeText(getContext(), "Calculated distance clamped to max screen distance", Toast.LENGTH_SHORT).show();
                    finalDistance = maxAllowedDistance;
                }

                // Step 2.11: Create translation animation (horizontal movement)
                // ObjectAnimator animates the "translationX" property of the ball from 0f to finalDistance
                ObjectAnimator translationAnimator = ObjectAnimator.ofFloat(ball, "translationX", 0f, finalDistance);
                translationAnimator.setDuration((long) (time * 1000)); // Set animation duration based on simulation time (in milliseconds)

                // Step 2.12: Add rolling (rotation) animation:
                // Step 2.12.1: Calculate the ball's circumference (assumes ball is circular)
                float ballCircumference = ballWidth * (float) Math.PI;
                // Step 2.12.2: Calculate rotation degrees: how many degrees the ball should rotate to "roll" over the finalDistance
                float rotationDegrees = (finalDistance / ballCircumference) * 360;
                // Step 2.12.3: Create ObjectAnimator for rotation
                ObjectAnimator rotationAnimator = ObjectAnimator.ofFloat(ball, "rotation", 0f, rotationDegrees);
                rotationAnimator.setDuration((long) (time * 1000)); // Set animation duration

                // Step 2.13: Play both animations (translation and rotation) together simultaneously
                AnimatorSet animatorSet = new AnimatorSet(); // Create an AnimatorSet
                animatorSet.playTogether(translationAnimator, rotationAnimator); // Play translation and rotation together
                animatorSet.start(); // Start the animation set

                // Step 2.14: Mark the task as complete (the simulation/animation has been run)
                isTaskComplete = true;
            }
        });
    }

    // Function: initializeUI
    // Description: Initializes UI elements by finding them in the layout.
    // Input: View view - The root view of the fragment's layout.
    // Output: void (Initializes UI views and Firebase instances).
    private void initializeUI(View view) {
        // Step 1: Find and assign the Continue button
        continueButton = view.findViewById(R.id.continueButton3); // Note: Assumes button ID from layout

        // Step 2: Find and assign TextViews for displaying SeekBar values
        force = view.findViewById(R.id.forceTextView); // TextView for force value
        mass = view.findViewById(R.id.massTextView); // TextView for mass value
        coefficient = view.findViewById(R.id.frictionTextView); // TextView for friction coefficient value

        // Step 3: Find and assign SeekBars
        frictionSeekBar = view.findViewById(R.id.frictionSeekBar); // SeekBar for friction
        forceSeekBar = view.findViewById(R.id.forceSeekBar); // SeekBar for force
        massSeekBar = view.findViewById(R.id.massSeekBar); // SeekBar for mass

        // Step 4: Find and assign the Start button
        startButton = view.findViewById(R.id.startButton1); // Note: Assumes button ID from layout

        // Step 5: Find and assign the Ball ImageView
        ball = view.findViewById(R.id.ballImage); // ImageView for the ball

        // Step 6: Initialize Firebase Authentication and Firestore instances
        mAuth = FirebaseAuth.getInstance(); // Get Auth instance
        firestore = FirebaseFirestore.getInstance(); // Get Firestore instance
    }

    // Function: seekBarsUpdate
    // Description: Sets up OnSeekBarChangeListener for each SeekBar to update the corresponding
    // TextViews whenever the SeekBar's progress changes.
    // Input: none
    // Output: void (Sets up SeekBar listeners).
    private void seekBarsUpdate() {
        // Step 1: Set listener for the Friction SeekBar
        frictionSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            // Function: onProgressChanged
            // Description: Called when the progress level of the SeekBar has changed. Updates the TextView.
            // Input: SeekBar seekBar - The SeekBar whose progress has changed.
            // Input: int i - The current progress level.
            // Input: boolean b - True if the change was initiated by the user, false otherwise.
            // Output: void (Updates friction coefficient TextView).
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                // Step 1.1: Update the coefficient TextView text with the current progress (scaled to 0.0-1.0)
                coefficient.setText("Friction Coefficient: " + ((float) seekBar.getProgress() / 100)); // Assumes SeekBar max is 100
            }
            // Function: onStartTrackingTouch
            // Description: Called when the user has started a touch gesture on the SeekBar. No action here.
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // No action needed when touch starts
            }
            // Function: onStopTrackingTouch
            // Description: Called when the user has finished a touch gesture on the SeekBar. Updates the TextView again.
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Step 1.2: Update the coefficient TextView text once touch stops (redundant with onProgressChanged but ensures final value is shown)
                coefficient.setText("Friction Coefficient: " + ((float) seekBar.getProgress() / 100)); // Assumes SeekBar max is 100
            }
        });

        // Step 2: Set listener for the Force SeekBar
        forceSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            // Function: onProgressChanged
            // Description: Called when the progress level of the SeekBar has changed. Updates the TextView.
            // Input: SeekBar seekBar - The SeekBar whose progress has changed.
            // Input: int i - The current progress level.
            // Input: boolean b - True if the change was initiated by the user, false otherwise.
            // Output: void (Updates force TextView).
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                // Step 2.1: Update the force TextView text with the current progress
                force.setText("Applied Force: " + seekBar.getProgress() + " N");
            }
            // Function: onStartTrackingTouch
            // Description: Called when the user has started a touch gesture on the SeekBar. No action here.
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // No action needed when touch starts
            }
            // Function: onStopTrackingTouch
            // Description: Called when the user has finished a touch gesture on the SeekBar. Updates the TextView again.
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Step 2.2: Update the force TextView text once touch stops (redundant with onProgressChanged)
                force.setText("Applied Force: " + seekBar.getProgress() + " N");
            }
        });

        // Step 3: Set listener for the Mass SeekBar
        massSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            // Function: onProgressChanged
            // Description: Called when the progress level of the SeekBar has changed. Updates the TextView.
            // Input: SeekBar seekBar - The SeekBar whose progress has changed.
            // Input: int i - The current progress level.
            // Input: boolean b - True if the change was initiated by the user, false otherwise.
            // Output: void (Updates mass TextView).
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                // Step 3.1: Update the mass TextView text with the current progress
                mass.setText("Mass: " + massSeekBar.getProgress() + " kg");
            }
            // Function: onStartTrackingTouch
            // Description: Called when the user has started a touch gesture on the SeekBar. No action here.
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // No action needed when touch starts
            }
            // Function: onStopTrackingTouch
            // Description: Called when the user has finished a touch gesture on the SeekBar. Updates the TextView again.
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Step 3.2: Update the mass TextView text once touch stops (redundant with onProgressChanged)
                mass.setText("Mass: " + massSeekBar.getProgress() + " kg");
            }
        });
    }

    // Function: updateSubtopicProgress
    // Description: Updates the progress for the 'Mastering Friction' Physics subtopic in Firestore.
    // It retrieves the current user's courses, finds the specific subtopic, sets its progress
    // (100% if the task is complete, 50% otherwise), saves the modified course list back to Firestore,
    // and shows a toast message on success or failure.
    // Input: none
    // Output: void (Fetches user data, updates Firestore, shows feedback).
    private void updateSubtopicProgress() {
        // Step 1: Get the currently logged-in Firebase user
        FirebaseUser currentUser = mAuth.getCurrentUser(); // Use mAuth to get the current user

        // Step 2: Check if the user is signed in
        if (currentUser == null) {
            // Step 2.1: If user is not signed in, show a toast and exit the method
            Toast.makeText(getContext(), "User not signed in", Toast.LENGTH_SHORT).show();
            return; // Exit the method
        }

        // Step 3: Get the user's UID
        String userId = currentUser.getUid();
        // Step 4: Get a document reference to the user's data in Firestore
        DocumentReference userRef = firestore.collection("users").document(userId); // Use firestore instance

        // Step 5: Retrieve current user data from Firestore asynchronously using addOnCompleteListener
        // 1. *GET* the current data from Firestore. You MUST do this first.
        userRef.get().addOnCompleteListener(task -> {
            // Function: onComplete (OnCompleteListener for Firestore get)
            // Description: Called when the task to get user data completes.
            // Input: Task<DocumentSnapshot> task - The completed task.
            // Output: void (Processes user data, updates subtopic, saves to Firestore, shows feedback).
            // Step 5.1: Check if the task was successful
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                // Step 5.2: Check if the document exists and is not null
                if (document != null && document.exists()) {
                    // Step 5.3: Convert the document to a UserInfoClass object
                    UserInfoClass userInfo = document.toObject(UserInfoClass.class);

                    // Step 5.4: Check if UserInfo object and its classes list are valid
                    if (userInfo != null && userInfo.getClasses() != null) {
                        // Step 5.5: Get the list of existing courses (creates a local copy/reference)
                        // 2. *Modify* the data *locally*.
                        ArrayList<CourseClass> courses = userInfo.getClasses(); // Get the existing list

                        // Step 5.6: Find the specific subtopic ('Mastering Friction') and update its progress
                        // Find and update
                        boolean updated = false; // Flag to track if progress was updated
                        for (CourseClass course : courses) {
                            if (course.getSubtopics() != null) { // Null Check for subtopics list
                                for (SubTopicClass subTopic : course.getSubtopics()) {
                                    // Step 5.6.1: Check if the current subtopic matches the target subtopic name
                                    if (subTopic.getName().equals(Constants.KEY_PHYSICS_MASTERING_FRICTION)) {
                                        // Step 5.6.2: Set the progress based on whether the task was completed (animation run)
                                        if (isTaskComplete)
                                            subTopic.setProgress(100); // Set progress to 100% if task completed
                                        else
                                            subTopic.setProgress(50); // Set progress to 50% if task not completed
                                        updated = true; // Set the flag to true
                                        break; // Exit the inner loop once found.
                                    }
                                }
                            }
                            // Step 5.6.3: If the subtopic was updated, exit the outer course loop as well
                            if (updated) break; // Exit also the course loop
                        }

                        // Step 5.7: Update the 'classes' field in the user's Firestore document with the modified courses list
                        // 3. *Update* Firestore with the *modified* data.
                        userRef.update("classes", courses) // Now 'courses' has the updated progress
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    // Function: onSuccess (OnSuccessListener for Firestore update)
                                    // Description: Called when the Firestore update succeeds.
                                    // Input: Void aVoid - Placeholder.
                                    // Output: void (Shows success toast).
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        // Step 5.7.1.1: Show a toast message indicating progress update success
                                        Toast.makeText(getContext(), "Subtopic progress updated!", Toast.LENGTH_SHORT).show();

                                        // Step 5.7.1.2: (Optional) Update the UI *locally* to reflect the change *immediately*.
                                        // The commented lines below are likely incorrect as they clear and re-add the same modified list.
                                        // courses.clear();  <-- This line is problematic. You probably don't want to clear the local list here.
                                        // courses.addAll(courses); <-- You probably don't want this either. You've already modified the `courses` list in place.
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    // Function: onFailure (OnFailureListener for Firestore update)
                                    // Description: Called when the Firestore update fails.
                                    // Input: Exception e - The exception detailing the failure.
                                    // Output: void (Shows error toast and logs error).
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        // Step 5.7.2.1: Show a toast message with the error details
                                        Toast.makeText(getContext(), "Error updating Firestore: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                        // Step 5.7.2.2: Log the error
                                        Log.e("Firestore", "Error updating subtopic progress", e);
                                    }
                                });

                    } else {
                        // Step 5.8: Show a toast if user data or course list is unexpectedly null
                        Toast.makeText(requireContext(), "User data or course list is null.", Toast.LENGTH_SHORT).show(); // Use requireContext()
                    }
                } else {
                    // Step 5.9: Show a toast if the user document is not found in Firestore
                    Toast.makeText(requireContext(), "User document not found.", Toast.LENGTH_SHORT).show(); // Use requireContext()
                }
            } else {
                // Step 5.10: Show a toast and log if fetching user data from Firestore failed
                Toast.makeText(requireContext(), "Error getting user data: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show(); // Use requireContext()
                Log.e("Firestore", "Error getting user data", task.getException());
            }
        });
    }

    // Function: onResume
    // Description: Called when the fragment is visible to the user and actively running.
    // Refreshes the options menu.
    // Input: none
    // Output: void (Refreshes menu).
    @Override
    public void onResume() {
        // Step 1: Call the superclass onResume method
        super.onResume();
        // Step 2: Invalidate the options menu to trigger onCreateOptionsMenu and refresh its state/visibility
        requireActivity().invalidateOptionsMenu(); // Refresh menu visibility
    }

    // Function: onCreateOptionsMenu
    // Description: Initializes the options menu for the fragment's toolbar.
    // Makes the Home menu item visible.
    // Input: Menu menu - The options menu.
    // Input: MenuInflater inflater - The inflater to inflate the menu layout.
    // Output: void (Inflates menu and sets Home item visibility).
    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        // Step 1: Call the superclass method (usually clears and inflates the base menu)
        super.onCreateOptionsMenu(menu, inflater);
        // Note: Original code in other fragments clears and reinflates here.
        // Consider inflating only once in the hosting activity if menu is consistent.

        // Step 2: Find the Home menu item
        MenuItem home = menu.findItem(R.id.menu_home);
        // Step 3: Make the Home menu item visible
        home.setVisible(true);
    }

    // Function: onOptionsItemSelected
    // Description: Called when an item in the options menu is selected. Handles navigation/actions based on the selected item.
    // Input: MenuItem item - The menu item that was selected.
    // Output: boolean - True if the event was consumed, false otherwise.
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Step 1: Get the ID of the selected menu item
        int itemId = item.getItemId();

        // Step 2: Check the ID and perform the corresponding action
        if (itemId == R.id.menu_log_out) {
            // Step 2.1: Handle Log Out action: Remove "Remember Me" flag from SharedPreferences
            SharedPreferences sharedPreferences = requireActivity()
                    .getSharedPreferences(Constants.KEY_REMEMBER_USER, requireActivity().MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(Constants.KEY_REMEMBER_USER, false); // Set flag to false
            editor.apply(); // Apply changes

            // Step 2.2: Clear the global currently selected subtopic
            SubtopicAdapter.currentlySelectedSubtopic = null;
            // Step 2.3: Sign out the user from Firebase Authentication (Optional based on flow)
            mAuth.signOut(); // Optionally sign out the user

            // Step 2.4: Navigate to the LogInActivity
            Intent intent = new Intent(getActivity(), LogInActivity.class); // Use getActivity() or requireActivity()
            startActivity(intent);
            // Step 2.5: Finish the current hosting activity if it exists
            if (getActivity() != null) { // Check if activity is not null
                getActivity().finish(); // Finish the hosting activity
            }
            return true; // Consume the event

        } else if (itemId == R.id.menu_go_back) {
            // Step 2.6: Handle Go Back action: Pop the fragment back stack
            FragmentManager fragmentManager = getParentFragmentManager(); // Use getParentFragmentManager() or requireActivity().getSupportFragmentManager()
            if (fragmentManager.getBackStackEntryCount() > 0) {
                // Step 2.6.1: If there are fragments in the back stack, pop the stack to go to the previous fragment
                fragmentManager.popBackStack();
            }
            // Note: If back stack is empty, no action is taken here. Consider navigating to MainActivity if needed.
            return true; // Consume the event

        } else if (itemId == R.id.menu_settings) {
            // Step 2.7: Handle Settings action: Navigate to the SettingsActivity
            Intent intent = new Intent(getActivity(), SettingsActivity.class); // Use getActivity() or requireActivity()
            startActivity(intent);
            // Note: Original code in other fragments sometimes finishes the current activity here. Review desired flow.
            return true; // Consume the event

        } else if (itemId == R.id.menu_home) {
            // Step 2.8: Handle Home action: Navigate to MainActivity
            if (itemId == R.id.menu_home) { // Assuming this was the intended check
                Intent intent = new Intent(getActivity(), MainActivity.class); // Use getActivity() or requireActivity()
                // Step 2.8.1: Clear the global currently selected subtopic (important when going home)
                SubtopicAdapter.currentlySelectedSubtopic = null;
                startActivity(intent);
                // Note: Finishing the activity here might be desired depending on navigation flow.
                return true; // Consume the event
            }
        } else if (itemId == R.id.menu_profile) {
            // Step 2.9: Handle Profile action: Navigate to the ProfileActivity
            Intent intent = new Intent(getActivity(), ProfileActivity.class); // Use getActivity() or requireActivity()
            startActivity(intent);
            return true; // Consume the event
        }

        // Step 3: If the item ID doesn't match any specific handling, call the superclass method for default handling
        return super.onOptionsItemSelected(item);
    }
}