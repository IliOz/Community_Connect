package com.example.myfinalproject.java_classes;

import java.io.Serializable;
import java.util.ArrayList;

// Class: UserInfoClass
// Description: Represents the data structure for user information stored in the application,
// including authentication details, selected courses, goals, time spent, and profile icon.
// It is Serializable to allow passing between components via Intents.
// Input: Data representing the various attributes of a user profile.
// Output: Provides access to the user's attributes and includes a basic credential verification method.
public class UserInfoClass implements Serializable {
    // --- User Authentication and Basic Info ---
    private String username; // The user's chosen username
    private String password; // The user's password (Note: Storing plain passwords is insecure; consider hashing)
    private String email; // The user's email address

    // --- User Progress and Customization ---
    private ArrayList<CourseClass> classes; // List of courses the user is enrolled in or has selected
    private int iconId; // Resource ID for the user's selected profile icon

    // Function: Constructor (No-argument)
    // Description: Default constructor required for Firebase Firestore object mapping and deserialization.
    // Input: none
    // Output: Initializes an empty UserInfoClass object.
    public UserInfoClass() {
        // Default constructor
    }

    // Function: Constructor (Parameterized - Full with Settings)
    // Description: Initializes a new UserInfoClass object with all attributes including app settings.
    // Input: All fields of the class.
    // Output: Fully initialized UserInfoClass object.
    public UserInfoClass(
            String username,
            String password,
            String email,
            ArrayList<CourseClass> classes,
            int iconId
    ) {
        // Basic info
        this.username = username;
        this.password = password;
        this.email = email;

        // Courses
        this.classes = (classes == null) ? new ArrayList<>() : classes;

        // Profile customization
        this.iconId = iconId;
    }

    // Function: getClasses
    // Description: Returns the list of courses the user is enrolled in or has selected.
    // Input: none
    // Output: ArrayList<CourseClass> - The list of courses.
    public ArrayList<CourseClass> getClasses() {
        return classes;
    }

    // Function: setClasses
    // Description: Sets the list of courses for the user.
    // Input: ArrayList<CourseClass> classes - The new list of courses.
    // Output: void (Updates the courses list).
    public void setClasses(ArrayList<CourseClass> classes) {
        this.classes = classes;
    }

    // Function: getEmail
    // Description: Returns the user's email address.
    // Input: none
    // Output: String - The user's email address.
    public String getEmail() {
        return email;
    }

    // Function: setEmail
    // Description: Sets the user's email address.
    // Input: String email - The new email address.
    // Output: void (Updates the email).
    public void setEmail(String email) {
        this.email = email;
    }

    // Function: getUsername
    // Description: Returns the user's username.
    // Input: none
    // Output: String - The username.
    public String getUsername() {
        return username;
    }

    // Function: getPassword
    // Description: Returns the user's password.
    // Input: none
    // Output: String - The password. (Note: Storing/returning plain passwords is insecure)
    public String getPassword() {
        return password;
    }
}