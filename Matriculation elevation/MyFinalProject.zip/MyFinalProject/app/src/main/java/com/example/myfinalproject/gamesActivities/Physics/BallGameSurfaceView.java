package com.example.myfinalproject.gamesActivities.Physics;

import android.content.Context; // Import Context
import android.graphics.Canvas; // Import Canvas
import android.graphics.Color; // Import Color
import android.graphics.Paint; // Import Paint
import android.graphics.Path; // Import Path
import android.util.AttributeSet; // Import AttributeSet
import android.util.Log; // Import Log
import android.view.MotionEvent; // Import MotionEvent
import android.view.SurfaceHolder; // Import SurfaceHolder
import android.view.SurfaceView; // Import SurfaceView

// Class: BallGameSurfaceView
// Description: A custom SurfaceView that displays and simulates a simple physics game
// where a ball moves horizontally and interacts with walls based on user touch input.
// It uses a dedicated thread for the game loop (update and draw).
// Input: Context and AttributeSet (standard for Views).
// Output: A interactive view displaying a moving ball and physics vectors.
public class BallGameSurfaceView extends SurfaceView implements SurfaceHolder.Callback {

    // --- Constants ---
    private static final float BALL_RADIUS = 50f; // Radius of the ball
    // Acceleration rate applied to the ball's velocity when moving towards the target
    // Static variable adjusted if multiple instances exist (simple attempt at difficulty scaling?)
    private static float ACCELERATION_RATE = 0.5f;
    // Deceleration factor applied on collision (bounce)
    private static float DECELERATION_FACTOR = 0.5f; // Not currently used in collision, check logic
    private static final float MAX_VELOCITY = 15f; // Maximum absolute velocity of the ball
    private static final float ARROW_LENGTH_MULTIPLIER = 25f; // Scales velocity to arrow length
    private static final float MAX_ARROW_LENGTH = 250f; // Maximum length for velocity/acceleration arrows
    private static final float ACCELERATION_ARROW_MULTIPLIER = 65f; // Scales acceleration to arrow length
    private static final float TEXT_SIZE = 30f; // Text size for physics values display
    private static final float ARROW_SPACING = 70f; // Vertical spacing between arrows and ball

    // --- Variables ---
    private Ball ball; // The Ball object representing the game element
    private GameThread gameThread; // The dedicated thread for the game loop
    private float targetVelocity = 0; // The desired velocity based on touch input
    // Static counter to track the number of instances of this class
    private static int instanceCount = 0;

    // Function: Constructor
    // Description: Initializes the BallGameSurfaceView. Increments the instance count and
    // adjusts physics constants if more than one instance exists. Adds the SurfaceHolder callback.
    // Input: Context context - The context this view is running in.
    // Input: AttributeSet attrs - The attributes of the XML tag that is inflating the view.
    // Output: Initializes the view and ball object.
    public BallGameSurfaceView(Context context, AttributeSet attrs) {
        // Step 1: Call the superclass constructor
        super(context, attrs);
        // Step 2: Increment the static instance counter
        instanceCount++;
        // Step 3: Check if more than one instance exists
        if (instanceCount > 1) {
            // Step 3.1: If more than one, reduce acceleration and deceleration (makes game easier?)
            ACCELERATION_RATE = 0.25f;
            DECELERATION_FACTOR = 0.25f; // Note: DECELERATION_FACTOR is currently not used in checkCollisions, review required.
        }
        // Step 4: Add this class as a callback to the SurfaceHolder to listen for surface events
        getHolder().addCallback(this);
        // Step 5: Create a new Ball instance with initial position (0,0) and radius
        ball = new Ball(0, 0, BALL_RADIUS); // Initial position will be set properly in surfaceCreated
    }

    // Function: surfaceCreated
    // Description: Called immediately after the surface is first created.
    // Sets the ball's initial position (center of the view), creates and starts the game thread.
    // Input: SurfaceHolder holder - The SurfaceHolder whose surface was just created.
    // Output: void (Sets up initial state and starts game thread).
    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        // Step 1: Calculate the initial position of the ball at the center of the view
        float startX = getWidth() / 2f;
        float startY = getHeight() / 2f;
        // Step 2: Set the ball's position using the calculated values
        ball.setPosition(startX, startY); // This also sets the initialX within the Ball class
        // Step 3: Log the dimensions of the SurfaceView (for debugging)
        Log.d("SurfaceView", "Width: " + getWidth() + ", Height: " + getHeight());

        // Step 4: Create a new GameThread instance, passing the SurfaceHolder and this view
        gameThread = new GameThread(getHolder(), this);
        // Step 5: Set the running state of the thread to true
        gameThread.setRunning(true);
        // Step 6: Start the game thread
        gameThread.start();
    }

    // Function: surfaceChanged
    // Description: Called immediately after any structural changes (format or size) have been made to the surface.
    // Input: SurfaceHolder holder - The SurfaceHolder whose surface has changed.
    // Input: int format - The new PixelFormat of the surface.
    // Input: int width - The new width of the surface.
    // Input: int height - The new height of the surface.
    // Output: void (Currently does nothing).
    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        // This method is often used to handle changes in surface dimensions, but is empty here.
    }

    // Function: surfaceDestroyed
    // Description: Called immediately before a surface is being destroyed. Stops the game thread safely.
    // Input: SurfaceHolder holder - The SurfaceHolder whose surface is being destroyed.
    // Output: void (Stops and joins the game thread).
    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        // Step 1: Flag to control the retry loop for joining the thread
        boolean retry = true;
        // Step 2: Set the running state of the game thread to false to signal it to stop
        gameThread.setRunning(false);
        // Step 3: Loop to repeatedly try joining (waiting for) the thread to finish
        while (retry) {
            try {
                // Step 3.1: Wait for the game thread to die (finish its run method)
                gameThread.join();
                // Step 3.2: If join is successful, set retry to false to exit the loop
                retry = false;
            } catch (InterruptedException e) {
                // Step 3.3: If interrupted while waiting, log or handle and retry stopping
                // Retry stopping thread (the while loop continues)
            }
        }
    }

    // Function: onTouchEvent
    // Description: Called when a touch screen event occurs. Handles setting the target velocity
    // based on whether the touch is left or right of the ball's center.
    // Input: MotionEvent event - The motion event object describing the touch.
    // Output: boolean - True if the event was handled, false otherwise.
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // Step 1: Use a switch statement to handle different touch event actions
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN: // Finger pressed down
            case MotionEvent.ACTION_MOVE: // Finger moved while pressed
                // Step 1.1: Get the X coordinate of the touch event
                float touchX = event.getX();
                // Step 1.2: Determine the target velocity based on touch position relative to the ball's X
                // If touch is left of the ball, target negative max velocity; otherwise, target positive max velocity.
                targetVelocity = (touchX < ball.getX()) ? -MAX_VELOCITY : MAX_VELOCITY;
                break; // Exit the switch case
            case MotionEvent.ACTION_UP: // Finger lifted up
            case MotionEvent.ACTION_CANCEL: // Touch gesture cancelled
                // Step 1.3: When touch ends, set the target velocity to 0 (stop the ball)
                targetVelocity = 0;
                break; // Exit the switch case
        }
        // Step 2: Return true to indicate that the touch event was handled
        return true;
    }

    // Function: update
    // Description: Updates the game state, applying physics (acceleration/deceleration)
    // and checking for collisions. Called in the game loop.
    // Input: none
    // Output: void (Updates ball position and velocity).
    public void update() {
        // Step 1: Apply physics to the ball (handle acceleration towards target velocity)
        applyPhysics();
        // Step 2: Check for and handle collisions with the screen edges
        checkCollisions();
        // Step 3: Update the ball's position based on its current velocity
        ball.update(); // This call was missing in the original update() but is present in the Ball class's update()
    }

    // Function: getGameThread
    // Description: Returns the instance of the GameThread associated with this view.
    // Input: none
    // Output: GameThread - The game thread object.
    public GameThread getGameThread() {
        // Step 1: Return the gameThread instance
        return gameThread;
    }

    // Function: hasBallMoved
    // Description: Public method to check if the ball has moved at least 1 unit from its initial X position.
    // Input: none
    // Output: boolean - True if the absolute difference between the ball's current X and initial X is >= 1.
    public boolean hasBallMoved() {
        // Step 1: Call the hasMovedAtLeastOne method on the ball object and return its result.
        return ball.hasMovedAtLeastOne();
    }

    // Function: applyPhysics
    // Description: Applies acceleration to the ball's velocity to move it towards the target velocity.
    // Handles acceleration and deceleration based on the target velocity.
    // Input: none
    // Output: void (Modifies ball's velocity and acceleration).
    private void applyPhysics() {
        // Step 1: Check if the ball's current velocity is less than the target velocity
        if (ball.getVelocity() < targetVelocity) {
            // Step 1.1: If less, accelerate the ball by the positive acceleration rate
            ball.accelerate(ACCELERATION_RATE);
        }
        // Step 2: Check if the ball's current velocity is greater than the target velocity
        else if (ball.getVelocity() > targetVelocity) {
            // Step 2.1: If greater, accelerate the ball by the negative acceleration rate (decelerate)
            ball.accelerate(-ACCELERATION_RATE);
        }

        // Step 3: Check if the ball's velocity is very close to the target velocity
        // This prevents oscillation around the target velocity due to small floating point errors.
        if (Math.abs(ball.getVelocity() - targetVelocity) < ACCELERATION_RATE) {
            // Step 3.1: If close enough, snap the velocity exactly to the target velocity
            ball.setVelocity(targetVelocity);
            // Step 3.2: Reset acceleration to 0 if velocity matches target? (Not explicitly done here but implied if velocity is set directly)
            // The Ball's accelerate method sets acceleration, but setting velocity directly doesn't.
            // Consider adding ball.setAcceleration(0) here if needed for accurate acceleration arrow.
        }
        // Note: The ball.update() call was moved from here to the public update() method for clarity.
        // Original code had ball.update() here.
    }

    // Function: checkCollisions
    // Description: Checks for collisions with the left and right edges of the view
    // and reverses/reduces the ball's velocity on collision (bounce).
    // Input: none
    // Output: void (Modifies ball's position and velocity on collision).
    private void checkCollisions() {
        // Step 1: Check for collision with the left edge
        // If the left edge of the ball (ball.getX() - ball.getRadius()) is less than 0
        if (ball.getX() - ball.getRadius() < 0) {
            // Step 1.1: If collision occurs, set the ball's X position to be just inside the edge
            ball.setX(ball.getRadius());
            // Step 1.2: Reverse the ball's velocity and reduce it by a factor (bounce effect)
            ball.setVelocity(-ball.getVelocity() * 0.5f); // Multiplies by 0.5f for damping
        }
        // Step 2: Check for collision with the right edge
        // If the right edge of the ball (ball.getX() + ball.getRadius()) is greater than the view's width
        else if (ball.getX() + ball.getRadius() > getWidth()) {
            // Step 2.1: If collision occurs, set the ball's X position to be just inside the edge
            ball.setX(getWidth() - ball.getRadius());
            // Step 2.2: Reverse the ball's velocity and reduce it by a factor (bounce effect)
            ball.setVelocity(-ball.getVelocity() * 0.5f); // Multiplies by 0.5f for damping
        }
    }

    // Function: draw
    // Description: Draws the game elements (ball, velocity arrow, acceleration arrow) onto the canvas.
    // Called in the game loop after update.
    // Input: Canvas canvas - The canvas to draw on.
    // Output: void (Renders the game state).
    @Override
    public void draw(Canvas canvas) {
        // Step 1: Call the superclass draw method
        super.draw(canvas);
        // Step 2: Check if the canvas is not null
        if (canvas != null) {
            // Step 2.1: Fill the canvas background with white color
            canvas.drawColor(Color.WHITE);
            // Step 2.2: Draw the ball onto the canvas
            ball.draw(canvas);
            // Step 2.3: Draw the velocity arrow onto the canvas
            drawVelocityArrow(canvas, ball);
            // Step 2.4: Draw the acceleration arrow onto the canvas
            drawAccelerationArrow(canvas, ball);
        }
    }

    // Function: drawVelocityArrow
    // Description: Draws an arrow representing the ball's current velocity above the ball.
    // The arrow's length and direction scale with the velocity.
    // Input: Canvas canvas - The canvas to draw on.
    // Input: Ball ball - The ball object whose velocity is being represented.
    // Output: void (Draws the velocity arrow and text).
    private void drawVelocityArrow(Canvas canvas, Ball ball) {
        // Step 1: Calculate the starting position of the arrow (above the ball)
        float startX = ball.getX();
        float startY = ball.getY() - ball.getRadius() - 90 - ARROW_SPACING; // Positions vertically above the ball

        // Step 2: Get the ball's current velocity
        float velocity = ball.getVelocity();
        // Step 3: Calculate the arrow length based on velocity and multiplier
        float arrowLength = velocity * ARROW_LENGTH_MULTIPLIER;
        // Step 4: Clamp the arrow length within the maximum allowed length
        arrowLength = Math.min(arrowLength, MAX_ARROW_LENGTH);
        arrowLength = Math.max(arrowLength, -MAX_ARROW_LENGTH); // Allows negative length for left direction

        // Step 5: Calculate the ending position of the arrow
        float endX = startX + arrowLength; // End X is shifted by arrowLength
        float endY = startY; // End Y is the same as start Y

        // Step 6: Create and configure a Paint object for drawing the arrow
        Paint paint = new Paint();
        paint.setColor(Color.BLUE); // Set arrow color to blue
        paint.setStrokeWidth(5); // Set line thickness
        // Step 7: Draw the main line of the arrow
        canvas.drawLine(startX, startY, endX, endY, paint);

        // Step 8: Draw the arrowhead
        Path path = new Path(); // Create a Path object for the arrowhead shape
        path.moveTo(endX, endY); // Start drawing from the end of the arrow line
        // Step 8.1: Draw the arrow point based on direction
        if (arrowLength >= 0) { // If moving right or stationary (arrow points right)
            path.lineTo(endX - 10, endY - 10); // Draw top wing of the arrowhead
            path.lineTo(endX - 10, endY + 10); // Draw bottom wing of the arrowhead
        } else { // If moving left (arrow points left)
            path.lineTo(endX + 10, endY - 10); // Draw top wing (relative to leftward direction)
            path.lineTo(endX + 10, endY + 10); // Draw bottom wing (relative to leftward direction)
        }
        path.close(); // Close the path to form a triangle
        // Step 8.2: Draw the arrowhead path using the same paint
        canvas.drawPath(path, paint);

        // Step 9: Draw the velocity text
        paint.setTextSize(TEXT_SIZE); // Set text size for the value
        paint.setTextAlign(Paint.Align.CENTER); // Center the text horizontally relative to startX
        // Draw the text showing the velocity value (formatted to 2 decimal places)
        canvas.drawText("Velocity = " + String.format("%.2f", velocity), startX, startY - 20, paint); // Position text slightly above the arrow start
    }

    // Function: drawAccelerationArrow
    // Description: Draws an arrow representing the ball's current acceleration above the ball (below velocity arrow).
    // The arrow's length and direction scale with the acceleration.
    // Input: Canvas canvas - The canvas to draw on.
    // Input: Ball ball - The ball object whose acceleration is being represented.
    // Output: void (Draws the acceleration arrow and text).
    private void drawAccelerationArrow(Canvas canvas, Ball ball) {
        // Step 1: Calculate the starting position of the arrow (above the ball, below velocity arrow)
        float startX = ball.getX();
        float startY = ball.getY() - ball.getRadius() - 60; // Positions vertically above the ball

        // Step 2: Get the ball's current acceleration
        float acceleration = ball.getAcceleration();
        // Step 3: Special case: If velocity is zero and acceleration is the rate (likely initial state or after stopping), show acceleration as 0
        // This prevents showing acceleration arrows when the ball is supposed to be stationary after reaching target 0.
        if (ball.getVelocity() == 0 && (acceleration == ACCELERATION_RATE || acceleration == -ACCELERATION_RATE))
            acceleration = 0; // Set displayed acceleration to 0 in this specific case

        // Step 4: Calculate the arrow length based on acceleration and multiplier
        float arrowLength = acceleration * ACCELERATION_ARROW_MULTIPLIER;
        // Step 5: Clamp the arrow length within the maximum allowed length
        arrowLength = Math.min(arrowLength, MAX_ARROW_LENGTH);
        arrowLength = Math.max(arrowLength, -MAX_ARROW_LENGTH); // Allows negative length for left direction

        // Step 6: Calculate the ending position of the arrow
        float endX = startX + arrowLength; // End X is shifted by arrowLength
        float endY = startY; // End Y is the same as start Y

        // Step 7: Create and configure a Paint object for drawing the arrow
        Paint paint = new Paint();
        paint.setColor(Color.GREEN); // Set arrow color to green
        paint.setStrokeWidth(5); // Set line thickness
        // Step 8: Draw the main line of the arrow
        canvas.drawLine(startX, startY, endX, endY, paint);

        // Step 9: Draw the arrowhead
        Path path = new Path(); // Create a Path object for the arrowhead shape
        path.moveTo(endX, endY); // Start drawing from the end of the arrow line
        // Step 9.1: Draw the arrow point based on direction
        if (arrowLength >= 0) { // If accelerating right or 0 (arrow points right)
            path.lineTo(endX - 10, endY - 10); // Draw top wing of the arrowhead
            path.lineTo(endX - 10, endY + 10); // Draw bottom wing of the arrowhead
        } else { // If accelerating left (arrow points left)
            path.lineTo(endX + 10, endY - 10); // Draw top wing (relative to leftward direction)
            path.lineTo(endX + 10, endY + 10); // Draw bottom wing (relative to leftward direction)
        }
        path.close(); // Close the path to form a triangle
        // Step 9.2: Draw the arrowhead path using the same paint
        canvas.drawPath(path, paint);

        // Step 10: Draw the acceleration text
        paint.setTextSize(TEXT_SIZE); // Set text size for the value
        paint.setTextAlign(Paint.Align.CENTER); // Center the text horizontally relative to startX
        // Draw the text showing the acceleration value (formatted to 2 decimal places)
        canvas.drawText("Acceleration = " + String.format("%.2f", acceleration), startX, startY - 20, paint); // Position text slightly above the arrow start
    }

    // Class: GameThread
    // Description: A dedicated thread for running the game loop (updating game state and drawing).
    // Input: SurfaceHolder and BallGameSurfaceView instance.
    // Output: Runs the game simulation in the background.
    class GameThread extends Thread {
        // Variables
        private final SurfaceHolder surfaceHolder; // Holds the surface allowing access to the Canvas
        private final BallGameSurfaceView gameView; // Reference to the hosting SurfaceView
        private boolean running = false; // Flag to control the game loop

        // Function: Constructor
        // Description: Initializes the GameThread with the necessary SurfaceHolder and SurfaceView references.
        // Input: SurfaceHolder surfaceHolder - The holder for the surface.
        // Input: BallGameSurfaceView gameView - The hosting SurfaceView instance.
        // Output: Initializes the thread object.
        public GameThread(SurfaceHolder surfaceHolder, BallGameSurfaceView gameView) {
            // Step 1: Assign the provided SurfaceHolder
            this.surfaceHolder = surfaceHolder;
            // Step 2: Assign the provided BallGameSurfaceView instance
            this.gameView = gameView;
        }

        // Function: setRunning
        // Description: Sets the flag that controls whether the game loop is running.
        // Input: boolean running - True to start/continue the loop, false to stop.
        // Output: void (Updates the running state).
        public void setRunning(boolean running) {
            this.running = running;
        }

        // Function: run
        // Description: The main method of the thread, containing the game loop.
        // It continuously locks the canvas, updates the game state, draws the game elements,
        // and unlocks/posts the canvas while the 'running' flag is true.
        // Input: none
        // Output: void (Executes the game loop).
        @Override
        public void run() {
            // Variable to hold the Canvas object
            Canvas canvas;
            // Step 1: The main game loop runs while the 'running' flag is true
            while (running) {
                canvas = null; // Reset canvas to null at the start of each loop iteration
                try {
                    // Step 2: Lock the canvas for drawing
                    canvas = surfaceHolder.lockCanvas();
                    // Step 3: Synchronize access to the surface holder to ensure only one thread draws at a time
                    synchronized (surfaceHolder) {
                        // Step 3.1: Update the game state
                        gameView.update();
                        // Step 3.2: Draw the game elements onto the canvas
                        gameView.draw(canvas);
                    }
                } finally {
                    // Step 4: Ensure the canvas is unlocked and posted even if errors occur
                    if (canvas != null) {
                        surfaceHolder.unlockCanvasAndPost(canvas);
                    }
                }
            }
        }
    }

    // Class: Ball
    // Description: Represents the ball object in the game, managing its position, velocity, and acceleration.
    // Handles updating its position based on velocity and drawing itself.
    // Input: Initial x, y coordinates and radius.
    // Output: Manages ball state and drawing.
    private static class Ball {
        // Variables
        private float x, y; // Current position of the ball
        private final float radius; // Radius of the ball (constant)
        private float velocity = 0; // Current horizontal velocity
        private float acceleration = 0; // Current horizontal acceleration
        // Field to track the initial X position for movement check
        private float initialX = 0; // Stores the X position when setPosition is first called

        // Function: Constructor
        // Description: Initializes a new Ball instance with a position and radius.
        // Input: float x - Initial x coordinate.
        // Input: float y - Initial y coordinate.
        // Input: float radius - The radius of the ball.
        // Output: Initializes the ball object.
        public Ball(float x, float y, float radius) {
            // Step 1: Assign the initial x coordinate
            this.x = x;
            // Step 2: Assign the initial y coordinate
            this.y = y;
            // Step 3: Assign the radius (final)
            this.radius = radius;
            // Note: initialX is set in the setPosition method when it's first called.
        }

        // Function: draw
        // Description: Draws the ball as a circle on the provided canvas.
        // Input: Canvas canvas - The canvas to draw on.
        // Output: void (Draws the ball).
        public void draw(Canvas canvas) {
            // Step 1: Create and configure a Paint object for drawing the ball
            Paint paint = new Paint();
            paint.setColor(Color.RED); // Set ball color to red
            // Step 2: Draw a circle on the canvas representing the ball
            canvas.drawCircle(x, y, radius, paint);
        }

        // Function: accelerate
        // Description: Applies acceleration to the ball's velocity and updates the acceleration value.
        // Clamps the velocity within the maximum allowed range.
        // Input: float acceleration - The acceleration value to add to the velocity.
        // Output: void (Modifies ball's velocity and acceleration).
        public void accelerate(float acceleration) {
            // Step 1: Store the applied acceleration value
            this.acceleration = acceleration;
            // Step 2: Add the acceleration to the current velocity
            velocity += acceleration;
            // Step 3: Clamp the velocity to the maximum positive limit
            if (velocity > MAX_VELOCITY) {
                velocity = MAX_VELOCITY;
            }
            // Step 4: Clamp the velocity to the maximum negative limit
            else if (velocity < -MAX_VELOCITY) {
                velocity = -MAX_VELOCITY;
            }
        }

        // Function: update
        // Description: Updates the ball's horizontal position based on its current velocity.
        // Input: none
        // Output: void (Modifies ball's x position).
        public void update() {
            // Step 1: Add the current velocity to the ball's x position
            x += velocity;
        }

        // Function: getX
        // Description: Returns the ball's current x coordinate.
        // Input: none
        // Output: float - The current x coordinate.
        public float getX() {
            return x;
        }

        // Function: setX
        // Description: Sets the ball's x coordinate.
        // Input: float x - The new x coordinate.
        // Output: void (Updates ball's x position).
        public void setX(float x) {
            this.x = x;
        }

        // Function: getY
        // Description: Returns the ball's current y coordinate.
        // Input: none
        // Output: float - The current y coordinate.
        public float getY() {
            return y;
        }

        // Function: getRadius
        // Description: Returns the ball's radius.
        // Input: none
        // Output: float - The radius.
        public float getRadius() {
            return radius;
        }

        // Function: getVelocity
        // Description: Returns the ball's current velocity.
        // Input: none
        // Output: float - The current velocity.
        public float getVelocity() {
            return velocity;
        }

        // Function: setVelocity
        // Description: Sets the ball's velocity directly.
        // Input: float velocity - The new velocity.
        // Output: void (Updates ball's velocity).
        public void setVelocity(float velocity) {
            this.velocity = velocity;
            // Note: This method does not update 'acceleration'. If accurate acceleration is needed
            // after setting velocity directly (e.g., after collision), 'acceleration' might need
            // to be reset here (e.g., this.acceleration = 0;).
        }

        // Function: setPosition
        // Description: Sets the ball's position. If the initial X position hasn't been recorded yet (is 0),
        // it records the provided x value as the initial X.
        // Input: float x - The new x coordinate.
        // Input: float y - The new y coordinate.
        // Output: void (Updates ball's position and records initial X if necessary).
        public void setPosition(float x, float y) {
            // Step 1: Set the ball's x coordinate
            this.x = x;
            // Step 2: Set the ball's y coordinate
            this.y = y;
            // Step 3: Check if the initial X position hasn't been set yet (default 0)
            // This assumes initialX will be set only once when the ball is first positioned after surface creation.
            if (initialX == 0) {
                // Step 3.1: If not set, record the current x position as the initial X
                initialX = x;
            }
        }

        // Function: getAcceleration
        // Description: Returns the ball's last applied acceleration value.
        // Input: none
        // Output: float - The last acceleration value used.
        public float getAcceleration() {
            return acceleration;
        }

        // Function: hasMovedAtLeastOne
        // Description: Checks if the ball's current horizontal position is at least 1 unit
        // away (in either direction) from its recorded initial X position.
        // Input: none
        // Output: boolean - True if the ball has moved 1 or more units away from the start, false otherwise.
        public boolean hasMovedAtLeastOne() {
            // Step 1: Calculate the absolute difference between the current x and the initial x
            // Step 2: Check if this absolute difference is greater than or equal to 1
            return Math.abs(x - initialX) >= 1;
        }
    }
}